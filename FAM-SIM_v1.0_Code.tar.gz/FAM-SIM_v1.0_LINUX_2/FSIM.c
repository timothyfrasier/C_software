/*--------------------------------Family_SIM.c---------------------------------------*/
/* This program takes allele frequencies from a given data set and generates a       */
/* user-defined number of pairs each of parent-offspring, full-sib, half-sib, and    */
/* unrelated individuals. These genotypes can then be used for power analyses of     */
/* various other applications.                                                       */    
/*										     */
/* Copyright (C) 2009 Tim Frasier                                                    */
/*                                                                                   */
/* This program is free software; you can redistribute it and/or modify it under the */
/* terms of the GNU General Public License as published by the Free Software         */
/* Foundation; either version 2 of the License, or (at your option) any later        */
/* version.                                                                          */
/*                                                                                   */
/* This program is distributed in the hope that it will be useful, but WITHOUT ANY   */
/* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A   */
/* PARTICULAR PURPOSE.  See the GNU Public License for more details.                 */
/* (http://www.gnu.org/licenses/gpl.html)                                            */
/*-----------------------------------------------------------------------------------*/

/*-----------------------*/
/* INCLUDED FILES        */
/*-----------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

/*----------------------*/
/* INCLUDED FUNCTIONS   */
/*----------------------*/
int Alleles(void);
void Frequencies(int a, int b);
int InitSeed(void);
void IterationSeed(int y, int z);
int Loci(void);
void *Mendel(int mm, int nn, int oo, int mendel[mm][nn]);
float Random(int e);
int Seed2(int aa, int bb);

/*-----------------------*/
/* START OF PROGRAM      */
/*-----------------------*/
int main(void)
{
	/*-------------------------*/
	/* PRINT WELCOME SCREEN    */
	/*-------------------------*/
	printf("\n\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	printf("\n\t\t    Welcome to FAMILY-SIM\n");
	printf("\n\t\t           ver. 1.0\n");
	printf("\n\t\t\tby Tim Frasier\n");
	printf("\n\t\t   Last updated: 22-Sep-2009");
	printf("\n\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");

	/************************************/
	/* Get # of desired simulated pairs */
	/************************************/
	int p;

        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many pairs of individuals (for each set of pairs) do you want to generate? ");
        scanf("%d", &p);
	

        /*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	        /*------------------*/
        	/* DEFINE VARIABLES */
        	/*------------------*/
        	int a;  /* Holds the number of alleles in most polymorphic locus */
        	int b;  /* Holds the number of loci analyzed */
        	int c;  /* Will be a + 1, which will be the # of rows in the array */
	
        	/*----------------------*/
        	/* GET DATA FROM USER   */
        	/*----------------------*/
        	a = Alleles();
		b = Loci();
        	c = a + 1;

        	/*------------------------*/
        	/* GET ALLELE FREQUENCIES */
        	/*------------------------*/
		Frequencies(c, b);

	/*************************************/
	/* DOUBLE THE ALLELE FREQUENCY ARRAY */
	/*************************************/

		/*--------------------------------------*/
		/* OPEN FREQS AND SCAN INTO FREQUENCIES */
		/*--------------------------------------*/
		FILE *fp2;
		char filename2[6] = "freqs";
		float frequencies[c][b];
		int count1, count2;

 	       	if((fp2 = fopen(filename2, "r")) == NULL)
        	{
        	        fprintf(stderr, "Error opening file %s.\n", filename2);
                	exit(1);
        	}

        	for (count1 = 0; count1 < c; count1++)
        	{
                	for (count2 = 0; count2 < b; count2++)
                	{
                	        fscanf(fp2, "%f", &frequencies[count1][count2]);
                	}
        	}

        	fclose(fp2);

		/*--------------------------*/
		/* DOUBLE THE ARRAY         */
		/*--------------------------*/
		int d;		/* Is the number of columns in new array */
		d = b*2;
		float freqs2[a][d];

		for (count1 = 1; count1 < c; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				freqs2[count1-1][count2*2] = frequencies[count1][count2];
				freqs2[count1-1][(count2*2)+1] = frequencies[count1][count2];
			}
		}

	/*******************************/
	/* MAKE FREQUENCIES CUMULATIVE */
	/*******************************/
	float freqs3[a][d];

	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < d; count2++)
		{
			if (count1 == 0)
				freqs3[count1][count2] = freqs2[count1][count2];
			else
				freqs3[count1][count2] = freqs3[count1-1][count2] + freqs2[count1][count2];
		}
	}

	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/

		/*-----------------------------------------*/
		/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
		/*-----------------------------------------*/
		int seed1;
		seed1 = InitSeed();
	
		/*-----------------------------------------*/
		/* WRITE RANDOM NUMBERS TO ARRAY           */
		/*-----------------------------------------*/
		int iterationseed[((2*p*4)+(3*p))];
	
		const gsl_rng_type * TT;
		gsl_rng * rr;
	
		gsl_rng_env_setup();
	
		TT = gsl_rng_mt19937;
		rr = gsl_rng_alloc (TT);
		gsl_rng_set(rr, seed1);
	
		for (count1 = 0; count1 < ((2*p*4)+(3*p)); count1++)
		{
			iterationseed[count1] = gsl_rng_uniform_pos(rr) * seed1;
		}
		
		gsl_rng_free(rr);

	/****************************************/
	/* MAKE ARRAY WITH NEW INDIVIDUALS      */
	/****************************************/
	int individuals[((2*p*4)+(3*p))][d];
	int individuals2[(2*p*4)][d];
	int count3;
	float rand;
	int e;

	for (count1 = 0; count1 < ((2*p*4)+(3*p)); count1++)
	{
		for (count2 = 0; count2 < d; count2++)
		{
			/*----------------------------*/
			/* GET A RANDOM NUMBER        */	
			/*----------------------------*/
			e = (iterationseed[count1] + (count2*3));
			
			rand = Random(e);

			for (count3 = 0; count3 < a; count3++)
			{
				if (rand < freqs3[count3][count2])
				{
					individuals[count1][count2] = count3+1;
					break;
				}
			}
		}
	}

	/******************************/
	/* GENERATE PARENT-OFFSPRING  */
	/******************************/
	int pair[2][d];

	for (count3 = 0; count3 < p; count3++)
	{
		/*-----------------------------*/
		/* GET APPROPRIATE MATING PAIR */        
		/*-----------------------------*/
		for (count2 = 0; count2 < d; count2++)
		{
			pair[0][count2] = individuals[(count3*2)][count2];
			pair[1][count2] = individuals[(count3*2)+1][count2];
		}

		/*----------------------------------------------*/
		/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
		/*----------------------------------------------*/
		int mendel[2][d];
		Mendel(2, d, iterationseed[count3], mendel);
	
		/*--------------------------*/
		/* CREATE A NEW OFFSPRING   */
		/*--------------------------*/
		int off[1][d];
	
		for (count1 = 0; count1 < d; count1 += 2)
		{
			if (mendel[0][count1] == 1)
				off[0][count1] = pair[0][count1];
			else
				off[0][count1] = pair[0][count1+1];
		}
	
		for (count1 = 1; count1 < d; count1 += 2)
		{
			if (mendel[1][count1] == 1)
				off[0][count1] = pair[1][count1-1];
			else
				off[0][count1] = pair[1][count1];
		}

		/*-------------------------------*/
		/* PLACE PAIR BACK IN ARRAY      */
		/*-------------------------------*/
		for (count1 = 0; count1 < d; count1++)
		{
			individuals2[count3*2][count1] = pair[0][count1];
			individuals2[(count3*2)+1][count1] = off[0][count1];
		}
	}

	/**********************************/
	/* GENERATE FULL-SIBS             */
	/**********************************/
	int count4;

	for (count3 = p; count3 < (2*p); count3++)
	{
		/*-----------------------------*/
		/* GET APPROPRIATE MATING PAIR */        
		/*-----------------------------*/
		for (count2 = 0; count2 < d; count2++)
		{
			pair[0][count2] = individuals[count3*2][count2];
			pair[1][count2] = individuals[(count3*2)+1][count2];
		}

		/*---------------------------*/
		/* GENERATE TWO OFFSPRING   */
		/*---------------------------*/
		for (count4 = 0; count4 < 2; count4++)
		{
			/*----------------------------------------------*/
			/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
			/*----------------------------------------------*/
			int mendel[2][d];
			int off[1][d];
			Mendel(2, d, iterationseed[(count3*2)+count4], mendel);
	
			/*--------------------------*/
			/* CREATE A NEW OFFSPRING   */
			/*--------------------------*/
			for (count1 = 0; count1 < d; count1 += 2)
			{
				if (mendel[0][count1] == 1)
					off[0][count1] = pair[0][count1];
				else
					off[0][count1] = pair[0][count1+1];
			}
		
			for (count1 = 1; count1 < d; count1 += 2)
			{
				if (mendel[1][count1] == 1)
					off[0][count1] = pair[1][count1-1];
				else
					off[0][count1] = pair[1][count1];
			}

			/*-------------------------------*/
			/* PLACE OFFSPRING BACK IN ARRAY */
			/*-------------------------------*/
			for (count1 = 0; count1 < d; count1++)
			{
				individuals2[(count3*2)+count4][count1] = off[0][count1];
			}
		}

	}

	/******************************/
	/* GENERATE HALF-SIBS         */
	/******************************/
	int z;
	z = 0;

	for (count3 = (2*p); count3 < (3*p); count3++)
	{
		/*-----------------------------*/
		/* GET FIRST PARENT            */        
		/*-----------------------------*/
		for (count2 = 0; count2 < d; count2++)
		{
			pair[0][count2] = individuals[(count3*2)+z][count2];
		}

		/*--------------------------------------------------------*/
		/* GENERATE TWO OFFSPRING EACH WITH A DIFFERENT SPOUSE    */
		/*--------------------------------------------------------*/
		for (count4 = 0; count4 < 2; count4++)
		{
			/*----------------------------*/
			/* GET SPOUSE                 */
			/*----------------------------*/
			for (count2 = 0; count2 < d; count2++)
			{
				pair[1][count2] = individuals[(count3*2)+z+(count4+1)][count2];
			}	
		
			/*----------------------------------------------*/
			/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
			/*----------------------------------------------*/
			int mendel[2][d];
			int off[1][d];
			Mendel(2, d, iterationseed[(count3*2)+count4], mendel);
	
			/*--------------------------*/
			/* CREATE A NEW OFFSPRING   */
			/*--------------------------*/
			for (count1 = 0; count1 < d; count1 += 2)
			{
				if (mendel[0][count1] == 1)
					off[0][count1] = pair[0][count1];
				else
					off[0][count1] = pair[0][count1+1];
			}
		
			for (count1 = 1; count1 < d; count1 += 2)
			{
				if (mendel[1][count1] == 1)
					off[0][count1] = pair[1][count1-1];
				else
					off[0][count1] = pair[1][count1];
			}

			/*-------------------------------*/
			/* PLACE OFFSPRING BACK IN ARRAY */
			/*-------------------------------*/
			for (count1 = 0; count1 < d; count1++)
			{
				individuals2[(count3*2)+count4][count1] = off[0][count1];
			}
		}
		z += 1;
	}

	/******************************/
	/* GET UNRELATED INDIVIDUALS  */
	/******************************/
	int w;
	w = (2*p*3);

	for (count1 = ((2*p*2)+(3*p)); count1 < ((2*p*4)+(3*p)); count1++)
	{
		for (count2 = 0; count2 < d; count2++)
		{
			individuals2[w][count2] = individuals[count1][count2];
		}
		w += 1;
	}

	/****************************/
	/* PRINT RESULTS TO OUTFILE */
	/****************************/
	FILE *fp20;
	char filename20[8] = "Fam_Sim";

        if((fp20 = fopen(filename20, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename20);
                exit(1);
        }

	for (count1 = 0; count1 < (2*p*4); count1++)
	{
		fprintf(fp20, "%d\t", count1+1);

		for (count2 = 0; count2 < d; count2++)
		{
			fprintf(fp20, "%d\t", individuals2[count1][count2]);
		}
		fprintf(fp20, "\n");
	}

	fclose(fp20);

	printf("\n************************************************\n");
	printf("Done!!! Results printed to file 'Fam_Sim'\n");
	printf("**************************************************\n\n");

return(0);
}	
	
int Alleles(void)
/*-----------------------------*/
/* This function asks the user */
/* how many alleles they have  */
/* in the most polymorphic     */
/* locus, and then saves that  */
/* value.                      */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many alleles do you have in the most polymorphic locus (not including 0)? ");
        scanf("%d", &a);

	return a;
}

void Frequencies(int a, int b)
/*------------------------------*/
/* This function asks the user  */
/* the name of their allele     */
/* frequency file, and then     */
/* reads that into an array     */
/* named frequencies and then   */
/* writes it to a file named    */
/* freqs.                       */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[40];
        int count1, count2;
	float frequencies[a][b];
	FILE *fp2;
	char filename2[6] = "freqs";

        printf("\nWhat is the name of your allele frequency file (including extension)? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < a; count1++)
        {
                for (count2 = 0; count2 < b; count2++)
                {
                        fscanf(fp1, "%f", &frequencies[count1][count2]);
                }
        }

        fclose(fp1);

	if ((fp2 = fopen(filename2, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename2);
		exit(1);
	}	
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			fprintf(fp2, "%f\t", frequencies[count1][count2]);
		}
		fprintf(fp2, "\n");
	}

	fclose(fp2);  	

}

int InitSeed(void)
/*------------------------------------*/
/* This function generates a seed for */
/* the random number generator based  */
/* on the computer clock.             */
/*------------------------------------*/
{
        int seed;
        time_t  nowtime;
        struct tm*preztime;

        time(&nowtime);
        preztime = localtime(&nowtime);
        seed = (int)((preztime->tm_sec+1)*(preztime->tm_min+1)*(preztime->tm_hour+1)*(preztime->tm_year)*(preztime->tm_year));
        if(seed%2==0) seed++;

        return seed;
}

void IterationSeed(int y, int z)
/*------------------------------*/
/* This function creates a list */
/* of random numbers, one for   */
/* each iteration that the user */
/* wants to perform, that will  */
/* serve as the seed for the    */
/* other random number          */
/* generators within that       */
/* iteration.  These numbers are*/
/* written to a file called     */
/* "iterationseeds".            */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[15] = "iterationseeds";
        int count1;
	int randomseed[y];
	
	/*--------------------------------*/
	/* CREAT ARRAY OF RANDOM NUMBERS  */
	/*--------------------------------*/
	const gsl_rng_type * TT;
	gsl_rng * rr;

	gsl_rng_env_setup();

	TT = gsl_rng_mt19937;
	rr = gsl_rng_alloc (TT);
	gsl_rng_set(rr, z);

	for (count1 = 0; count1 < y; count1++)
	{
		randomseed[count1] = gsl_rng_uniform_pos(rr) * z;
	}
	
	gsl_rng_free(rr);

	/*-----------------------------*/
	/* WRITE ARRAY TO FILE         */
	/*-----------------------------*/
	if ((fp1 = fopen(filename1, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename1);
		exit(1);
	}	
	
	for (count1 = 0; count1 < y; count1++)
	{
		fprintf(fp1, "%d\n", randomseed[count1]);
	}

	fclose(fp1);  	
}

int Loci(void)
/*-----------------------------*/
/* This function asks the user */
/* how many loci they used and */
/* saves that  value.          */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of loci used */
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many loci did you use? ");
        scanf("%d", &a);

	return a;
}

void *Mendel(int mm, int nn, int oo, int mendel[mm][nn])
/*------------------------------------*/
/* This function makes an array that  */
/* is filled with 1's and 2's that    */
/* serves to determine which alleles  */
/* offspring will inherit.            */
/*------------------------------------*/
{
	/*--------------------------*/
	/* DEFINE VARIABLES         */
	/*--------------------------*/
	float mendel1[mm][nn];
	int count1, count2;
	const gsl_rng_type * TTT;
	
	gsl_rng * rrr;

	/*------------------------------------*/
	/* CREAT ARRAY OF RANDOM NUMBERS      */
	/*------------------------------------*/
	gsl_rng_env_setup();

	TTT = gsl_rng_mt19937;
	rrr = gsl_rng_alloc (TTT);
	gsl_rng_set(rrr, oo);

	for (count1 = 0; count1 < mm; count1++)
	{
		for (count2 = 0; count2 < nn; count2++)
		{
			mendel1[count1][count2] = gsl_rng_uniform_pos(rrr);
		}
	}

	gsl_rng_free(rrr);

	/*--------------------------------------*/
	/* CONVERT THESE NUMBERS TO 1'S AND 0'S */
	/*--------------------------------------*/
	for (count1 = 0; count1 < mm; count1++)
	{
		for (count2 = 0; count2 < nn; count2++)
		{
			if (mendel1[count1][count2] < 0.5)
				mendel[count1][count2] = 1;
			else
				mendel[count1][count2] = 2;
		}
	}	
	return(0);
}

float Random(int e)
/*----------------------------------*/
/* This function generates a random */
/* number between 0 and 1.          */
/*----------------------------------*/
{
	float a;
	const gsl_rng_type * TTT;
	
	gsl_rng * rrr;

	/*------------------------------------*/
	/* CREAT ARRAY OF RANDOM NUMBERS      */
	/*------------------------------------*/
	gsl_rng_env_setup();

	TTT = gsl_rng_mt19937;
	rrr = gsl_rng_alloc (TTT);
	gsl_rng_set(rrr, e);

	a = gsl_rng_uniform_pos(rrr);

	gsl_rng_free(rrr);

	return(a);
}

int Seed2(int aa, int bb)
/*-----------------------------*/
/* This function opens the     */
/* file of random numbers and  */
/* returns the number that     */
/* corresponds to the          */
/* iteration that is currently */
/* being performed.  This      */
/* number acts as the seed for */
/* the current iteration.      */
/*-----------------------------*/
{
	/********************************************************/
	/* OPEN "iterationseeds" AND SCAN INTO "randommc" ARRAY */
	/********************************************************/

	/*----------------------*/
	/* DEFINE VARIABLES     */
	/*----------------------*/
        FILE *fp1;
        char filename1[15] = "iterationseeds";
        int count1;
	int randommc[bb];

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < bb; count1++)
        {
		fscanf(fp1, "%d", &randommc[count1]);
        }

        fclose(fp1);

	/*********************************************/
	/* GET NUMBER ASSOCIATED WITH THIS ITERATION */
	/*********************************************/
	int a;
	a = randommc[aa];

	return(a);
} 




	
