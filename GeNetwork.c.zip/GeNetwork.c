/*-------------------GeNetwork.c------------------------------------*/
/* This program provides a few functions for analyzing individual-  */
/* based genetic data as a network.  Briefly, the program allows the*/
/* user to create a network based on pairwise relatedness values,   */
/* or pairwise values of allele sharing.  The program also creates  */
/* simulated data sets based on a given allele frequency file, so   */
/* that users can generate simulated data sets as the "null model"  */
/* for what a network may look like for their data set.             */
/*                                                                  */
/* Copyright (C) 2011 Tim Frasier                                   */
/*                                                                  */
/* This program is free software; you can redistribute it and/or    */
/* modify it under the terms of the GNU General Public License as   */
/* published by the Free Software Foundation; either version 2 of   */
/* the Locense, or (at your option) any later version.              */
/*                                                                  */
/* This program is distributed in teh hope that it will be useful,  */
/* but WITHOUT ANY WARRANTY; without even the implied warrant of    */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    */
/* GNU Public License for more details.                             */
/* (http://www.gnu.org/licenses/gpl.html)                           */
/*------------------------------------------------------------------*/

/*-------------------------*/
/*   INCLUDED FILES        */
/*-------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

/*----------------------*/
/*   MAIN FUNCTIONS     */
/*----------------------*/
int AlleleFrequencies(void);
int AlleleSharing2(void);
int AlleleSharingSim(void);
int Relatedness2(void);
int RelatednessSim(void);

/*----------------------*/
/*   HELPER FUNCTIONS   */
/*----------------------*/
int Alleles(void);
void *AlleleSharing(int b, int e, int pair[2][e], float AS[1][b]);
void *AlleleSharingRel(int b, int e, int pair[2][e], float AS[1][b]);
void clear_kb(void);
void *FreqConvert(int c, int b, float frequencies[c][b], float freqs2[c][b]);
void *FreqsColumn_to_Row(int b, int c, float freqs3[c][b], float freqs4[b][c]);
void *Frequencies(int c, int b, float frequencies[c][b]);
int Genotypes(void);
int InitSeed(void);
int Iterations(void);
void *IterationSeed(int y, int z, int iterationseeds[y]);
int Loci(void);
void *Locus_Var(int b, int c, float freqs3[b][c], float var[b]);
float Locus_Weights(int b, int e, int pair[2][e], float var[b], float weights[1][b]);
void Partials(int d, int e, int profiles[d][e]);
float Random(int e);
float Relatedness(int b, int e, float weight, int pair[2][e], float AS[1][b], float S02[1][b], float weights[1][b]);
void *S0_Calc(int b, int c, float freqs3[b][c], float S02[1][b]);

/*------------------------*/
/* BEGINNING OF PROGRAM   */
/*------------------------*/

/*-----------------------------------------*/
/* CREATE STRUCTURE TO HOLD OUTFILE NAMES  */
/*-----------------------------------------*/
struct Text1{
	char outname[10];
};

/*-------------------------------------------*/
/* CREATE STRUCTURE TO HOLD INDIVIDUAL NAMES */
/*-------------------------------------------*/
struct Text2{
	char IndName[20];
};

int main(void)
{
	int selection;
	selection = 0;
	
	/*-----------------------------------------*/
	/*         PRINT WELCOME SCREEN            */
	/*-----------------------------------------*/
	printf("\n\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	printf("\n\t\t      Welcome to GeNetwork\n");
	printf("\n\t\t            ver. 1.0\n");
	printf("\n\t\t\tby    Tim Frasier\n");
	printf("\n\t\t     Last Updated: 23-Sep-2011");
	printf("\n\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
	printf("\n WHAT WOULD YOU LIKE TO DO?\n");
	printf("\n\t1. Calculate allele frequencies?\n");
	printf("\n\t2. Create a pairwise matrix based on allele sharing?\n");
	printf("\n\t3. Create a pairwise matrix based on relatedness?\n");
	printf("\n\tSimilate data sets based on allele frequencies and...\n");
	printf("\n\t\t4. Have these simlations analyzed based on allele sharing?\n");
	printf("\n\t\t5. Have these simlations analyzed based on relatedness?\n");
	printf("\n\t6. QUIT?\n");
	printf("\nType your selection here: ");
	scanf("%d", &selection);
	
	if (selection == 1)
		AlleleFrequencies();
	else
		if (selection == 2)
			AlleleSharing2();
		else 
			if (selection == 3)
				Relatedness2();
			else 
				if (selection == 4)
					AlleleSharingSim();
				else 
					if (selection == 5)
						RelatednessSim();

	return(0);
}	

/********************************************************************************/
/*                          MAIN FUNCTIONS                                      */
/********************************************************************************/

int AlleleFrequencies(void)
{
	clear_kb();
	/****************************************/
	/* GET GENOTYPE DATA FROM THE USER      */
	/****************************************/
	
	/*------------------*/
	/* Define Variables */
	/*------------------*/
	int loci; /* Holds the number of loci analyzed */
	int individuals; /* Holds the number of individuals analyzed */
	int columns; /* Will be (2 * loci) = # of columns in array */
	
	/*------------------*/
	/* Get Data         */
	/*------------------*/
	loci = Loci();
	individuals = Genotypes();
	columns = (2 * loci);
	
	int profiles[individuals][columns]; /* The array that will hold the genotype data */
	
	/*------------------------*/
	/* INITIALIZE STRUCTURE   */
	/*------------------------*/
	struct Text2 Names[individuals];
	
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
	FILE *fp1;
	char filename1[40];
	int count1, count2;
	
	printf("\nWhat is the name of your genotype file (including extension)? ");
	scanf("%s", filename1);
	
	if((fp1 = fopen(filename1, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename1);
		exit(1);
	}
	
	for (count1 = 0; count1 < individuals; count1++)
	{
		for (count2 = 0; count2 < (columns+1); count2++)
		{
			if (count2 == 0)
				fscanf(fp1, "%s", Names[count1].IndName);
			else
				fscanf(fp1, "%d", &profiles[count1][count2-1]);
		}
	}
	
	fclose(fp1);
	
	/*----------------------------*/
	/* Write results to outfile   */
	/*----------------------------*/
	FILE *fp2;
	char filename2[40];
	
	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename2);
	
	if((fp2 = fopen(filename2, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename2);
		exit(1);
	}
	
	/*----------------------------*/
	/* Write zeros across top     */
	/*----------------------------*/
	for (count1 = 0; count1 < loci; count1++)
	{
		fprintf(fp2, "%d", 0);
		
		if (count1 < (loci-1))
			fprintf(fp2, "\t");
		else
			fprintf(fp2, "\n");
	}
	
	
	/*------------------------------------------*/
	/* MAKE ALLELES ONE COLUMNS FOR EACH LOCUS  */
	/*------------------------------------------*/
	int alleles1[(individuals*2)][loci];
	
	for (count1 = 0; count1 < individuals; count1++)
	{
		for (count2 = 0; count2 < loci; count2++)
		{	
			alleles1[count1*2][count2] = profiles[count1][count2*2];
			alleles1[(count1*2)+1][count2] = profiles[count1][(count2*2)+1];
		}
	}
	
	/*--------------------------------------*/
	/*    MAKE COLUMNS ROWS                 */
	/*--------------------------------------*/
	int alleles2[loci][(individuals*2)];
	
	for (count1 = 0; count1 < (individuals*2); count1++)
	{	
		for (count2 = 0; count2 < loci; count2++)
		{	
			alleles2[count2][count1] = alleles1[count1][count2];
		}
	}
	
	/*---------------------------*/
	/*    SORT ALLELES           */
	/*---------------------------*/
	int holder;
	int count3;
	
	for (count1 = 0; count1 < loci; count1++)
	{
		for (count2 = 0; count2 < (individuals*2)-1; count2++)
		{	
			for (count3 = 0; count3 < (individuals*2)-count2-1; count3++)
			{	
				if (alleles2[count1][count3] > alleles2[count1][count3+1])
				{	
					holder = alleles2[count1][count3];
					alleles2[count1][count3] = alleles2[count1][count3+1];
					alleles2[count1][count3+1] = holder;
				}
			}
		}
	}

	
	/*--------------------------*/
	/* IDENTIFY UNIQUE VALUES   */
	/*--------------------------*/
	int unique[loci][individuals*2];
	int allelecounts[loci];
	int allelenumber;
	
	for (count1 = 0; count1 < loci; count1++)
	{	
		allelenumber = 0;
		
		if (alleles2[count1][0] == 0)	
			unique[count1][0] = 0;
		else{
			unique[count1][0] = 2;
			allelenumber += 1;
		} 
		
		
		for (count2 = 1; count2 < (individuals*2); count2++)
		{	
			if (alleles2[count1][count2] == 0)
				unique[count1][count2] = 0;
			else
				if (alleles2[count1][count2] == alleles2[count1][count2-1])
					unique[count1][count2] = 1;
				else{
					unique[count1][count2] = 2;
					allelenumber += 1;
				}	
			
		}	
		allelecounts[count1] = allelenumber;
	}
		
	/*----------------------------*/
	/* Identify most # of alleles */
	/*----------------------------*/
	int MAX;
	
	MAX = allelecounts[0];
	
	for (count1 = 1; count1 < loci; count1++)
	{	
		if (allelecounts[count1] > MAX)
			MAX = allelecounts[count1];
	}
	
	/*-------------------------------------*/
	/* Place unique alleles in a new array */
	/*-------------------------------------*/
	int alleles3[loci][MAX];
	
	for (count1 = 0; count1 < loci; count1++)
	{	
		count3 = 0;
		
		for (count2 = 0; count2 < (individuals*2); count2++)
		{	
			if (unique[count1][count2] == 2)
			{	
				alleles3[count1][count3] = alleles2[count1][count2];
				count3 += 1;
			}
		}
	}
		
	/*-------------------------------------*/
	/* Count the number of missing alleles */
	/*-------------------------------------*/
	float missing[loci];
	float count4;
	
	for (count1 = 0; count1 < loci; count1++)
	{	
		count4 = 0;
		
		for (count2 = 0; count2 < (individuals*2); count2++)
		{	
			if (alleles2[count1][count2] == 0)
				count4 += 1;
		}
		missing[count1] = count4;	
	}
	
	/*----------------------------------------------*/
	/* Count the number of times each allele occurs */
	/*----------------------------------------------*/
	float alleles4[loci][MAX];
	
	for (count1 = 0; count1 < loci; count1++)
	{	
		for (count2 = 0; count2 < MAX; count2++)
		{	
			count4 = 0;
			
			for (count3 = 0; count3 < (individuals*2); count3++)
			{	
				if (alleles2[count1][count3] == alleles3[count1][count2])
					count4 += 1;
			}
			alleles4[count1][count2] = count4 / ((individuals*2)-missing[count1]);	
		}
	}
	
	
	/*--------------------------*/
	/* Write allele frequencies */
	/*--------------------------*/
	for (count1 = 0; count1 < MAX; count1++)
	{			
		for (count2 = 0; count2 < loci; count2++)
		{	
			if (alleles3[count2][count1] == 0)
			{
				fprintf(fp2, "%d", 5);
			}
			else{
				fprintf(fp2, "%f", alleles4[count2][count1]);
				}
			
			if (count2 < (loci-1))
				fprintf(fp2, "\t");
			else
				fprintf(fp2, "\n");	
		}
	}
	
	fclose(fp2);
	
	printf("\n**************************************************************");
	printf("\n Done! Your results have been printed to file %s.", filename2);
	printf("\n**************************************************************\n");
	return(0);
}

int AlleleSharing2(void)
{
	/****************************************/
	/* GET GENOTYPE DATA FROM THE USER      */
	/****************************************/
	
	/*------------------*/
	/* Define Variables */
	/*------------------*/
	int loci; /* Holds the number of loci analyzed */
	int individuals; /* Holds the number of individuals analyzed */
	int columns; /* Will be (2 * loci) = # of columns in array */

	/*------------------*/
	/* Get Data         */
	/*------------------*/
	loci = Loci();
	individuals = Genotypes();
	columns = (2 * loci);
	
	int profiles[individuals][columns]; /* The array that will hold the genotype data */
	
	/*------------------------*/
	/* INITIALIZE STRUCTURE   */
	/*------------------------*/
	struct Text2 Names[individuals];
	
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
	FILE *fp1;
	char filename1[40];
	int count1, count2;
	
	printf("\nWhat is the name of your genotype file (including extension)? ");
	scanf("%s", filename1);
	
	if((fp1 = fopen(filename1, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename1);
		exit(1);
	}
	
	for (count1 = 0; count1 < individuals; count1++)
	{
		for (count2 = 0; count2 < (columns+1); count2++)
		{
			if (count2 == 0)
				fscanf(fp1, "%s", Names[count1].IndName);
			else
				fscanf(fp1, "%d", &profiles[count1][count2-1]);
		}
	}
	
	fclose(fp1);
	
	/*--------------------------------*/
	/* Deal with partial profiles     */
	/*--------------------------------*/
	Partials(individuals, columns, profiles);
	
	/******************************/
	/* MAKE RESULTS FILE          */
	/******************************/
	FILE *fp2;
	char filename2[40];
	
	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename2);
	
	if((fp2 = fopen(filename2, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename2);
		exit(1);
	}
	
	/*--------------------------------------*/
	/* Write individual ID's across top     */
	/*--------------------------------------*/
	for (count1 = 0; count1 < individuals; count1++)
	{
		fprintf(fp2, "%s", Names[count1].IndName);
		
		if (count1 < (individuals-1))
			fprintf(fp2, ",");
		else
			fprintf(fp2, "\n");
	}
	
	/*------------------------------------*/
	/* Read appropriate pair into array   */
	/*------------------------------------*/
	int count3;
	int pair[2][columns];
	
	for (count1 = 0; count1 < individuals; count1++)
	{
		for (count2 = 0; count2 < individuals; count2++)
		{
			for (count3 = 0; count3 < columns; count3++)
			{
				pair[0][count3] = profiles[count1][count3];
				pair[1][count3] = profiles[count2][count3];
			}
			
			/*****************************************/
			/* CALCULATE ALLELE SHARING FOR THE PAIR */
			/*****************************************/
			int count5, count6;	
			float AS[1][loci];
			float total;
			AlleleSharing(loci, columns, pair, AS);
			
			total = 0;
			
			for (count5 = 0; count5 < 1; count5++)
			{
				for (count6 = 0; count6 < loci; count6++)
				{
						total += AS[count5][count6];
				}
			}
			
			/********************************/
			/* COUNT LOCI NOT TYPED         */
			/********************************/
			int miss[1][loci];
			float missing;
			
			missing = 0;
			
			for (count5 = 0; count5 < 1; count5++)
			{
				for (count6 = 0; count6 < loci; count6++)
				{
					if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
						miss[count5][count6] = 1;
					else
						miss[count5][count6] = 0;
					missing += miss[count5][count6];
				}
			}
			
			/*********************************/
			/* CALCULATE PROPSHARED          */
			/*********************************/
			float propshared;
			
			propshared = total/(loci - missing);
			
			/**************************/
			/* PRINT RESULTS TO FILE  */
			/**************************/
			if (count2 < (individuals-1))
				fprintf(fp2, "%f,", propshared);
			else
				fprintf(fp2, "%f\n", propshared);
		}
		
	}
	fclose(fp2);
	
	printf("\n**************************************************************");
	printf("\n Done! Your results have been printed to file %s.", filename2);
	printf("\n**************************************************************\n");
	
	return(0);
}

int AlleleSharingSim(void)
{
	/******************************************/
	/* GET HOW MANY ITERATIONS TO PERFORM     */
	/******************************************/
	int mc;
	mc = Iterations();
	
	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/
	
	/*-----------------------------------------*/
	/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
	/*-----------------------------------------*/
	int seed1;
	seed1 = InitSeed();
	
	/*-------------------------------------------------*/
	/* CREATE ARRAY AND WRITE TO FILE "iterationseeds" */
	/*-------------------------------------------------*/
	int iterationseeds[mc];
	IterationSeed(mc, seed1, iterationseeds);
	
	/**************************************/
	/*     GET DATA FROM THE USER         */
	/**************************************/
	int individuals;
	
	printf("\nHow many individuals do you want to generate? ");
	scanf("%d", &individuals);
	
	/*******************************************/
	/* Get allele frequency data from the user */
	/*******************************************/
	
 	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int alleles;  /* Holds the number of alleles in most polymorphic locus */
	int loci;  /* Holds the number of loci analyzed */
	int rows;  /* Will be a + 1, which will be the # of rows in the array */
	int columns; 	/* Will be 2 * loci */
	int count1, count2;
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	alleles = Alleles();
	loci = Loci();
	rows = (alleles + 1);
	columns = (2 * loci);
	
	/*------------------------*/
	/* GET ALLELE FREQUENCIES */
	/*------------------------*/
	float frequencies[rows][loci];
	Frequencies(rows, loci, frequencies);
	
	
	/*--------------------------*/
	/* DOUBLE THE ARRAY         */
	/*--------------------------*/
	float freqs2[alleles][columns];
	
	for (count1 = 1; count1 < rows; count1++)
	{
		for (count2 = 0; count2 < loci; count2++)
		{
			freqs2[count1-1][count2*2] = frequencies[count1][count2];
			freqs2[count1-1][(count2*2)+1] = frequencies[count1][count2];
		}
	}
	
	/*-----------------------------*/
	/* MAKE FREQUENCIES CUMULATIVE */
	/*-----------------------------*/
	float freqs3[alleles][columns];
	
	for (count1 = 0; count1 < alleles; count1++)
	{
		for (count2 = 0; count2 < columns; count2++)
		{
			if (count1 == 0)
				freqs3[count1][count2] = freqs2[count1][count2];
			else
				freqs3[count1][count2] = (freqs3[(count1-1)][count2] + freqs2[count1][count2]);
		}
	}
		
	/*-----------------------------*/
	/* INITIALIZE STRUCTURE	       */
	/*-----------------------------*/
	struct Text1 Names[mc];
	
	/*-----------------------------*/
	/* LOAD DATA INTO STRUCTURE    */
	/*-----------------------------*/
	FILE *fp10;
	char filename10[18] = "outfile_names.txt";

	if((fp10 = fopen(filename10, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename10);
		exit(1);
	}
	
	for (count1 = 0; count1 < mc; count1++)
	{	
		fscanf(fp10, "%s", Names[count1].outname);
	}
	fclose(fp10);
		
	/************************************************/
	/*         BEGIN SIMULATIONS                    */
	/************************************************/
	int count3;
		for (count3 = 0; count3 < mc; count3++)
	{	
		/*----------------------------------------------------------------*/
		/* Seed new random number generator with value from previous list */
		/*----------------------------------------------------------------*/
		int seed2;
		seed2 = iterationseeds[count3];
		
		/*-------------------------------------------*/
		/*    Write random numbers to a new array    */
		/*-------------------------------------------*/
		int randomindividuals[individuals];
		IterationSeed(individuals, seed2, randomindividuals);
				
		/*---------------------------------*/
		/* Make array with new individuals */
		/*---------------------------------*/
		int newindividuals[individuals][columns];
		int count4;
		float rand;
		int e;
		
		for (count1 = 0; count1 < individuals; count1++)
		{
			for (count2 = 0; count2 < columns; count2++)
			{
				/*--------------------------*/
				/*   GET A RANDOM NUMBER    */
				/*--------------------------*/
				e = (randomindividuals[count1] + count2);
				
				rand = Random(e);
				
				for (count4 = 0; count4 < alleles; count4++)
				{	
					if (rand < freqs3[count4][count2])
					{	
						newindividuals[count1][count2] = count4+1;
						break;
					}
				}
			}
		}
		
		/*-----------------------------------------*/
		/* Below is test code for writing a file   */
		/* of the simulated genotypes, to ensure   */
		/* that everything is working all right.   */
		/* It is commented out in the working      */
		/* program.                                */
		/*-----------------------------------------*/
		/*---------------------------------------*/
		/* PRINT INDIVIDUALS TO A NEW FILE       */
		/*---------------------------------------*/
		/*FILE *fp100;
		char filename100[6] = "test1";
		
		if((fp100 = fopen(filename100, "w")) == NULL)
		{
			fprintf(stderr, "Error opening file %s.\n", filename100);
			exit(1);
		}
		
		for (count1 = 0; count1 < individuals; count1++)
		{	
			for (count2 = 0; count2 < columns; count2++)
			{	
				fprintf(fp100, "%d\t", newindividuals[count1][count2]);

			}
		fprintf(fp100, "\n");	
		}
		
		fclose(fp100);*/
		
				
		/*************************************/
		/*   MAKE RESULTS FILE               */
		/*************************************/
		FILE *fp1;
		char *filename1;
		
		filename1 = Names[count3].outname;
				
		if((fp1 = fopen(filename1, "w")) == NULL)
		{
			fprintf(stderr, "Error opening file %s.\n", filename1);
			exit(1);
		}
		
		/*--------------------------------------*/
		/* Write individual ID's across top     */
		/*--------------------------------------*/
		for (count1 = 0; count1 < individuals; count1++)
		{
			fprintf(fp1, "%d", (count1+1));
			
			if (count1 < (individuals-1))
				fprintf(fp1, ",");
			else
				fprintf(fp1, "\n");
		}
		
		/*------------------------------------*/
		/* Read appropriate pair into array   */
		/*------------------------------------*/
		int count5;
		int pair[2][columns];
		
		for (count1 = 0; count1 < individuals; count1++)
		{
			for (count2 = 0; count2 < individuals; count2++)
			{
				for (count5 = 0; count5 < columns; count5++)
				{
					pair[0][count5] = newindividuals[count1][count5];
					pair[1][count5] = newindividuals[count2][count5];
				}
				
				/*****************************************/
				/* CALCULATE ALLELE SHARING FOR THE PAIR */
				/*****************************************/
				int count6, count7;	
				float AS[1][loci];
				float total;
				AlleleSharing(loci, columns, pair, AS);
				
				total = 0;
				
				for (count6 = 0; count6 < 1; count6++)
				{
					for (count7 = 0; count7 < loci; count7++)
					{
						total += AS[count6][count7];
					}
				}
								
				/********************************/
				/* COUNT LOCI NOT TYPED         */
				/********************************/
				int miss[1][loci];
				float missing;
				
				missing = 0;
				
				for (count6 = 0; count6 < 1; count6++)
				{
					for (count7 = 0; count7 < loci; count7++)
					{
						if((pair[count6*2][(count7*2)] == 0) || (pair[(count6*2)+1][(count7*2)] == 0))
							miss[count6][count7] = 1;
						else
							miss[count6][count7] = 0;
						missing += miss[count6][count7];
					}
				}
				
				/*********************************/
				/* CALCULATE PROPSHARED          */
				/*********************************/
				float propshared;
				
				propshared = total/(loci - missing);
				
				/**************************/
				/* PRINT RESULTS TO FILE  */
				/**************************/
				if (count2 < (individuals-1))
					fprintf(fp1, "%f,", propshared);
				else
					fprintf(fp1, "%f\n", propshared);
			}
			
		}
		fclose(fp1);
		
		printf("\nIteration %d", count3+1);
	}	
	
	printf("\n**************************************************************");
	printf("\n Done! Your results have been printed to the outfiles");
	printf("\n**************************************************************\n");
	
	return(0);
}

int Relatedness2(void)
{
	/*******************************************/
	/* Get allele frequency data from the user */
	/*******************************************/
	
 	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int a;  /* Holds the number of alleles in most polymorphic locus */
	int b;  /* Holds the number of loci analyzed */
	int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	a = Alleles();
	b = Loci();
	c = a + 1;
	f = 2 * b;
	
	/*------------------------*/
	/* GET ALLELE FREQUENCIES */
	/*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);
	
	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);
	
	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs3[b][c];
	FreqsColumn_to_Row(b, c, freqs2, freqs3);
	
	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	float var[b];
	Locus_Var(b, c, freqs3, var);
	
	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	float S02[1][b];
	S0_Calc(b, c, freqs3, S02);
	
	/***********************************************************/
	/* GET GENOTYPE DATA FROM USER                             */
	/***********************************************************/
	
	/*----------------------------*/
	/* DEFINE VARIABLES           */
	/*----------------------------*/
	int d;                  /* Holds the number of individuals profiled - for the # of rows in array */
	int e;                  /* Will be (2 x b) to hold the number of columns in genotype file */
	
	/*---------------------------*/
	/* GET DATA FROM USER        */
	/*---------------------------*/
  	d = Genotypes();
	e = (2 * b);
	
	int profiles[d][e];
	
	/*------------------------*/
	/* INITIALIZE STRUCTURE   */
	/*------------------------*/
	struct Text2 Names[d];
	
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
	FILE *fp10;
	char filename10[40];
	int count1, count2;
	
	printf("\nWhat is the name of your genotype file (including extension)? ");
	scanf("%s", filename10);
	
	if((fp10 = fopen(filename10, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename10);
		exit(1);
	}
	
	for (count1 = 0; count1 < d; count1++)
	{
		for (count2 = 0; count2 < (e+1); count2++)
		{
			if (count2 == 0)
				fscanf(fp10, "%s", Names[count1].IndName);
			else
				fscanf(fp10, "%d", &profiles[count1][count2-1]);
		}
	}
	
	fclose(fp10);
	
	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(d, e, profiles);
	
	/**************************************/
	/* GET OUTFILE INFORMATION            */
	/**************************************/
	FILE *fp1;
	char filename1[40];
	
	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename1);
	
	if((fp1 = fopen(filename1, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename1);
		exit(1);
	}
	
	/*--------------------------------------*/
	/* Write individual ID's across top     */
	/*--------------------------------------*/
	for (count1 = 0; count1 < d; count1++)
	{
		fprintf(fp1, "%s", Names[count1].IndName);
		
		if (count1 < (d-1))
			fprintf(fp1, ",");
		else
			fprintf(fp1, "\n");
	}
	
	
	/**********************/
	/* CONDUCT ANALYSES   */
	/**********************/
	
	
	/*----------------------------------*/
	/* READ APPROPRIATE PAIR INTO ARRAY */
	/*----------------------------------*/
	int pair[2][e];
	int count3, count4;
	
	for (count2 = 0; count2 < d; count2++)
	{		
		
		for (count3 = 0; count3 < d; count3++)
		{
			for (count4 = 0; count4 < e; count4++)
			{
				pair[0][count4] = profiles[count2][count4];
				pair[1][count4] = profiles[count3][count4];
			}
			
			/****************************************/
			/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
			/****************************************/
			float weight;
			float weights[1][b];
			weight = 0;
			weight = Locus_Weights(b, e, pair, var, weights);
			
			/*****************************************/
			/* CALCULATE ALLELE SHARING FOR THE PAIR */
			/*****************************************/
			float AS[1][b];
			AlleleSharingRel(b, e, pair, AS);
			
			/*****************************/
			/* CALCULATE RELATEDNESS     */
			/*****************************/
			float rel;
			float rel2;
			rel = 0;
			rel = Relatedness(b, e, weight, pair, AS, S02, weights);
			
			if (rel < 0)
				rel2 = 0;
			else 
				rel2 = rel;

			/*************************/
			/* PRINT RESULTS TO FILE */
			/*************************/
			if (count3 < (d-1))	
				fprintf(fp1, "%f,", rel2);
			else 
				fprintf(fp1, "%f\n", rel2);
			
		}
	}
	
	fclose(fp1);
	
	printf("\n********************************************************\n");
	printf("Done!! Your results have been written to file %s", filename1);
	printf("\n********************************************************\n\n");
	
	return(0);
}

int RelatednessSim(void)
{
	/******************************************/
	/* GET HOW MANY ITERATIONS TO PERFORM     */
	/******************************************/
	int mc;
	mc = Iterations();
	
	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/
	
	/*-----------------------------------------*/
	/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
	/*-----------------------------------------*/
	int seed1;
	seed1 = InitSeed();
	
	/*-------------------------------------------------*/
	/* CREATE ARRAY AND WRITE TO FILE "iterationseeds" */
	/*-------------------------------------------------*/
	int iterationseeds[mc];
	IterationSeed(mc, seed1, iterationseeds);
	
	/**************************************/
	/*     GET DATA FROM THE USER         */
	/**************************************/
	int individuals;
	
	printf("\nHow many individuals do you want to generate? ");
	scanf("%d", &individuals);
	
	/*******************************************/
	/* Get allele frequency data from the user */
	/*******************************************/
	
 	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int a;  /* Holds the number of alleles in most polymorphic locus */
	int b;  /* Holds the number of loci analyzed */
	int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	a = Alleles();
	b = Loci();
	c = a + 1;
	f = 2 * b;
	
	/*------------------------*/
	/* GET ALLELE FREQUENCIES */
	/*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);
	
	/*--------------------------*/
	/* DOUBLE THE ARRAY         */
	/*--------------------------*/
	int count1, count2;
	float freqs2[a][f];
	
	for (count1 = 1; count1 < c; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			freqs2[count1-1][count2*2] = frequencies[count1][count2];
			freqs2[count1-1][(count2*2)+1] = frequencies[count1][count2];
		}
	}
	
	/*-----------------------------*/
	/* MAKE FREQUENCIES CUMULATIVE */
	/*-----------------------------*/
	float freqs3[a][f];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < f; count2++)
		{
			if (count1 == 0)
				freqs3[count1][count2] = freqs2[count1][count2];
			else
				freqs3[count1][count2] = (freqs3[(count1-1)][count2] + freqs2[count1][count2]);
		}
	}
	
	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs5[c][b];
	FreqConvert(c, b, frequencies, freqs5);
	
	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs6[b][c];
	FreqsColumn_to_Row(b, c, freqs5, freqs6);
	
	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	float var[b];
	Locus_Var(b, c, freqs6, var);
	
	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	float S02[1][b];
	S0_Calc(b, c, freqs6, S02);
	
	/*-----------------------------*/
	/* INITIALIZE STRUCTURE	       */
	/*-----------------------------*/
	struct Text1 Names[mc];
	
	/*-----------------------------*/
	/* LOAD DATA INTO STRUCTURE    */
	/*-----------------------------*/
	FILE *fp10;
	char filename10[18] = "outfile_names.txt";
	
	if((fp10 = fopen(filename10, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename10);
		exit(1);
	}
	
	for (count1 = 0; count1 < mc; count1++)
	{	
		fscanf(fp10, "%s", Names[count1].outname);
	}
	fclose(fp10);
	
	/************************************************/
	/*         BEGIN SIMULATIONS                    */
	/************************************************/
	int count3;
	for (count3 = 0; count3 < mc; count3++)
	{	
		/*----------------------------------------------------------------*/
		/* Seed new random number generator with value from previous list */
		/*----------------------------------------------------------------*/
		int seed2;
		seed2 = iterationseeds[count3];
		
		/*-------------------------------------------*/
		/*    Write random numbers to a new array    */
		/*-------------------------------------------*/
		int randomindividuals[individuals];
		IterationSeed(individuals, seed2, randomindividuals);
		
		/*---------------------------------*/
		/* Make array with new individuals */
		/*---------------------------------*/
		int newindividuals[individuals][f];
		int count4;
		float rand;
		int e;
		
		for (count1 = 0; count1 < individuals; count1++)
		{	
			for (count2 = 0; count2 < f; count2++)
			{
				/*--------------------------*/
				/*   GET A RANDOM NUMBER    */
				/*--------------------------*/
				e = (randomindividuals[count1] + count2);
				
				rand = Random(e);
				
				for (count4 = 0; count4 < a; count4++)
				{	
					if (rand < freqs3[count4][count2])
					{	
						newindividuals[count1][count2] = count4+1;
						break;
					}
				}
			}
		}
		
		/*-----------------------------------------*/
		/* Below is test code for writing a file   */
		/* of the simulated genotypes, to ensure   */
		/* that everything is working all right.   */
		/* It is commented out in the working      */
		/* program.                                */
		/*-----------------------------------------*/		
		/*---------------------------------------*/
		/* PRINT INDIVIDUALS TO A NEW FILE       */
		/*---------------------------------------*/
		/*FILE *fp100;
		char filename100[6] = "test2";
		
		if((fp100 = fopen(filename100, "w")) == NULL)
		{
			fprintf(stderr, "Error opening file %s.\n", filename100);
			exit(1);
		}
		
		for (count1 = 0; count1 < individuals; count1++)
		{	
			for (count2 = 0; count2 < f; count2++)
			{	
				fprintf(fp100, "%d", newindividuals[count1][count2]);
				
				if (count2 < (f-1))
					fprintf(fp100, "\t");
				else 
					fprintf(fp100, "\n");
			}
		}
		
		fclose(fp100);*/
		
		/*************************************/
		/*   MAKE RESULTS FILE               */
		/*************************************/
		FILE *fp1;
		char *filename1;
		
		filename1 = Names[count3].outname;
		
		if((fp1 = fopen(filename1, "w")) == NULL)
		{
			fprintf(stderr, "Error opening file %s.\n", filename1);
			exit(1);
		}
		
		/*--------------------------------------*/
		/* Write individual ID's across top     */
		/*--------------------------------------*/
		for (count1 = 0; count1 < individuals; count1++)
		{
			fprintf(fp1, "%d", (count1+1));
			
			if (count1 < (individuals-1))
				fprintf(fp1, ",");
			else
				fprintf(fp1, "\n");
		}
		
		/*------------------------------------*/
		/* Read appropriate pair into array   */
		/*------------------------------------*/
		int count5;
		int pair[2][f];
		
		for (count1 = 0; count1 < individuals; count1++)
		{
			for (count2 = 0; count2 < individuals; count2++)
			{
				for (count5 = 0; count5 < f; count5++)
				{
					pair[0][count5] = newindividuals[count1][count5];
					pair[1][count5] = newindividuals[count2][count5];
				}
				
				/****************************************/
				/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
				/****************************************/
				float weight;
				float weights[1][b];
				weight = 0;
				weight = Locus_Weights(b, f, pair, var, weights);
		
				/*****************************************/
				/* CALCULATE ALLELE SHARING FOR THE PAIR */
				/*****************************************/
				float AS[1][b];
				AlleleSharingRel(b, f, pair, AS);
				
				/*****************************/
				/* CALCULATE RELATEDNESS     */
				/*****************************/
				float rel;
				float rel2;
				rel = 0;
				rel = Relatedness(b, f, weight, pair, AS, S02, weights);
				
				if (rel < 0)
					rel2 = 0;
				else 
					rel2 = rel;
				
				/**************************/
				/* PRINT RESULTS TO FILE  */
				/**************************/
				if (count2 < (individuals-1))
					fprintf(fp1, "%f,", rel2);
				else
					fprintf(fp1, "%f\n", rel2);
			}
			
		}
		fclose(fp1);
		
		printf("\nIteration %d", count3+1);
	}	
	
	printf("\n**************************************************************");
	printf("\n Done! Your results have been printed to the outfiles");
	printf("\n**************************************************************\n");
	
	return(0);
}	

/******************************************************************/
/*                       HELPER FUNCTIONS                         */
/******************************************************************/

int Alleles(void)
/*-----------------------------*/
/* This function asks the user */
/* how many alleles they have  */
/* in the most polymorphic     */
/* locus, and then saves that  */
/* value.                      */
/*-----------------------------*/
{
	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int a;  /* Holds the number of alleles in most polymorphic locus */
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	printf("\nHow many alleles do you have in the most polymorphic locus (not including 0)? ");
	scanf("%d", &a);
	
	return a;
}

void *AlleleSharing(int b, int e, int pair[2][e], float AS[1][b])
/*------------------------------*/
/* This function calculates the */
/* allele sharing between a pair*/
/* of individuals for the       */
/* calculation of relatedness   */
/*------------------------------*/
{
	/*--------------------*/
	/* FIRST COMPARISON   */
	/*--------------------*/
	int sharing[1][e];
	int count5, count6;
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < e; count6++)
		{
			if((pair[count5*2][count6] == 0) || (pair[(count5*2)+1][count6] == 0))
				sharing[count5][count6] = 0;
			else
				if (pair[count5*2][count6] == pair[(count5*2)+1][count6])
					sharing[count5][count6] = 1;
				else
					sharing[count5][count6] = 0;
		}
	}
	
	/*----------------------------------*/
	/* COLLAPSE TO ONE COLUMN PER LOCUS */
	/*----------------------------------*/
	int share1[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			share1[count5][count6] = (sharing[count5][count6*2] + sharing[count5][(count6*2)+1]);
		}
	}
	
	/*-----------------------*/
	/* SECOND COMPARISON     */
	/*-----------------------*/
	int share2[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				share2[count5][count6] = 0;
			else
				if(pair[count5*2][(count6*2)] == pair[(count5*2)+1][(count6*2)+1])
					share2[count5][count6] = 1;
				else
					share2[count5][count6] = 0;
		}
	}
	
	/*---------------------------*/
	/* FOR COMPARISON #3         */
	/*---------------------------*/
	int share3[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				share3[count5][count6] = 0;
			else
				if(pair[count5*2][(count6*2)+1] == pair[(count5*2)+1][(count6*2)])
					share3[count5][count6] = 1;
				else
					share3[count5][count6] = 0;
		}
	}
	
	/*--------------------------------*/
	/* COMBINE TO ONE VALUE PER LOCUS */
	/*--------------------------------*/
	float share4[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				share4[count5][count6] = 0;
			else
				share4[count5][count6] = (share1[count5][count6] + share2[count5][count6] + share3[count5][count6]);
		}
	}
	
	/********************************************************/
	/* ASSESS IF INDIVIDUALS ARE HOMOZYGOUS OR HETEROZYGOUS */
	/********************************************************/
	
	/*-----------------------------------*/
	/* HOMOZYGOTE OR HETEROZYGOTE        */
	/*-----------------------------------*/
	float homo[2][b];
	
	for (count5 = 0; count5 < 2; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if(pair[count5][(count6*2)] == 0)
				homo[count5][count6] = 0;
			else
				if(pair[count5][(count6*2)] == pair[count5][(count6*2)+1])
					homo[count5][count6] = 1;
				else
					homo[count5][count6] = 0;
		}
	}
	
	float hetero[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				hetero[count5][count6] = 0;	
			else
				hetero[count5][count6] = (homo[count5*2][count6] + homo[(count5*2)+1][count6]);
		}
	}	
	
	/********************/
	/* CALCULATE AS     */
	/********************/
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				AS[count5][count6] = 0;
			else
				if(share4[count5][count6] == 4)
					AS[count5][count6] = 1;
				else	
					if((share4[count5][count6] == 2) && (hetero[count5][count6] == 0))
						AS[count5][count6] = 1;
					else
						if((share4[count5][count6] == 2) && (hetero[count5][count6] == 1))
							AS[count5][count6] = 0.5;
						else
							if(share4[count5][count6] == 1)
								AS[count5][count6] = 0.5;
							else
								AS[count5][count6] = 0;
		}
	}
	return(0);
}

void *AlleleSharingRel(int b, int e, int pair[2][e], float AS[1][b])
/*------------------------------*/
/* This function calculates the */
/* allele sharing between a pair*/
/* of individuals for the       */
/* calculation of relatedness   */
/*------------------------------*/
{
	/*--------------------*/
	/* FIRST COMPARISON   */
	/*--------------------*/
	int sharing[1][e];
	int count5, count6;
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < e; count6++)
		{
			if((pair[count5*2][count6] == 0) || (pair[(count5*2)+1][count6] == 0))
				sharing[count5][count6] = 0;
			else
				if (pair[count5*2][count6] == pair[(count5*2)+1][count6])
					sharing[count5][count6] = 1;
				else
					sharing[count5][count6] = 0;
		}
	}
	
	/*----------------------------------*/
	/* COLLAPSE TO ONE COLUMN PER LOCUS */
	/*----------------------------------*/
	int share1[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			share1[count5][count6] = (sharing[count5][count6*2] + sharing[count5][(count6*2)+1]);
		}
	}
	
	/*-----------------------*/
	/* SECOND COMPARISON     */
	/*-----------------------*/
	int share2[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				share2[count5][count6] = 0;
			else
				if(pair[count5*2][(count6*2)] == pair[(count5*2)+1][(count6*2)+1])
					share2[count5][count6] = 1;
				else
					share2[count5][count6] = 0;
		}
	}
	
	/*---------------------------*/
	/* FOR COMPARISON #3         */
	/*---------------------------*/
	int share3[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				share3[count5][count6] = 0;
			else
				if(pair[count5*2][(count6*2)+1] == pair[(count5*2)+1][(count6*2)])
					share3[count5][count6] = 1;
				else
					share3[count5][count6] = 0;
		}
	}
	
	/*--------------------------------*/
	/* COMBINE TO ONE VALUE PER LOCUS */
	/*--------------------------------*/
	float share4[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				share4[count5][count6] = 0;
			else
				share4[count5][count6] = (share1[count5][count6] + share2[count5][count6] + share3[count5][count6]);
		}
	}
	
	/********************************************************/
	/* ASSESS IF INDIVIDUALS ARE HOMOZYGOUS OR HETEROZYGOUS */
	/********************************************************/
	
	/*-----------------------------------*/
	/* HOMOZYGOTE OR HETEROZYGOTE        */
	/*-----------------------------------*/
	float homo[2][b];
	
	for (count5 = 0; count5 < 2; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if(pair[count5][(count6*2)] == 0)
				homo[count5][count6] = 0;
			else
				if(pair[count5][(count6*2)] == pair[count5][(count6*2)+1])
					homo[count5][count6] = 1;
				else
					homo[count5][count6] = 0;
		}
	}
	
	float hetero[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				hetero[count5][count6] = 0;	
			else
				hetero[count5][count6] = (homo[count5*2][count6] + homo[(count5*2)+1][count6]);
		}
	}	
	
	/********************/
	/* CALCULATE AS     */
	/********************/
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				AS[count5][count6] = 0;
			else
				if(share4[count5][count6] == 4)
					AS[count5][count6] = 1;
				else	
					if((share4[count5][count6] == 2) && (hetero[count5][count6] == 0))
						AS[count5][count6] = 1;
					else
						if((share4[count5][count6] == 2) && (hetero[count5][count6] == 1))
							AS[count5][count6] = 0.75;
						else
							if(share4[count5][count6] == 1)
								AS[count5][count6] = 0.5;
							else
								AS[count5][count6] = 0;
		}
	}
	return(0);
}

void clear_kb(void)
/* Clears stdin of any waiting characters */
{
	char junk[80];
	fgets(junk,80,stdin);
}

void *FreqConvert(int c, int b, float frequencies[c][b], float freqs2[c][b])
/*----------------------------*/
/* This function converts the */
/* integers in an allele      */
/* frequency file to zeros.   */
/*----------------------------*/
{
	int count1, count2;
	
	for (count1 = 0; count1 < c; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (frequencies[count1][count2] < 1)
				freqs2[count1][count2] = frequencies[count1][count2];
			else
				freqs2[count1][count2] = 0;
		}
	}
	return(0);
}

void *FreqsColumn_to_Row(int b, int c, float freqs3[c][b], float freqs4[b][c])
/*------------------------------------*/
/* This function reads the "freqs3"   */
/* array and converts the columns     */
/* to rows.                           */
/*------------------------------------*/
{
	/*--------------------------*/
	/* CONVERT COLUMNS TO ROWS  */
	/*--------------------------*/
	int count1, count2;
	
	for (count1 = 0; count1 < b; count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			freqs4[count1][count2] = freqs3[count2][count1];
		}
	}
	return(0);
}

void *Frequencies(int c, int b, float frequencies[c][b])
/*------------------------------*/
/* This function asks the user  */
/* the name of their allele     */
/* frequency file, and then     */
/* reads that into an array     */
/* named frequencies and then   */
/* writes it to a file named    */
/* freqs.                       */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
	FILE *fp1;
	char filename1[40];
	int count1, count2;
	
	printf("\nWhat is the name of your allele frequency file (including extension)? ");
	scanf("%s", filename1);
	
	if((fp1 = fopen(filename1, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename1);
		exit(1);
	}
	
	for (count1 = 0; count1 < c; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			fscanf(fp1, "%f", &frequencies[count1][count2]);
		}
	}
	
	fclose(fp1);
	
	return(0);
}

int Genotypes(void)
/*-----------------------------*/
/* This function asks the user */
/* how many individuals they   */
/* have in their genotype file */
/* and then returns that value */
/*-----------------------------*/
{
	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int a;  /* Holds the number of individuals in their genotype file */
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	printf("\nHow many individuals do you have in your genotype file? ");
	scanf("%d", &a);
	
	return a;
}

int InitSeed(void)
/*------------------------------------*/
/* This function generates a seed for */
/* the random number generator based  */
/* on the computer clock.             */
/*------------------------------------*/
{
	int seed;
	time_t  nowtime;
	struct tm*preztime;
	
	time(&nowtime);
	preztime = localtime(&nowtime);
	seed = (int)((preztime->tm_sec+1)*(preztime->tm_min+1)*(preztime->tm_hour+1)*(preztime->tm_year)*(preztime->tm_year));
	if(seed%2==0) seed++;
	
	return seed;
}

int Iterations(void)
/*-----------------------------*/
/* This function asks the user */
/* how many iterations they    */
/* would like to perform, and  */
/* then saves that value.      */
/*-----------------------------*/
{
	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int a;  
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	printf("\nHow many iterations do you want to perform (e.g. 1000)? ");
	scanf("%d", &a);
	
	return a;
}

void *IterationSeed(int y, int z, int iterationseeds[y])
/*------------------------------*/
/* This function creates a list */
/* of random numbers, one for   */
/* each iteration that the user */
/* wants to perform, that will  */
/* serve as the seed for the    */
/* other random number          */
/* generators within that       */
/* iteration.  These numbers are*/
/* written to an array called    */
/* "iterationseeds".            */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
	int count1;
	
	/*--------------------------------*/
	/* CREAT ARRAY OF RANDOM NUMBERS  */
	/*--------------------------------*/
	const gsl_rng_type * TT;
	gsl_rng * rr;
	
	gsl_rng_env_setup();
	
	TT = gsl_rng_mt19937;
	rr = gsl_rng_alloc (TT);
	gsl_rng_set(rr, z);
	
	for (count1 = 0; count1 < y; count1++)
	{
		iterationseeds[count1] = gsl_rng_uniform_pos(rr) * z;
	}
	
	gsl_rng_free(rr);
	
	return(0);
}

int Loci(void)
/*-----------------------------*/
/* This function asks the user */
/* how many loci they used and */
/* saves that  value.          */
/*-----------------------------*/
{
	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int a;  /* Holds the number of loci used */
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	printf("\nHow many loci did you use? ");
	scanf("%d", &a);
	
	return a;
}

void *Locus_Var(int b, int c, float freqs3[b][c], float var[b])
/*-------------------------------*/
/* This function sums the number */
/* of alleles present in each    */
/* locus.                        */
/*-------------------------------*/
{
	int x, w, count1, count2;
	
	for (count1 = 0; count1 < b; count1++)
	{
		x = 0;	
		w = 0;	
		for (count2 = 0; count2 < c; count2++)
		{
			if (freqs3[count1][count2] == 0)
				w = 0;
			else
				w = 1;
			x += w;
		}
		var[count1] = x;	
	}
	return(0);
}

float Locus_Weights(int b, int e, int pair[2][e], float var[b], float weights[1][b])
/*------------------------------*/
/* This function calculates the */
/* weight to be given to each   */
/* locus for relatedness        */
/* calculation.                 */
/*------------------------------*/
{
	/*--------------------------------------------------------*/
	/* CALCULATE WEIGHTS FOR EACH LOCUS PROFILED IN EACH PAIR */
	/*--------------------------------------------------------*/
	
	float w1[1][b];
	int count5, count6;
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				w1[count5][count6] = 0;
			else
				w1[count5][count6] = var[count6];
		}
	}
	
	/*----------------------------------------------*/
	/* CALCULATE THE WEIGHT FOR EACH COMPARED LOCUS */
	/*----------------------------------------------*/
	float w2[1][1];
	float yy, xx;
	yy = 0;
	xx = 0;
	
	for (count5 = 0; count5 < 1; count5++)
	{
		xx = 0;
		yy = 0;		
		for (count6 = 0; count6 < b; count6++)
		{
			yy = w1[count5][count6];
			xx += yy;
		}
		w2[count5][0] = xx;
	}
	
	/*-------------------*/
	/* CALCULATE WEIGHTS */
	/*-------------------*/
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if(w1[count5][count6] == 0)
				weights[count5][count6] = 0;
			else
				weights[count5][count6] = (((w1[count5][count6])-1)/(((w2[count5][0])-1)));
		}
	}
	
	/*------------------------*/
	/* COMBINE WEIGHTS        */
	/*------------------------*/
	float aaa;
	float w3;
	aaa = 0;
	w3 = 0;
	
	for (count5 = 0; count5 < 1; count5++)
	{
		aaa = 0;
		for (count6 = 0; count6 < b; count6++)
		{
			aaa += weights[count5][count6];
		}
		w3 += aaa;
	}
	return w3;
}

void Partials(int d, int e, int profiles[d][e])
/*---------------------------------*/
/* This function goes through the  */
/* genotype file and ensures that  */
/* if one allele is missing at a   */
/* locus, then both alleles are    */
/* coded as "0". Genotypes must be */
/* all or none at each locus for   */
/* these analyses.                 */
/*---------------------------------*/
{
	int count1, count2;
	
	for (count1 = 0; count1 < d; count1++)
	{
		for(count2 = 0; count2 < e; count2+=2)
		{
			if (profiles[count1][count2] == 0)
				profiles[count1][count2+1] = 0;
			else
				if (profiles[count1][count2+1] == 0)
					profiles[count1][count2] = 0;
		}
	}
}
	
float Random(int e)
/*----------------------------------*/
/* This function generates a random */
/* number between 0 and 1.          */
/*----------------------------------*/
{
	float a;
	const gsl_rng_type * TTT;
		
	gsl_rng * rrr;
		
	/*------------------------------------*/
	/* CREAT ARRAY OF RANDOM NUMBERS      */
	/*------------------------------------*/
	gsl_rng_env_setup();
		
	TTT = gsl_rng_mt19937;
	rrr = gsl_rng_alloc (TTT);
	gsl_rng_set(rrr, e);
		
	a = gsl_rng_uniform_pos(rrr);
		
	gsl_rng_free(rrr);
		
	return(a);
}
	
float Relatedness(int b, int e, float weight, int pair[2][e], float AS[1][b], float S02[1][b], float weights[1][b])
/*-----------------------------*/
/* This function takes other   */
/* data and calculates the     */
/* relatedness for a pair of   */
/* individuals.                */
/*-----------------------------*/
{
	/*----------------------------------*/
	/* CALCULATE RELATEDNESS_1         */
	/*----------------------------------*/
	float rel1[1][b];
	int count5, count6;
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				rel1[count5][count6] = 0;
			else
				rel1[count5][count6] = ((AS[count5][count6] - S02[0][count6])/(1-S02[0][count6]));
		}
	}
	
	/*------------------------------------------*/
	/* CALCULATE THE WEIGHTED RELATEDNESS VALUE */
	/*------------------------------------------*/
	float rel2[1][b];
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)] == 0) || (pair[(count5*2)+1][(count6*2)] == 0))
				rel2[count5][count6] = 0;
			else
				rel2[count5][count6] = ((rel1[count5][count6])*(weights[count5][count6]));
		}
	}
	
	/*--------------------------------*/
	/* CALCULATE RELATEDNESS VALUE    */
	/*--------------------------------*/
	float rel3;
	float q, s;
	
	for (count5 = 0; count5 < 1; count5++)
	{
		q = 0;
		s = 0;
		for (count6 = 0; count6 < b; count6++)
		{
			q = rel2[count5][count6];
			s += q;
		}
		rel3 = s/weight;
	}
	return rel3;
}

void *S0_Calc(int b, int c, float freqs3[b][c], float S02[1][b])
/*-------------------------------*/
/* This function calculates the  */
/* S0 for each locus, as needed  */
/* for calculating relatedness.  */
/*-------------------------------*/
{
	int count1, count2;
	float S01[b][c];
	
	for (count1 = 0; count1 < b; count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			S01[count1][count2] = ((freqs3[count1][count2] * freqs3[count1][count2])*(2-freqs3[count1][count2]));
		}
	}
	
	/*------------------------------*/
	/* SUM ACROSS ALLELES           */
	/*------------------------------*/
	float y,z;
	
	for (count1 = 0; count1 < b; count1++)
	{
		y = 0;	
		z = 0;	
		for (count2 = 0; count2 < c; count2++)
		{
			z = S01[count1][count2];
			y += z;			
		}
		S02[0][count1] = y;	
	}	
	
	return(0);
}
