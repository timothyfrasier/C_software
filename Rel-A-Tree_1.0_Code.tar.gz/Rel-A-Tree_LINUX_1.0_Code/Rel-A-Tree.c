/*--------------------------------Rel-A-Tree.c---------------------------------------*/
/* This program calculates pairwise relatedness values for a set of individuals, and */
/* then formats those data in a manner that can be read by PHYLIP, which can be used */
/* to create a UPGMA tree based on the relatedness values.                           */
/*										     */
/* Copyright (C) 2009 Tim Frasier                                                    */
/*                                                                                   */
/* This program is free software; you can redistribute it and/or modify it under the */
/* terms of the GNU General Public License as published by the Free Software         */
/* Foundation; either version 2 of the License, or (at your option) any later        */
/* version.                                                                          */
/*                                                                                   */
/* This program is distributed in the hope that it will be useful, but WITHOUT ANY   */
/* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A   */
/* PARTICULAR PURPOSE.  See the GNU Public License for more details.                 */
/* (http://www.gnu.org/licenses/gpl.html)                                            */
/*-----------------------------------------------------------------------------------*/

/*-----------------------*/
/* INCLUDED FILES        */
/*-----------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

/*----------------------*/
/* INCLUDED FUNCTIONS   */
/*----------------------*/
int Alleles(void);
void Bootstrap(int b, int seed2);
void FreqsColumn_to_Row(int b, int c);
void Frequencies(int a, int b);
int Genotypes(void);
int InitSeed(void);
void IterationSeed(int y, int z);
int Loci(void);
void Locus_Var(int b, int c);
void *Mendel(int mm, int nn, int oo, int mendel[mm][nn]);
void Partials(int g, int h);
float Random(int e);
void S0_Calc(int b, int c);
int Seed2(int aa, int bb);
int Sim(void);
void UserGenotypes(int e, int f);
int get_menu_choice(void);
int Rel_Dist(void);
int Rel(void);

/*-----------------------*/
/* START OF PROGRAM      */
/*-----------------------*/
int main(void)
{
	/*-------------------------*/
	/* PRINT WELCOME SCREEN    */
	/*-------------------------*/
	printf("\n\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	printf("\n\t\t    Welcome to REL-A-TREE\n");
	printf("\n\t\t           ver. 1.0\n");
	printf("\n\t\t\tby Tim Frasier\n");
	printf("\n\t\t   Last updated: 15-JUL-2009");
	printf("\n\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");

	/*---------------------------*/
	/* PRINT MENU AND GET CHOICE */
	/*---------------------------*/
	int choice;

	choice = get_menu_choice();

	if (choice == 1)
		Rel();
	else
		if(choice ==2)
			Rel_Dist();
		else
			if(choice == 3)
				Sim();

	printf("\n");

	return(0);
}

int get_menu_choice(void)
{
	int selection = 0;

	do
	{
		printf("\n*******************************MENU*************************************\n");
		printf("\nWhat would you like to do?\n");
		printf("\nCalculate pairwise relatedness.......................................1\n");
		printf("\nCalculate pairwise relatedness as a distance matrix..................2\n");
		printf("\nGenerate a simulated dataset with individuals of known relatedness...3\n");
		printf("\nQUIT.................................................................4\n"); 
		printf("\n************************************************************************\n");
		printf("\n");

		printf("\nWhat would you like to do? ");	
		scanf("%d", &selection);

	} while (selection < 1 || selection > 4);

	return selection;
}

int Rel_Dist(void)
{
        /*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	        /*------------------*/
        	/* DEFINE VARIABLES */
        	/*------------------*/
        	int a;  /* Holds the number of alleles in most polymorphic locus */
        	int b;  /* Holds the number of loci analyzed */
        	int c;  /* Will be a + 1, which will be the # of rows in the array */
	
        	/*----------------------*/
        	/* GET DATA FROM USER   */
        	/*----------------------*/
        	a = Alleles();
		b = Loci();
        	c = a + 1;

        	/*------------------------*/
        	/* GET ALLELE FREQUENCIES */
        	/*------------------------*/
		Frequencies(c, b);

	/*--------------------------*/
	/* CONVERT COLUMNS TO ROWS  */
	/*--------------------------*/
	FreqsColumn_to_Row(b, c);

	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	Locus_Var(b, c);

	/*----------------------------------*/
	/* SCAN "locusvar" INTO ARRAY "var" */
	/*----------------------------------*/
	FILE *fp3;
	char filename3[9] = "locusvar";
	float var[1][b];
	int count5;
	
   	if((fp3 = fopen(filename3, "r")) == NULL)
  	{
  		fprintf(stderr, "Error opening file %s.\n", filename3);
   	 	exit(1);
  	}
	
        for (count5 = 0; count5 < b; count5++)
        {
		fscanf(fp3, "%f", &var[0][count5]);
        }
	
        fclose(fp3);
	remove(filename3);

	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	S0_Calc(b, c);

	/*----------------------------------*/
	/* SCAN "S0_Data" INTO ARRAY "S0" */
	/*----------------------------------*/
	FILE *fp5;
	char filename5[8] = "S0_data";
	float S0[1][b];
	int count6;
	
   	if((fp5 = fopen(filename5, "r")) == NULL)
  	{
  		fprintf(stderr, "Error opening file %s.\n", filename5);
   	 	exit(1);
  	}
	
        for (count5 = 0; count5 < 1; count5++)
        {
		for (count6 = 0; count6 < b; count6++)
		{
			fscanf(fp5, "%f", &S0[count5][count6]);
        	}
	}
	
        fclose(fp5);
	remove(filename5);


        /***********************************************************/
        /* GET GENOTYPE DATA FROM USER                             */
        /***********************************************************/

	        /*----------------------------*/
        	/* DEFINE VARIABLES           */
        	/*----------------------------*/
        	int d;                  /* Holds the number of individuals profiled - for the # of rows in array */
        	int e;                  /* Will be (2 x b) +1 to hold the number of columns in genotype file */
 
		/*----------------------------*/
		/* GET DATA FROM USER         */
		/*----------------------------*/
		d = Genotypes();
        	e = (2 * b) + 1;

		UserGenotypes(d, e);

	/*********************************/
	/* DEAL WITH PARTIAL PROFILES    */
	/*********************************/
	Partials(d, e);

	/*--------------------------------------*/
	/* WRITE GENOTYPES TO ARRAY "Genotypes" */
	/*--------------------------------------*/
       	FILE *fp2;
        char filename2[15] = "usergenotypes2";
        int count1, count2;
	int Genotypes[d][e];

        if((fp2 = fopen(filename2, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename2);
                exit(1);
        }

        for (count1 = 0; count1 < d; count1++)
        {
                for (count2 = 0; count2 < e; count2++)
                {
                        fscanf(fp2, "%d", &Genotypes[count1][count2]);
                }
        }

        fclose(fp2);
	remove(filename2);

	/*--------------------------------*/
	/* NUMBER OF PAIRWISE COMPARISONS */
	/*--------------------------------*/
	int f;
	f = (d*(d-1))/2;

	/*----------------------*/
	/* NUMBER OF BOOTSTRAPS */
	/*----------------------*/
	int g;
	printf("\nHow many times do you want to bootstrap your data? ");
	scanf("%d", &g);

	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/

		/*-----------------------------------------*/
		/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
		/*-----------------------------------------*/
		int seed1;
		seed1 = InitSeed();

		/*-------------------------------------------------*/
		/* CREATE ARRAY AND WRITE TO FILE "iterationseeds" */
		/*-------------------------------------------------*/
		IterationSeed(g, seed1);

	/*******************************/
	/* MAKE RESULTS FILE           */
	/*******************************/
	FILE *fp20;
	char filename20[14] = "Rel_Distances";

        if((fp20 = fopen(filename20, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename20);
                exit(1);
        }

	/**************************/
	/* CONDUCT ANALYSES       */
	/**************************/

	for (count1 = 0; count1 < g; count1++)
	{
		fprintf(fp20, "%d\n", d);
		/*-----------------------------------*/
		/* GET A NEW SEED FOR EACH ITERATION */
		/*-----------------------------------*/
		int seed2;
		seed2 = Seed2(count1, g);

		/*----------------*/
		/* BOOTSTRAP LOCI */
		/*----------------*/
		Bootstrap(b, seed2);

		/*-----------------------------*/
		/* WRITE DATA TO ARRAY "Strap" */
		/*-----------------------------*/
        	FILE *fp1;
       	 	char filename1[6] = "strap";
		int Strap[b];
		int count2;

 	       	if((fp1 = fopen(filename1, "r")) == NULL)
        	{
        	        fprintf(stderr, "Error opening file %s.\n", filename1);
        	        exit(1);
        	}

        	for (count2 = 0; count2 < b; count2++)
        	{
        		fscanf(fp1, "%d", &Strap[count2]);
        	}

        	fclose(fp1);

		remove(filename1);

		/*----------------*/
		/* DOUBLE ARRAY   */
		/*----------------*/
		int Strap2[(2*b)+1];
		int bb;

		Strap2[0] = 0;
		bb = 1;

		for (count2 = 1; count2 < ((2*b)+1); count2 += 2)
		{
			Strap2[count2] = ((Strap[count2-bb]*2)-1);
			Strap2[count2+1] = ((Strap[count2-bb])*2);
		bb += 1;
		}

		/*----------------------------------*/
		/* READ APPROPRIATE PAIR INTO ARRAY */
		/*----------------------------------*/
		int pair[2][e];
		int count3, count4;
		int columns;

		columns = 0;

		for (count2 = 0; count2 < d; count2++)
		{
			fprintf(fp20, "%d ", Genotypes[count2][0]);
			
			int holder;
			for (holder = (d - count2); holder < d; holder++)
			{
				if (columns < 8)
				{
					fprintf(fp20, " ");
					columns +=1;
				}
				else
				{
					fprintf(fp20, "\n");
					columns = 1;
					fprintf(fp20, " ");
				}
			}

			if (columns < 8)
			{
				fprintf(fp20," ");
				columns += 1;
			}
			else
			{
				fprintf(fp20, "\n");
				columns = 1;
				fprintf(fp20, " ");
			}	

			for (count3 = (count2+1); count3 < d; count3++)
			{
				for (count4 = 0; count4 < e; count4++)
				{
					pair[0][count4] = Genotypes[count2][Strap2[count4]];
					pair[1][count4] = Genotypes[count3][Strap2[count4]];
				}

				/****************************************/
				/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
				/****************************************/

					/*-----------------------------*/
					/* BOOTSTRAP LOCUSVAR DATA     */
					/*-----------------------------*/
					float var2[1][b];

					for (count5 = 0; count5 < b; count5++)
					{
						var2[0][count5] = var[0][(Strap[count5]-1)];
					}

					/*--------------------------------------------------------*/
					/* CALCULATE WEIGHTS FOR EACH LOCUS PROFILED IN EACH PAIR */
					/*--------------------------------------------------------*/
					float w1[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								w1[count5][count6] = 0;
							else
								w1[count5][count6] = var2[0][count6];
						}
					}

					/*----------------------------------------------*/
					/* CALCULATE THE WEIGHT FOR EACH COMPARED LOCUS */
					/*----------------------------------------------*/
					float w2[1][1];
					float yy, xx;

					for (count5 = 0; count5 < 1; count5++)
					{
						xx = 0;
						yy = 0;		
						for (count6 = 0; count6 < b; count6++)
						{
							yy = w1[count5][count6];
							xx += yy;
						}
					w2[count5][0] = xx;
					}

					/*-------------------*/
					/* CALCULATE WEIGHTS */
					/*-------------------*/
					float weight[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if(w1[count5][count6] == 0)
								weight[count5][count6] = 0;
							else
								weight[count5][count6] = (((w1[count5][count6])-1)/(((w2[count5][0])-1)));
						}
					}

					/*------------------------*/
					/* COMBINE WEIGHTS        */
					/*------------------------*/
					float aaa;
					float w3[1];

					for (count5 = 0; count5 < 1; count5++)
					{
						aaa = 0;
						for (count6 = 0; count6 < b; count6++)
						{
							aaa += weight[count5][count6];
						}
					w3[count5] = aaa;
					}

				/************************/
				/* BOOTSTRAP S0_DATA    */
				/************************/
				float S02[1][b];

				for (count5 = 0; count5 < b; count5++)
				{
					S02[0][count5] = S0[0][(Strap[count5]-1)];
				}

				/*****************************************/
				/* CALCULATE ALLELE SHARING FOR THE PAIR */
				/*****************************************/

					/*--------------------*/
					/* FIRST COMPARISON   */
					/*--------------------*/
					int sharing[1][e-1];
	
					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < (e-1); count6++)
						{
							if((pair[count5*2][count6+1] == 0) || (pair[(count5*2)+1][count6+1] == 0))
								sharing[count5][count6] = 0;
							else
								if (pair[count5*2][count6+1] == pair[(count5*2)+1][count6+1])
									sharing[count5][count6] = 1;
								else
									sharing[count5][count6] = 0;
						}
					}

					/*----------------------------------*/
					/* COLLAPSE TO ONE COLUMN PER LOCUS */
					/*----------------------------------*/
					int share1[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							share1[count5][count6] = (sharing[count5][count6*2] + sharing[count5][(count6*2)+1]);
						}
					}

					/*-----------------------*/
					/* SECOND COMPARISON     */
					/*-----------------------*/
					int share2[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								share2[count5][count6] = 0;
							else
								if(pair[count5*2][(count6*2)+1] == pair[(count5*2)+1][(count6*2)+2])
									share2[count5][count6] = 1;
								else
									share2[count5][count6] = 0;
						}
					}

					/*---------------------------*/
					/* FOR COMPARISON #3         */
					/*---------------------------*/
					int share3[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								share3[count5][count6] = 0;
							else
								if(pair[count5*2][(count6*2)+2] == pair[(count5*2)+1][(count6*2)+1])
									share3[count5][count6] = 1;
								else
									share3[count5][count6] = 0;
						}
					}

					/*--------------------------------*/
					/* COMBINE TO ONE VALUE PER LOCUS */
					/*--------------------------------*/
					float share4[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								share4[count5][count6] = 0;
							else
								share4[count5][count6] = (share1[count5][count6] + share2[count5][count6] + share3[count5][count6]);
						}
					}
				
				/********************************************************/
				/* ASSESS IF INDIVIDUALS ARE HOMOZYGOUS OR HETEROZYGOUS */
				/********************************************************/

					/*-----------------------------------*/
					/* HOMOZYGOTE OR HETEROZYGOTE        */
					/*-----------------------------------*/
					float homo[2][b];

					for (count5 = 0; count5 < 2; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if(pair[count5][(count6*2)+1] == 0)
								homo[count5][count6] = 0;
							else
								if(pair[count5][(count6*2)+1] == pair[count5][(count6*2)+2])
									homo[count5][count6] = 1;
								else
									homo[count5][count6] = 0;
						}
					}

					float hetero[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								hetero[count5][count6] = 0;	
							else
								hetero[count5][count6] = (homo[count5*2][count6] + homo[(count5*2)+1][count6]);
						}
					}	

				/********************/
				/* CALCULATE AS     */
				/********************/
				float AS[1][b];

				for (count5 = 0; count5 < 1; count5++)
				{
					for (count6 = 0; count6 < b; count6++)
					{
						if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
							AS[count5][count6] = 0;
						else
							if(share4[count5][count6] == 4)
								AS[count5][count6] = 1;
							else	
								if((share4[count5][count6] == 2) && (hetero[count5][count6] == 0))
									AS[count5][count6] = 1;
								else
									if((share4[count5][count6] == 2) && (hetero[count5][count6] == 1))
										AS[count5][count6] = 0.75;
									else
										if(share4[count5][count6] == 1)
											AS[count5][count6] = 0.5;
										else
											AS[count5][count6] = 0;
					}
				}

				/*****************************/
				/* CALCULATE RELATEDNESS     */
				/*****************************/

					/*----------------------------------*/
					/* CALCULATE RELATEDNESS_1         */
					/*----------------------------------*/
					float rel1[1][b];
	
					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								rel1[count5][count6] = 0;
							else
								rel1[count5][count6] = ((AS[count5][count6] - S02[0][count6])/(1-S02[0][count6]));
						}
					}

					/*------------------------------------------*/
					/* CALCULATE THE WEIGHTED RELATEDNESS VALUE */
					/*------------------------------------------*/
					float rel2[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								rel2[count5][count6] = 0;
							else
								rel2[count5][count6] = ((rel1[count5][count6])*(weight[count5][count6]));
						}
					}
	
					/*--------------------------------*/
					/* CALCULATE RELATEDNESS VALUE    */
					/*--------------------------------*/
					float rel3[1][1];
					float q, s;

					for (count5 = 0; count5 < 1; count5++)
					{
						q = 0;
						s = 0;
						for (count6 = 0; count6 < b; count6++)
						{
							q = rel2[count5][count6];
							s += q;
						}
					rel3[count5][0] = s/w3[count5];
					}
				
				/*****************************/
				/* CONVERT TO DISTANCE       */
				/*****************************/
				float dist;

				if (rel3[0][0] < -1)
					dist = 1;
				else
					if (rel3[0][0] > 1)
						dist = 0;
					else
						dist = (1 - ((rel3[0][0]+1)/2));

				/*************************/
				/* PRINT RESULTS TO FILE */
				/*************************/
				if (columns < 8)
				{
					fprintf(fp20, "%f ", dist);
					columns += 1;
				}
				else
				{
					fprintf(fp20, "\n");
					columns = 1;
					fprintf(fp20, "%f ", dist);		
				}
			}
		fprintf(fp20, "\n");
		columns = 0;
		}
	fprintf(fp20, "\n");
	columns = 0;

	printf("\nBootstrap #%d", count1+1);

	}

	fclose(fp20);

	/*------------------------*/
	/* CLEAN UP FILES         */
	/*------------------------*/
	char filename50[7] = "freqs2";
	char filename51[15] = "iterationseeds";

	remove(filename50);
	remove(filename51);

	printf("\n**************************************************************");
	printf("\n Done! Your results have been printed to file 'Rel_Distances'.");
	printf("\n**************************************************************\n");

	
	return(0);

}

int Rel(void)
{
        /*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	        /*------------------*/
        	/* DEFINE VARIABLES */
        	/*------------------*/
        	int a;  /* Holds the number of alleles in most polymorphic locus */
        	int b;  /* Holds the number of loci analyzed */
        	int c;  /* Will be a + 1, which will be the # of rows in the array */
	
        	/*----------------------*/
        	/* GET DATA FROM USER   */
        	/*----------------------*/
        	a = Alleles();
		b = Loci();
        	c = a + 1;

        	/*------------------------*/
        	/* GET ALLELE FREQUENCIES */
        	/*------------------------*/
		Frequencies(c, b);

	/*--------------------------*/
	/* CONVERT COLUMNS TO ROWS  */
	/*--------------------------*/
	FreqsColumn_to_Row(b, c);

	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	Locus_Var(b, c);

	/*----------------------------------*/
	/* SCAN "locusvar" INTO ARRAY "var" */
	/*----------------------------------*/
	FILE *fp3;
	char filename3[9] = "locusvar";
	float var[1][b];
	int count5;
	
   	if((fp3 = fopen(filename3, "r")) == NULL)
  	{
  		fprintf(stderr, "Error opening file %s.\n", filename3);
   	 	exit(1);
  	}
	
        for (count5 = 0; count5 < b; count5++)
        {
		fscanf(fp3, "%f", &var[0][count5]);
        }
	
        fclose(fp3);
	remove(filename3);

	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	S0_Calc(b, c);

	/*----------------------------------*/
	/* SCAN "S0_Data" INTO ARRAY "S0" */
	/*----------------------------------*/
	FILE *fp5;
	char filename5[8] = "S0_data";
	float S0[1][b];
	int count6;
	
   	if((fp5 = fopen(filename5, "r")) == NULL)
  	{
  		fprintf(stderr, "Error opening file %s.\n", filename5);
   	 	exit(1);
  	}
	
        for (count5 = 0; count5 < 1; count5++)
        {
		for (count6 = 0; count6 < b; count6++)
		{
			fscanf(fp5, "%f", &S0[count5][count6]);
        	}
	}
	
        fclose(fp5);
	remove(filename5);


        /***********************************************************/
        /* GET GENOTYPE DATA FROM USER                             */
        /***********************************************************/

	        /*----------------------------*/
        	/* DEFINE VARIABLES           */
        	/*----------------------------*/
        	int d;                  /* Holds the number of individuals profiled - for the # of rows in array */
        	int e;                  /* Will be (2 x b) +1 to hold the number of columns in genotype file */
 
		/*----------------------------*/
		/* GET DATA FROM USER         */
		/*----------------------------*/
		d = Genotypes();
        	e = (2 * b) + 1;

		UserGenotypes(d, e);

	/*********************************/
	/* DEAL WITH PARTIAL PROFILES    */
	/*********************************/
	Partials(d, e);

	/*--------------------------------------*/
	/* WRITE GENOTYPES TO ARRAY "Genotypes" */
	/*--------------------------------------*/
       	FILE *fp2;
        char filename2[15] = "usergenotypes2";
        int count1, count2;
	int Genotypes[d][e];

        if((fp2 = fopen(filename2, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename2);
                exit(1);
        }

        for (count1 = 0; count1 < d; count1++)
        {
                for (count2 = 0; count2 < e; count2++)
                {
                        fscanf(fp2, "%d", &Genotypes[count1][count2]);
                }
        }

        fclose(fp2);
	remove(filename2);

	/*--------------------------------*/
	/* NUMBER OF PAIRWISE COMPARISONS */
	/*--------------------------------*/
	int f;
	f = (d*(d-1))/2;

	/*******************************/
	/* MAKE RESULTS FILE           */
	/*******************************/
	FILE *fp20;
	char filename20[12] = "Relatedness";

        if((fp20 = fopen(filename20, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename20);
                exit(1);
        }

	/**********************/
	/* CONDUCT ANALYSES   */
	/**********************/

	fprintf(fp20, "Individual_1\tIndividual_2\tR-value\n");

	/*----------------------------------*/
	/* READ APPROPRIATE PAIR INTO ARRAY */
	/*----------------------------------*/
	int pair[2][e];
	int count3, count4;

	for (count2 = 0; count2 < d; count2++)
	{		

			for (count3 = (count2+1); count3 < d; count3++)
			{
				for (count4 = 0; count4 < e; count4++)
				{
					pair[0][count4] = Genotypes[count2][count4];
					pair[1][count4] = Genotypes[count3][count4];
				}

				/****************************************/
				/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
				/****************************************/

					/*--------------------------------------------------------*/
					/* CALCULATE WEIGHTS FOR EACH LOCUS PROFILED IN EACH PAIR */
					/*--------------------------------------------------------*/
					float w1[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								w1[count5][count6] = 0;
							else
								w1[count5][count6] = var[0][count6];
						}
					}

					/*----------------------------------------------*/
					/* CALCULATE THE WEIGHT FOR EACH COMPARED LOCUS */
					/*----------------------------------------------*/
					float w2[1][1];
					float yy, xx;

					for (count5 = 0; count5 < 1; count5++)
					{
						xx = 0;
						yy = 0;		
						for (count6 = 0; count6 < b; count6++)
						{
							yy = w1[count5][count6];
							xx += yy;
						}
					w2[count5][0] = xx;
					}

					/*-------------------*/
					/* CALCULATE WEIGHTS */
					/*-------------------*/
					float weight[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if(w1[count5][count6] == 0)
								weight[count5][count6] = 0;
							else
								weight[count5][count6] = (((w1[count5][count6])-1)/(((w2[count5][0])-1)));
						}
					}

					/*------------------------*/
					/* COMBINE WEIGHTS        */
					/*------------------------*/
					float aaa;
					float w3[1];

					for (count5 = 0; count5 < 1; count5++)
					{
						aaa = 0;
						for (count6 = 0; count6 < b; count6++)
						{
							aaa += weight[count5][count6];
						}
					w3[count5] = aaa;
					}

				/*****************************************/
				/* CALCULATE ALLELE SHARING FOR THE PAIR */
				/*****************************************/

					/*--------------------*/
					/* FIRST COMPARISON   */
					/*--------------------*/
					int sharing[1][e-1];
	
					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < (e-1); count6++)
						{
							if((pair[count5*2][count6+1] == 0) || (pair[(count5*2)+1][count6+1] == 0))
								sharing[count5][count6] = 0;
							else
								if (pair[count5*2][count6+1] == pair[(count5*2)+1][count6+1])
									sharing[count5][count6] = 1;
								else
									sharing[count5][count6] = 0;
						}
					}

					/*----------------------------------*/
					/* COLLAPSE TO ONE COLUMN PER LOCUS */
					/*----------------------------------*/
					int share1[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							share1[count5][count6] = (sharing[count5][count6*2] + sharing[count5][(count6*2)+1]);
						}
					}

					/*-----------------------*/
					/* SECOND COMPARISON     */
					/*-----------------------*/
					int share2[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								share2[count5][count6] = 0;
							else
								if(pair[count5*2][(count6*2)+1] == pair[(count5*2)+1][(count6*2)+2])
									share2[count5][count6] = 1;
								else
									share2[count5][count6] = 0;
						}
					}

					/*---------------------------*/
					/* FOR COMPARISON #3         */
					/*---------------------------*/
					int share3[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								share3[count5][count6] = 0;
							else
								if(pair[count5*2][(count6*2)+2] == pair[(count5*2)+1][(count6*2)+1])
									share3[count5][count6] = 1;
								else
									share3[count5][count6] = 0;
						}
					}

					/*--------------------------------*/
					/* COMBINE TO ONE VALUE PER LOCUS */
					/*--------------------------------*/
					float share4[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								share4[count5][count6] = 0;
							else
								share4[count5][count6] = (share1[count5][count6] + share2[count5][count6] + share3[count5][count6]);
						}
					}
				
				/********************************************************/
				/* ASSESS IF INDIVIDUALS ARE HOMOZYGOUS OR HETEROZYGOUS */
				/********************************************************/

					/*-----------------------------------*/
					/* HOMOZYGOTE OR HETEROZYGOTE        */
					/*-----------------------------------*/
					float homo[2][b];

					for (count5 = 0; count5 < 2; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if(pair[count5][(count6*2)+1] == 0)
								homo[count5][count6] = 0;
							else
								if(pair[count5][(count6*2)+1] == pair[count5][(count6*2)+2])
									homo[count5][count6] = 1;
								else
									homo[count5][count6] = 0;
						}
					}

					float hetero[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								hetero[count5][count6] = 0;	
							else
								hetero[count5][count6] = (homo[count5*2][count6] + homo[(count5*2)+1][count6]);
						}
					}	

				/********************/
				/* CALCULATE AS     */
				/********************/
				float AS[1][b];

				for (count5 = 0; count5 < 1; count5++)
				{
					for (count6 = 0; count6 < b; count6++)
					{
						if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
							AS[count5][count6] = 0;
						else
							if(share4[count5][count6] == 4)
								AS[count5][count6] = 1;
							else	
								if((share4[count5][count6] == 2) && (hetero[count5][count6] == 0))
									AS[count5][count6] = 1;
								else
									if((share4[count5][count6] == 2) && (hetero[count5][count6] == 1))
										AS[count5][count6] = 0.75;
									else
										if(share4[count5][count6] == 1)
											AS[count5][count6] = 0.5;
										else
											AS[count5][count6] = 0;
					}
				}

				/*****************************/
				/* CALCULATE RELATEDNESS     */
				/*****************************/

					/*----------------------------------*/
					/* CALCULATE RELATEDNESS_1         */
					/*----------------------------------*/
					float rel1[1][b];
	
					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								rel1[count5][count6] = 0;
							else
								rel1[count5][count6] = ((AS[count5][count6] - S0[0][count6])/(1-S0[0][count6]));
						}
					}

					/*------------------------------------------*/
					/* CALCULATE THE WEIGHTED RELATEDNESS VALUE */
					/*------------------------------------------*/
					float rel2[1][b];

					for (count5 = 0; count5 < 1; count5++)
					{
						for (count6 = 0; count6 < b; count6++)
						{
							if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
								rel2[count5][count6] = 0;
							else
								rel2[count5][count6] = ((rel1[count5][count6])*(weight[count5][count6]));
						}
					}
	
					/*--------------------------------*/
					/* CALCULATE RELATEDNESS VALUE    */
					/*--------------------------------*/
					float rel3[1][1];
					float q, s;

					for (count5 = 0; count5 < 1; count5++)
					{
						q = 0;
						s = 0;
						for (count6 = 0; count6 < b; count6++)
						{
							q = rel2[count5][count6];
							s += q;
						}
					rel3[count5][0] = s/w3[count5];
					}

				/*************************/
				/* PRINT RESULTS TO FILE */
				/*************************/
				fprintf(fp20, "%d\t%d\t%f\n", Genotypes[count2][0], Genotypes[count3][0], rel3[0][0]);

			}
		
	}

	fclose(fp20);

	/*------------------------*/
	/* CLEAN UP FILES         */
	/*------------------------*/
	char filename50[7] = "freqs2";

	remove(filename50);

	printf("\n************************************************************");
	printf("\n Done! Your results have been printed to file 'Relatedness'.");
	printf("\n************************************************************\n");

	
	return(0);

}

int Sim(void)
/*-------------------------------------*/
/* This function creates a simulated   */
/* data set of 100 individuals that    */
/* contains 5 full-sibs (and parents), */
/* 5 half-sibs (and shared parents),   */
/* and 5 first-cousins. These data can */
/* be used to test the power of Rel-A- */
/* Tree with you data set.             */
/*-------------------------------------*/
{
        /*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	        /*------------------*/
        	/* DEFINE VARIABLES */
        	/*------------------*/
        	int a;  /* Holds the number of alleles in most polymorphic locus */
        	int b;  /* Holds the number of loci analyzed */
        	int c;  /* Will be a + 1, which will be the # of rows in the array */
	
        	/*----------------------*/
        	/* GET DATA FROM USER   */
        	/*----------------------*/
        	a = Alleles();
		b = Loci();
        	c = a + 1;

        	/*------------------------*/
        	/* GET ALLELE FREQUENCIES */
        	/*------------------------*/
		Frequencies(c, b);

	/*************************************/
	/* DOUBLE THE ALLELE FREQUENCY ARRAY */
	/*************************************/

		/*--------------------------------------*/
		/* OPEN FREQS AND SCAN INTO FREQUENCIES */
		/*--------------------------------------*/
		FILE *fp2;
		char filename2[6] = "freqs";
		float frequencies[c][b];
		int count1, count2;

 	       	if((fp2 = fopen(filename2, "r")) == NULL)
        	{
        	        fprintf(stderr, "Error opening file %s.\n", filename2);
                	exit(1);
        	}

        	for (count1 = 0; count1 < c; count1++)
        	{
                	for (count2 = 0; count2 < b; count2++)
                	{
                	        fscanf(fp2, "%f", &frequencies[count1][count2]);
                	}
        	}

        	fclose(fp2);

		/*--------------------------*/
		/* DOUBLE THE ARRAY         */
		/*--------------------------*/
		int d;		/* Is the number of columns in new array */
		d = b*2;
		float freqs2[a][d];

		for (count1 = 1; count1 < c; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				freqs2[count1-1][count2*2] = frequencies[count1][count2];
				freqs2[count1-1][(count2*2)+1] = frequencies[count1][count2];
			}
		}

	/*******************************/
	/* MAKE FREQUENCIES CUMULATIVE */
	/*******************************/
	float freqs3[a][d];

	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < d; count2++)
		{
			if (count1 == 0)
				freqs3[count1][count2] = freqs2[count1][count2];
			else
				freqs3[count1][count2] = freqs3[count1-1][count2] + freqs2[count1][count2];
		}
	}

	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/

		/*-----------------------------------------*/
		/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
		/*-----------------------------------------*/
		int seed1;
		seed1 = InitSeed();
	
		/*-----------------------------------------*/
		/* WRITE RANDOM NUMBERS TO ARRAY           */
		/*-----------------------------------------*/
		int iterationseed[100];
	
		const gsl_rng_type * TT;
		gsl_rng * rr;
	
		gsl_rng_env_setup();
	
		TT = gsl_rng_mt19937;
		rr = gsl_rng_alloc (TT);
		gsl_rng_set(rr, seed1);
	
		for (count1 = 0; count1 < 100; count1++)
		{
			iterationseed[count1] = gsl_rng_uniform_pos(rr) * seed1;
		}
		
		gsl_rng_free(rr);

	/****************************************/
	/* MAKE ARRAY WITH NEW INDIVIDUALS      */
	/****************************************/
	int individuals[100][d];
	int count3;
	float rand;
	int e;

	for (count1 = 0; count1 < 100; count1++)
	{
		for (count2 = 0; count2 < d; count2++)
		{
			/*----------------------------*/
			/* GET A RANDOM NUMBER        */	
			/*----------------------------*/
			e = (iterationseed[count1] + (count2*3));
			
			rand = Random(e);

			for (count3 = 0; count3 < a; count3++)
			{
				if (rand < freqs3[count3][count2])
				{
					individuals[count1][count2] = count3+1;
					break;
				}
			}
		}
	}

	/******************************/
	/* GENERATE FIRST FAMILY      */
	/******************************/
	
		/*-----------------------------*/
		/* GET APPROPRIATE MATING PAIR */
		/*-----------------------------*/
		int pair[2][d];

		for (count1 = 0; count1 < 2; count1++)
		{
			for (count2 = 0; count2 < d; count2++)
			{
				pair[count1][count2] = individuals[count1][count2];
			}
		}

		/*----------------------------------------------*/
		/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
		/*----------------------------------------------*/
		int mendel[2][d];
		Mendel(2, d, iterationseed[0], mendel);
	
		/*--------------------------*/
		/* CREATE A NEW OFFSPRING   */
		/*--------------------------*/
		int off[1][d];
	
		for (count1 = 0; count1 < d; count1 += 2)
		{
			if (mendel[0][count1] == 1)
				off[0][count1] = pair[0][count1];
			else
				off[0][count1] = pair[0][count1+1];
		}
	
		for (count1 = 1; count1 < d; count1 += 2)
		{
			if (mendel[1][count1] == 1)
				off[0][count1] = pair[1][count1-1];
			else
				off[0][count1] = pair[1][count1];
		}

		/*-------------------------------*/
		/* PLACE OFFSPRING BACK IN ARRAY */
		/*-------------------------------*/
		for (count1 = 0; count1 < d; count1++)
		{
			individuals[2][count1] = off[0][count1];
		}

		/*---------------------------*/
		/* SELECT NEXT MATING PAIR   */
		/*---------------------------*/
		for (count1 = 0; count1 < 2; count1++)
		{
			for (count2 = 0; count2 < d; count2++)
			{
				pair[count1][count2] = individuals[count1+2][count2];
			}
		}	

		/*---------------------------*/
		/* GENERATE FIVE OFFSPRING   */
		/*---------------------------*/
		for (count3 = 0; count3 < 5; count3++)
		{
			/*----------------------------------------------*/
			/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
			/*----------------------------------------------*/
			Mendel(2, d, iterationseed[count3+1], mendel);
	
			/*--------------------------*/
			/* CREATE A NEW OFFSPRING   */
			/*--------------------------*/
			for (count1 = 0; count1 < d; count1 += 2)
			{
				if (mendel[0][count1] == 1)
					off[0][count1] = pair[0][count1];
				else
					off[0][count1] = pair[0][count1+1];
			}
		
			for (count1 = 1; count1 < d; count1 += 2)
			{
				if (mendel[1][count1] == 1)
					off[0][count1] = pair[1][count1-1];
				else
					off[0][count1] = pair[1][count1];
			}

			/*-------------------------------*/
			/* PLACE OFFSPRING BACK IN ARRAY */
			/*-------------------------------*/
			for (count1 = 0; count1 < d; count1++)
			{
				individuals[count3+4][count1] = off[0][count1];
			}
		}

	/******************************/
	/* GENERATE SECOND FAMILY     */
	/******************************/
	
		/*-----------------------------*/
		/* GET APPROPRIATE MATING PAIR */
		/*-----------------------------*/
		for (count1 = 0; count1 < 2; count1++)
		{
			for (count2 = 0; count2 < d; count2++)
			{
				pair[count1][count2] = individuals[count1+9][count2];
			}
		}

		/*----------------------------------------------*/
		/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
		/*----------------------------------------------*/
		Mendel(2, d, iterationseed[9], mendel);
	
		/*--------------------------*/
		/* CREATE A NEW OFFSPRING   */
		/*--------------------------*/
		for (count1 = 0; count1 < d; count1 += 2)
		{
			if (mendel[0][count1] == 1)
				off[0][count1] = pair[0][count1];
			else
				off[0][count1] = pair[0][count1+1];
		}
	
		for (count1 = 1; count1 < d; count1 += 2)
		{
			if (mendel[1][count1] == 1)
				off[0][count1] = pair[1][count1-1];
			else
				off[0][count1] = pair[1][count1];
		}

		/*-------------------------------*/
		/* PLACE OFFSPRING BACK IN ARRAY */
		/*-------------------------------*/
		for (count1 = 0; count1 < d; count1++)
		{
			individuals[11][count1] = off[0][count1];
		}

		/*-------------------------------*/
		/* GENERATE FIVE OFFSPRING       */
		/*-------------------------------*/
		for (count3 = 0; count3 < 5; count3++)
		{
			/*---------------------------*/
			/* SELECT NEXT MATING PAIR   */
			/*---------------------------*/
			for (count1 = 0; count1 < d; count1++)
			{
				pair[0][count1] = individuals[11][count1];
				pair[1][count1] = individuals[count3+12][count1];
			}	

			/*----------------------------------------------*/
			/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
			/*----------------------------------------------*/
			Mendel(2, d, iterationseed[count3+12], mendel);
	
			/*--------------------------*/
			/* CREATE A NEW OFFSPRING   */
			/*--------------------------*/
			for (count1 = 0; count1 < d; count1 += 2)
			{
				if (mendel[0][count1] == 1)
					off[0][count1] = pair[0][count1];
				else
					off[0][count1] = pair[0][count1+1];
			}
		
			for (count1 = 1; count1 < d; count1 += 2)
			{
				if (mendel[1][count1] == 1)
					off[0][count1] = pair[1][count1-1];
				else
					off[0][count1] = pair[1][count1];
			}

			/*-------------------------------*/
			/* PLACE OFFSPRING BACK IN ARRAY */
			/*-------------------------------*/
			for (count1 = 0; count1 < d; count1++)
			{
				individuals[count3+12][count1] = off[0][count1];
			}
		}

	/**************************/
	/* GENERATE THIRD FAMILY  */
	/**************************/

		/*-----------------------------*/
		/* GET APPROPRIATE MATING PAIR */
		/*-----------------------------*/
		for (count2 = 0; count2 < d; count2++)
		{
				pair[0][count2] = individuals[17][count2];
				pair[1][count2] = individuals[18][count2];
		}

		/*----------------------------------------------*/
		/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
		/*----------------------------------------------*/
		Mendel(2, d, iterationseed[17], mendel);
	
		/*--------------------------*/
		/* CREATE A NEW OFFSPRING   */
		/*--------------------------*/
		for (count1 = 0; count1 < d; count1 += 2)
		{
			if (mendel[0][count1] == 1)
				off[0][count1] = pair[0][count1];
			else
				off[0][count1] = pair[0][count1+1];
		}
	
		for (count1 = 1; count1 < d; count1 += 2)
		{
			if (mendel[1][count1] == 1)
				off[0][count1] = pair[1][count1-1];
			else
				off[0][count1] = pair[1][count1];
		}

		/*-------------------------------*/
		/* PLACE OFFSPRING BACK IN ARRAY */
		/*-------------------------------*/
		for (count1 = 0; count1 < d; count1++)
		{
			individuals[18][count1] = off[0][count1];
		}

		/*-------------------------------*/
		/* GENERATE THREE OFFSPRING       */
		/*-------------------------------*/
		for (count3 = 0; count3 < 3; count3++)
		{
			/*---------------------------*/
			/* SELECT NEXT MATING PAIR   */
			/*---------------------------*/
			for (count1 = 0; count1 < d; count1++)
			{
				pair[0][count1] = individuals[18][count1];
				pair[1][count1] = individuals[count3+19][count1];
			}	

			/*----------------------------------------------*/
			/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
			/*----------------------------------------------*/
			Mendel(2, d, iterationseed[count3+19], mendel);
	
			/*--------------------------*/
			/* CREATE A NEW OFFSPRING   */
			/*--------------------------*/
			for (count1 = 0; count1 < d; count1 += 2)
			{
				if (mendel[0][count1] == 1)
					off[0][count1] = pair[0][count1];
				else
					off[0][count1] = pair[0][count1+1];
			}
		
			for (count1 = 1; count1 < d; count1 += 2)
			{
				if (mendel[1][count1] == 1)
					off[0][count1] = pair[1][count1-1];
				else
					off[0][count1] = pair[1][count1];
			}

			/*-------------------------------*/
			/* PLACE OFFSPRING BACK IN ARRAY */
			/*-------------------------------*/
			for (count1 = 0; count1 < d; count1++)
			{
				individuals[count3+19][count1] = off[0][count1];
			}
		}

	/**************************/
	/* GENERATE FOURTH FAMILY */
	/**************************/

		/*-----------------------------*/
		/* GET APPROPRIATE MATING PAIR */
		/*-----------------------------*/
		for (count2 = 0; count2 < d; count2++)
		{
			pair[0][count2] = individuals[17][count2];
			pair[1][count2] = individuals[22][count2];
		}

		/*----------------------------------------------*/
		/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
		/*----------------------------------------------*/
		Mendel(2, d, iterationseed[18], mendel);
	
		/*--------------------------*/
		/* CREATE A NEW OFFSPRING   */
		/*--------------------------*/
		for (count1 = 0; count1 < d; count1 += 2)
		{
			if (mendel[0][count1] == 1)
				off[0][count1] = pair[0][count1];
			else
				off[0][count1] = pair[0][count1+1];
		}
	
		for (count1 = 1; count1 < d; count1 += 2)
		{
			if (mendel[1][count1] == 1)
				off[0][count1] = pair[1][count1-1];
			else
				off[0][count1] = pair[1][count1];
		}

		/*-------------------------------*/
		/* PLACE OFFSPRING BACK IN ARRAY */
		/*-------------------------------*/
		for (count1 = 0; count1 < d; count1++)
		{
			individuals[22][count1] = off[0][count1];
		}

		/*-------------------------------*/
		/* GENERATE THREE OFFSPRING       */
		/*-------------------------------*/
		for (count3 = 0; count3 < 3; count3++)
		{
			/*---------------------------*/
			/* SELECT NEXT MATING PAIR   */
			/*---------------------------*/
			for (count1 = 0; count1 < d; count1++)
			{
				pair[0][count1] = individuals[22][count1];
				pair[1][count1] = individuals[count3+23][count1];
			}	

			/*----------------------------------------------*/
			/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
			/*----------------------------------------------*/
			Mendel(2, d, iterationseed[count3+23], mendel);
	
			/*--------------------------*/
			/* CREATE A NEW OFFSPRING   */
			/*--------------------------*/
			for (count1 = 0; count1 < d; count1 += 2)
			{
				if (mendel[0][count1] == 1)
					off[0][count1] = pair[0][count1];
				else
					off[0][count1] = pair[0][count1+1];
			}
		
			for (count1 = 1; count1 < d; count1 += 2)
			{
				if (mendel[1][count1] == 1)
					off[0][count1] = pair[1][count1-1];
				else
					off[0][count1] = pair[1][count1];
			}

			/*-------------------------------*/
			/* PLACE OFFSPRING BACK IN ARRAY */
			/*-------------------------------*/
			for (count1 = 0; count1 < d; count1++)
			{
				individuals[count3+23][count1] = off[0][count1];
			}
		}

	/****************************/
	/* PRINT RESULTS TO OUTFILE */
	/****************************/
	FILE *fp20;
	char filename20[8] = "Rel_Sim";

        if((fp20 = fopen(filename20, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename20);
                exit(1);
        }

	for (count1 = 0; count1 < 100; count1++)
	{
		fprintf(fp20, "%d\t", count1+1000000001);

		for (count2 = 0; count2 < d; count2++)
		{
			fprintf(fp20, "%d\t", individuals[count1][count2]);
		}
		fprintf(fp20, "\n");
	}

	fclose(fp20);

	/*------------------------*/
	/* CLEAN UP FILES         */
	/*------------------------*/
	char filename50[6] = "freqs";

	remove(filename50);

	printf("\n************************************************\n");
	printf("Done!!! Results printed to file 'Rel_Sim'\n");
	printf("**************************************************\n\n");

return(0);
}	
	
int Alleles(void)
/*-----------------------------*/
/* This function asks the user */
/* how many alleles they have  */
/* in the most polymorphic     */
/* locus, and then saves that  */
/* value.                      */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many alleles do you have in the most polymorphic locus (not including 0)? ");
        scanf("%d", &a);

	return a;
}

void Bootstrap(int b, int seed2)
/*-------------------------------*/
/* This functions randomly       */
/* samples loci with replacement */
/* that will then be used for    */
/* calculating relatedness. It   */
/* writes these data to file     */
/* "strap".                      */
/*-------------------------------*/
{
	/*-----------------------*/
	/* DEFINE VARIABLES      */
	/*-----------------------*/
	int b1[b];
	int b2[b];
	int count1;

	const gsl_rng_type * T;
	gsl_rng * r;
	
	/*------------------------*/
	/* RANDOMIZE LIST         */
	/*------------------------*/	gsl_rng_env_setup();	T = gsl_rng_mt19937;
	r = gsl_rng_alloc (T);
	gsl_rng_set(r, seed2);

	for (count1 = 0; count1 < b; count1++)
	{
		b1[count1] = count1+1;
	}

	gsl_ran_sample (r, b2, b, b1, b, sizeof(int));

	gsl_rng_free(r);

	/*-------------------------------*/
	/* WRITE LIST TO FILE "strap"    */
	/*-------------------------------*/
	FILE *fp1;
	char filename1[6] = "strap";

        if((fp1 = fopen(filename1, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < b; count1++)
        {
		fprintf(fp1, "%d\n", b2[count1]);
        }

        fclose(fp1);
}


void FreqsColumn_to_Row(int b, int c)
/*------------------------------------*/
/* This function reads the "freqs"    */
/* file of allele frequencies into an */
/* array called "frequencies2",       */
/* converts columns to rows, and then */
/* writes these data to a file called */
/* "freqs2".                          */
/*------------------------------------*/
{
	/*----------------------------------------------*/
	/* READ "freqs" file INTO ARRAY "frequencies"  */
	/*----------------------------------------------*/
        FILE *fp1;
        char filename1[6] = "freqs";
        int count1, count2;
	float frequencies[c][b];

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < c; count1++)
        {
                for (count2 = 0; count2 < b; count2++)
                {
                        fscanf(fp1, "%f", &frequencies[count1][count2]);
                }
        }

        fclose(fp1);

	remove(filename1);

	/*--------------------------*/
	/* CONVERT COLUMNS TO ROWS  */
	/*--------------------------*/
	float frequencies2[b][c];

	for (count1 = 0; count1 < b; count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			frequencies2[count1][count2] = frequencies[count2][count1];
		}
	}

	/*---------------------------------*/
	/* WRITE ARRAY TO FILE "freqs2"    */
	/*---------------------------------*/
	FILE *fp2;
	char filename2[7] = "freqs2";
	
	if ((fp2 = fopen(filename2, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename2);
		exit(1);
	}	
	
	for (count1 = 0; count1 < b; count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			fprintf(fp2, "%f\t", frequencies2[count1][count2]);
		}
		fprintf(fp2, "\n");
	}

	fclose(fp2);  	
}

void Frequencies(int a, int b)
/*------------------------------*/
/* This function asks the user  */
/* the name of their allele     */
/* frequency file, and then     */
/* reads that into an array     */
/* named frequencies and then   */
/* writes it to a file named    */
/* freqs.                       */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[40];
        int count1, count2;
	float frequencies[a][b];
	FILE *fp2;
	char filename2[6] = "freqs";

        printf("\nWhat is the name of your allele frequency file (including extension)? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < a; count1++)
        {
                for (count2 = 0; count2 < b; count2++)
                {
                        fscanf(fp1, "%f", &frequencies[count1][count2]);
                }
        }

        fclose(fp1);

	if ((fp2 = fopen(filename2, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename2);
		exit(1);
	}	
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			fprintf(fp2, "%f\t", frequencies[count1][count2]);
		}
		fprintf(fp2, "\n");
	}

	fclose(fp2);  	

}

int Genotypes(void)
/*-----------------------------*/
/* This function asks the user */
/* how many individuals they   */
/* have in their genotype file */
/* and then returns that value */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of individuals in their genotype file */
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many individuals do you have in your genotype file? ");
        scanf("%d", &a);

	return a;
}

int InitSeed(void)
/*------------------------------------*/
/* This function generates a seed for */
/* the random number generator based  */
/* on the computer clock.             */
/*------------------------------------*/
{
        int seed;
        time_t  nowtime;
        struct tm*preztime;

        time(&nowtime);
        preztime = localtime(&nowtime);
        seed = (int)((preztime->tm_sec+1)*(preztime->tm_min+1)*(preztime->tm_hour+1)*(preztime->tm_year)*(preztime->tm_year));
        if(seed%2==0) seed++;

        return seed;
}

void IterationSeed(int y, int z)
/*------------------------------*/
/* This function creates a list */
/* of random numbers, one for   */
/* each iteration that the user */
/* wants to perform, that will  */
/* serve as the seed for the    */
/* other random number          */
/* generators within that       */
/* iteration.  These numbers are*/
/* written to a file called     */
/* "iterationseeds".            */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[15] = "iterationseeds";
        int count1;
	int randomseed[y];
	
	/*--------------------------------*/
	/* CREAT ARRAY OF RANDOM NUMBERS  */
	/*--------------------------------*/
	const gsl_rng_type * TT;
	gsl_rng * rr;

	gsl_rng_env_setup();

	TT = gsl_rng_mt19937;
	rr = gsl_rng_alloc (TT);
	gsl_rng_set(rr, z);

	for (count1 = 0; count1 < y; count1++)
	{
		randomseed[count1] = gsl_rng_uniform_pos(rr) * z;
	}
	
	gsl_rng_free(rr);

	/*-----------------------------*/
	/* WRITE ARRAY TO FILE         */
	/*-----------------------------*/
	if ((fp1 = fopen(filename1, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename1);
		exit(1);
	}	
	
	for (count1 = 0; count1 < y; count1++)
	{
		fprintf(fp1, "%d\n", randomseed[count1]);
	}

	fclose(fp1);  	
}

int Loci(void)
/*-----------------------------*/
/* This function asks the user */
/* how many loci they used and */
/* saves that  value.          */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of loci used */
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many loci did you use? ");
        scanf("%d", &a);

	return a;
}

void Locus_Var(int b, int c)
/*-------------------------------*/
/* This function sums the number */
/* of alleles present in each    */
/* locus, and writes these data  */
/* to a file called "locusvar"   */
/*-------------------------------*/
{
	/*----------------------------------------*/
	/* READ "freqs2" INTO ARRAY "frequencies2 */	
	/*----------------------------------------*/
	FILE *fp1;
	char filename1[7] = "freqs2";
	int count1, count2;
	float frequencies2[b][c];

	if((fp1 = fopen(filename1, "r")) == NULL)
        {
       		fprintf(stderr, "Error opening file %s.\n", filename1);
        	exit(1);
        }

        for (count1 = 0; count1 < b; count1++)
        {
		for (count2 = 0; count2 < c; count2++)
		{
			fscanf(fp1, "%f", &frequencies2[count1][count2]);
        	}
	}

        fclose(fp1);

	/*------------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS  */
	/*------------------------------------*/
	float var[b];
	int x, w;

	for (count1 = 0; count1 < b; count1++)
	{
		x = 0;	
		w = 0;	
		for (count2 = 0; count2 < c; count2++)
		{
			if (frequencies2[count1][count2] == 0)
				w = 0;
			else
				if (frequencies2[count1][count2] < 2)
					w = 1;
				else
					w = 0;
		x += w;
		}
	var[count1] = x;	
	}

	/*--------------------------------*/
	/* WRITE ARRAY TO FILE "locusvar" */
	/*--------------------------------*/
	FILE *fp2;
	char filename2[9] = "locusvar";

	if((fp2 = fopen(filename2, "w")) == NULL)
        {
       		fprintf(stderr, "Error opening file %s.\n", filename2);
        	exit(1);
        }

	for (count1 = 0; count1 < b; count1++)
	{
		fprintf(fp2, "%f\n", var[count1]);
	}

	fclose(fp2);
}

void *Mendel(int mm, int nn, int oo, int mendel[mm][nn])
/*------------------------------------*/
/* This function makes an array that  */
/* is filled with 1's and 2's that    */
/* serves to determine which alleles  */
/* offspring will inherit.            */
/*------------------------------------*/
{
	/*--------------------------*/
	/* DEFINE VARIABLES         */
	/*--------------------------*/
	float mendel1[mm][nn];
	int count1, count2;
	const gsl_rng_type * TTT;
	
	gsl_rng * rrr;

	/*------------------------------------*/
	/* CREAT ARRAY OF RANDOM NUMBERS      */
	/*------------------------------------*/
	gsl_rng_env_setup();

	TTT = gsl_rng_mt19937;
	rrr = gsl_rng_alloc (TTT);
	gsl_rng_set(rrr, oo);

	for (count1 = 0; count1 < mm; count1++)
	{
		for (count2 = 0; count2 < nn; count2++)
		{
			mendel1[count1][count2] = gsl_rng_uniform_pos(rrr);
		}
	}

	gsl_rng_free(rrr);

	/*--------------------------------------*/
	/* CONVERT THESE NUMBERS TO 1'S AND 0'S */
	/*--------------------------------------*/
	for (count1 = 0; count1 < mm; count1++)
	{
		for (count2 = 0; count2 < nn; count2++)
		{
			if (mendel1[count1][count2] < 0.5)
				mendel[count1][count2] = 1;
			else
				mendel[count1][count2] = 2;
		}
	}	
	return(0);
}

void Partials(int g, int h)
/*---------------------------------*/
/* This function goes through the  */
/* genotype file and ensures that  */
/* if one allele is missing at a   */
/* locus, then both alleles are    */
/* coded as "0". Genotypes must be */
/* all or none at each locus for   */
/* these analyses.                 */
/*---------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[14] = "usergenotypes";
        int count1, count2;
	int profiles[g][h];
	FILE *fp2;
	char filename2[15] = "usergenotypes2";

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < g; count1++)
        {
                for (count2 = 0; count2 < h; count2++)
                {
                        fscanf(fp1, "%d", &profiles[count1][count2]);
                }
        }

        fclose(fp1);

	remove(filename1);

        for (count1 = 0; count1 < g; count1++)
        {
                for(count2 = 1; count2 < h; count2+=2)
                {
                        if (profiles[count1][count2] == 0)
                                profiles[count1][count2+1] = 0;
                        else
                                if (profiles[count1][count2+1] == 0)
                                        profiles[count1][count2] = 0;
                }
        }


	if ((fp2 = fopen(filename2, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename2);
		exit(1);
	}	
	
	for (count1 = 0; count1 < g; count1++)
	{
		for (count2 = 0; count2 < h; count2++)
		{
			fprintf(fp2, "%d\t", profiles[count1][count2]);
		}
		fprintf(fp2, "\n");
	}

	fclose(fp2);  	
}

float Random(int e)
/*----------------------------------*/
/* This function generates a random */
/* number between 0 and 1.          */
/*----------------------------------*/
{
	float a;
	const gsl_rng_type * TTT;
	
	gsl_rng * rrr;

	/*------------------------------------*/
	/* CREAT ARRAY OF RANDOM NUMBERS      */
	/*------------------------------------*/
	gsl_rng_env_setup();

	TTT = gsl_rng_mt19937;
	rrr = gsl_rng_alloc (TTT);
	gsl_rng_set(rrr, e);

	a = gsl_rng_uniform_pos(rrr);

	gsl_rng_free(rrr);

	return(a);
}

void S0_Calc(int b, int c)
/*-------------------------------*/
/* This function calculates the  */
/* S0 for each locus, as needed  */
/* for calculating relatedness,  */
/* and then writes results to a  */
/* file called "S0_data".        */
/*-------------------------------*/
{
	/*----------------------------------------------*/
	/* READ "freqs2" FILE INTO ARRAY "frequencies2" */
	/*----------------------------------------------*/
       	FILE *fp1;
        char filename1[7] = "freqs2";
        int count1, count2;
	float frequencies2[b][c];

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < b; count1++)
        {
                for (count2 = 0; count2 < c; count2++)
                {
                        fscanf(fp1, "%f", &frequencies2[count1][count2]);
                }
        }

        fclose(fp1);

	/*---------------------------------*/
	/* REPLACE INTEGERS WITH ZEROS     */
	/*---------------------------------*/	
	float S0[b][c];

	for (count1 = 0; count1 < b; count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			if (frequencies2[count1][count2] > 1)
				S0[count1][count2] = 0;
			else
				S0[count1][count2] = frequencies2[count1][count2];
		}
	}

	/*-----------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS */
	/*-----------------------------*/
	float S02[b][c];
	
	for (count1 = 0; count1 < b; count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			S02[count1][count2] = ((S0[count1][count2] * S0[count1][count2])*(2-S0[count1][count2]));
		}
	}

	/*------------------------------*/
	/* SUM ACROSS ALLELES           */
	/*------------------------------*/
	float S03[1][b];
	float y,z;

	for (count1 = 0; count1 < b; count1++)
	{
		y = 0;	
		z = 0;	
		for (count2 = 0; count2 < c; count2++)
		{
			z = S02[count1][count2];
		y += z;			
		}
	S03[0][count1] = y;	
	}	

	/*--------------------------------*/
	/* WRITE ARRAY TO FILE "S0_data"  */
	/*--------------------------------*/
	FILE *fp2;
	char filename2[8] = "S0_data";

	if((fp2 = fopen(filename2, "w")) == NULL)
        {
       		fprintf(stderr, "Error opening file %s.\n", filename2);
        	exit(1);
        }

	for (count1 = 0; count1 < b; count1++)
	{
		fprintf(fp2, "%f\n", S03[0][count1]);
	}

	fclose(fp2);	
}

int Seed2(int aa, int bb)
/*-----------------------------*/
/* This function opens the     */
/* file of random numbers and  */
/* returns the number that     */
/* corresponds to the          */
/* iteration that is currently */
/* being performed.  This      */
/* number acts as the seed for */
/* the current iteration.      */
/*-----------------------------*/
{
	/********************************************************/
	/* OPEN "iterationseeds" AND SCAN INTO "randommc" ARRAY */
	/********************************************************/

	/*----------------------*/
	/* DEFINE VARIABLES     */
	/*----------------------*/
        FILE *fp1;
        char filename1[15] = "iterationseeds";
        int count1;
	int randommc[bb];

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < bb; count1++)
        {
		fscanf(fp1, "%d", &randommc[count1]);
        }

        fclose(fp1);

	/*********************************************/
	/* GET NUMBER ASSOCIATED WITH THIS ITERATION */
	/*********************************************/
	int a;
	a = randommc[aa];

	return(a);
} 

void UserGenotypes(int e, int f)
/*------------------------------*/
/* This function gets the       */
/* genotype data from the user  */
/* and writes it to a file      */
/* called "usergenotypes".      */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[40];
        int count1, count2;
	int profiles[e][f];
	FILE *fp2;
	char filename2[14] = "usergenotypes";

        printf("\nWhat is the name of your genotype file (including extension)? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < e; count1++)
        {
                for (count2 = 0; count2 < f; count2++)
                {
                        fscanf(fp1, "%d", &profiles[count1][count2]);
                }
        }

        fclose(fp1);

	if ((fp2 = fopen(filename2, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename2);
		exit(1);
	}	
	
	for (count1 = 0; count1 < e; count1++)
	{
		for (count2 = 0; count2 < f; count2++)
		{
			fprintf(fp2, "%d\t", profiles[count1][count2]);
		}
		fprintf(fp2, "\n");
	}

	fclose(fp2);  	
}



	
