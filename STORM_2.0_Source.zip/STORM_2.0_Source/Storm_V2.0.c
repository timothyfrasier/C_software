/*------------------------------------STORM.c----------------------------------------*/
/* This program carries out a number of calculations and processes in order to test  */
/* hypotheses of relatedness and mating patterns of individuals within a population. */
/* More detail of the different functions is provided below.                         */
/*										                                             */
/* Copyright (C) 2011 Tim Frasier                                                    */
/*                                                                                   */
/* This program is free software; you can redistribute it and/or modify it under the */
/* terms of the GNU General Public License as published by the Free Software         */
/* Foundation; either version 2 of the License, or (at your option) any later        */
/* version.                                                                          */
/*                                                                                   */
/* This program is distributed in the hope that it will be useful, but WITHOUT ANY   */
/* WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A   */
/* PARTICULAR PURPOSE.  See the GNU Public License for more details.                 */
/* (http://www.gnu.org/licenses/gpl.html)                                            */
/*-----------------------------------------------------------------------------------*/

/*-----------------------*/
/* INCLUDED FILES        */
/*-----------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

/*-----------------------*/
/* MAIN FUNCTIONS        */
/*-----------------------*/
int AI(void);
int AISIM(void);
int AlleleFrequencies(void);
int FL(void);
int FLSIM(void);
int Grelate(void);
int GrelateSim(void);
int Grelate2(void);
int Grelate2Sim(void);
int HL(void);
int HLSIM(void);
int IRcalc(void);
int IRsim(void);
int Pairrelate(void);
int Pairsim(void);
int Pairwise(void);

/*-----------------------*/
/* MENU FUNCTIONS        */
/*-----------------------*/
int alleleinheritance(void);
int relatedness(void);
int variability(void);

/*-----------------------*/
/* HELPER FUNCTIONS      */
/*-----------------------*/
float AICalc(int b, int e, int mom[1][e], int dad[1][e], int off[1][e], float HE[b], float share1[1][b], int offtyped);
int Alleles(void);
void *AlleleSharing(int b, int e, int pair[2][e], float AS[1][b]);
void clear_kb(void);
void *DoubleFreqs(int b, int c, int f, float freqs2[c][f], float frequencies[c][b]);
void *FemaleGenotypes(int w, int x, int femalegenotypes[w][x]);
void *FreqsColumn_to_Row(int b, int c, float freqs3[c][b], float freqs4[b][c]);
void *FreqConvert(int c, int b, float frequencies[c][b], float freqs2[c][b]);
void *FreqSquare(int c, int b, float freqs2[c][b], float freqs3[c][b]);
void *Frequencies(int c, int b, float frequencies[c][b]);
int Genotypes(void);
void *HECalc(int b, int c, float freqs4[b][c], float HE[b]);
void *Homozygosity(int a, int b, int genotype[a][(2*b)+1], int homo[a][b]);
int InitSeed(void);
int Iterations(void);
void *IterationSeed(int y, int z, int iterationseeds[y]);
int Loci(void);
void *Locus_Var(int b, int c, float freqs3[b][c], float var[b]);
float Locus_Weights(int b, int e, int pair[2][e], float var[b], float weights[1][b]);
void *MaleGenotypes(int u, int v, int malegenotypes[u][v]);
int MatingPairs(void);
void *MatingPairsFile(int d, int e, int profiles[d][e]);
void *Mendel(int mm, int nn, int oo, int mendel[mm][nn]);
int Offspring(void);
void *OffspringProfiles(int d, int e, int offspring[d][e]);
void *ParentalAlleleSharing(int b, int e, int mom[1][e], int dad[1][e], int MF5[1][b]);
void Partials(int d, int e, int profiles[d][e]);
int ProfiledFemales(void);
int ProfiledMales(void);
int Randomize(int ff, int gg);
float Relatedness(int b, int e, float weight, int pair[2][e], float AS[1][b], float S02[1][b], float weights[1][b]);
void *Sharing(int b, int e, int mom[1][e], int dad[1][e], int off[1][e], int homo[1][b], int fatherhomo[1][b], int motherhomo[1][b], int MF5[1][b], int FO5[1][b], float share1[1][b]);
void *Shuffle(int d, int seed2, int d1[d]);
void *S0_Calc(int b, int c, float freqs3[b][c], float S02[1][b]);
void *UserGenotypes(int d, int e, int profiles[d][e]);		

/*-------------------------------------------*/
/* CREATE STRUCTURE TO HOLD INDIVIDUAL NAMES */
/*-------------------------------------------*/
struct Text2{
	char IndName[20];
};


/*------------------------*/
/* BEGINNING OF PROGRAM   */
/*------------------------*/

int main(void)
{
	int selection;
	selection = 0;
	/*-------------------------*/
	/* PRINT WELCOME SCREEN    */
	/*-------------------------*/
	printf("\n\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	printf("\n\t\t\tWelcome to STORM\n");
	printf("\n\t\t           ver. 2.0\n");
	printf("\n\t\t\tby Tim Frasier\n");
	printf("\n\t\t   Last updated: 29-June-2011");
	printf("\n\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
	printf("\nWHAT WOULD YOU LIKE TO DO?\n");
    printf("\n1. Estimate allele frequencies and format for analyses?\n");
	printf("\n2. Quantify genetic variability within individuals (using IR or HL)?\n");
	printf("\n3. Conduct analyses of relatedness?\n");
	printf("\n4. Assess allele inheritance of offspring\n");
	printf("\n5. QUIT \n");
	printf("\nType your selection here ");
	scanf("%d", &selection);

    if(selection == 1)
        AlleleFrequencies();
    else
        if(selection == 2)
            variability();
        else
            if(selection == 3)
                relatedness();
            else
                if(selection == 4)
                    alleleinheritance();

	return(0);
}

/****************************************************************************************/
/*                               MENU FUNCTIONS                                         */
/****************************************************************************************/
int variability(void)
{
	int choice;
	choice = 0;
	printf("\n\n\n");
	printf("\n************************************************************\n");
	printf("\nWHAT WOULD YOU LIKE TO DO?\n");
	printf("\nCalculate Internal Relatedness (IR):");
	printf("\n\tOf genotyped individuals..........................1");
	printf("\n\tOf simulated offspring from a known gene pool.....2");		
	printf("\n");
	printf("\nCalculate Homozygosity by Loci (HL):");
	printf("\n\tOf genotyped individuals..........................3");
	printf("\n\tOf simulated offspring from a known gene pool.....4\n");
	printf("\nQUIT......................................................5\n");
	printf("\n************************************************************\n");
	printf("\n\n");
	printf("\nEnter your selection here ");
	scanf("%d", &choice);		

	if (choice == 1)
		IRcalc();
	else
		if (choice == 2)
			IRsim();
		else
			if (choice == 3)
				HL();
			else	
				if (choice == 4)
					HLSIM();

	return(0);
}

int relatedness(void)
{
	int choice;
	choice = 0;
	printf("\n\n\n");
	printf("\n************************************************************\n");
	printf("\nWHAT WOULD YOU LIKE TO DO?\n");
	printf("\nCalculate pairwise relatedness values.....................1");
	printf("\n");
	printf("\nCalculate mating pair relatedness:");
	printf("\n\tOf identified mating pairs (or any type of pairs).2");
	printf("\n\tOf randomly generated mating pairs................3");		
	printf("\n");
	printf("\nCalculate relatedness in groups (all vs all):");	
	printf("\n\tPairwise within-group relatedness.................4");
	printf("\n\tIndividuals shuffled between groups...............5");
	printf("\n");
	printf("\nCalculate relatedness in groups (with reference individual):");
	printf("\n\tPairwise within-group relatedness.................6");
	printf("\n\tIndividuals shuffled between groups...............7");		
	printf("\n");	
	printf("\nQUIT......................................................8\n");
	printf("\n************************************************************\n");
	printf("\n\n");
	printf("\nEnter your selection here ");
	scanf("%d", &choice);		

	if (choice == 1)
		Pairwise();
	else
		if (choice == 2)
			Pairrelate();
		else
			if (choice == 3)
				Pairsim();
			else	
				if (choice == 4)
					Grelate();
				else
					if (choice == 5)
						GrelateSim();
					else
						if (choice == 6)
							Grelate2();
						else 
							if (choice == 7)
								Grelate2Sim();

	return(0);
}

int alleleinheritance(void)
{
	int choice;
	choice = 0;
	printf("\n\n\n");
	printf("\n************************************************************\n");
	printf("\nWHAT WOULD YOU LIKE TO DO?\n");
	printf("\nCalculate Allele Inheritance (Divergent Parental Allele Hypothesis):");
	printf("\n\tOf identified offspring...........................1");
	printf("\n\tOf simulated offspring from a known gene pool.....2\n");
	printf("\nCalcualte Allele Inheritance (Fetal Loss Hypothesis):");
	printf("\n\tOf identified offspring...........................3");
	printf("\n\tOf simulated offspring from a known gene pool.....4\n");	
	printf("\nQUIT......................................................5\n");
	printf("\n************************************************************\n");
	printf("\n\n");
	printf("\nEnter your selection here ");
	scanf("%d", &choice);		

	if (choice == 1)
		AI();
	else
		if (choice == 2)
			AISIM();
		else 
			if (choice == 3)
				FL();
			else 
				if (choice == 4)
					FLSIM();



	return(0);
}

/****************************************************************************************/
/*                               MAIN FUNCTIONS                                         */
/****************************************************************************************/

int AI(void)
/*---------------------------------*/
/* This program calculates the     */
/* allele inheritance for each     */
/* individual based on the         */
/* dissimilar paternal alleles.    */
/*---------------------------------*/
{
       	/*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);

	/*---------------------------------*/
	/* SQUARE THE ALLELE FREQUENCIES   */
	/*---------------------------------*/
	float freqs3[c][b];
	FreqSquare(c, b, freqs2, freqs3);

	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs4[b][c];
	FreqsColumn_to_Row(b, c, freqs3, freqs4);
	
	/*-------------------------------*/
	/* CALCULATE HE FOR EACH LOCUS   */
	/*-------------------------------*/
	float HE[b];
	HECalc(b, c, freqs4, HE);

	/*----------------------------------*/
	/* GET OFFSPRING DATA               */
	/*----------------------------------*/
	int d;		/* Is the number of offspring in the file */
	int e;		/* Will be (2*b + 1) - is the number of columns in file) */
	e = (2*b)+1;

	d = Offspring();

	int offspring[d][e];
	OffspringProfiles(d, e, offspring);

	/*-----------------------------*/
	/* DEAL WITH PARTIAL PROFILES  */
	/*-----------------------------*/
	Partials(d, e, offspring);

	/*------------------------------*/
	/* GET MATING PAIR DATA         */
	/*------------------------------*/
	int h;		/* Is the number of mating pairs */
	int g;

  	h = MatingPairs();
	g = (2 * h);

	int profiles[g][e];
	MatingPairsFile(g, e, profiles);

	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(g, e, profiles);

	/*----------------------------*/
	/* GET OUTFILE INFORMATION    */
	/*----------------------------*/
	FILE *fp4;
	char filename4[40];

	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename4);

        if((fp4 = fopen(filename4, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename4);
                exit(1);
        }

	/*----------------------------*/
	/* MAKE HEADERS FOR OUTFILE   */
	/*----------------------------*/
	fprintf(fp4, "Offspring\tAI\n");

	/********************************/
	/* BEGIN ANALYSIS               */
	/********************************/
	int count1;
	float aa, bb, cc;

	aa = 0;
	bb = 0;
	cc = 0;

	for (count1 = 0; count1 < d; count1++)
	{
		/*-------------------------------*/
		/* GET THE APPROPRIATE OFFSPRING */
		/*-------------------------------*/
		int off[1][e];
		int count2;
	
		for (count2 = 0; count2 < e; count2++)
		{
			off[0][count2] = offspring[count1][count2];
		}

		/*-------------------------------*/
		/* GET THE APPROPRIATE PAIR      */
		/*-------------------------------*/
		int mom[1][e];
		int dad[1][e];

		for (count2 = 0; count2 < e; count2++)
		{
			mom[0][count2] = profiles[(count1*2)][count2];
		}

		for (count2 = 0; count2 < e; count2++)
		{
			dad[0][count2] = profiles[(count1*2)+1][count2];
		}

		/*-----------------------------*/
		/* HETEROZYGOSITY OF OFFSPRING */
		/*-----------------------------*/
		int homo[1][b];
		Homozygosity(1, b, off, homo);

		/*-----------------------------*/
		/* NUMBER OF TYPED LOCI        */
		/*-----------------------------*/
		int offtyped;
		offtyped = 0;

		for (count2 = 0; count2 < b; count2++)
		{
			if (off[0][(count2*2)+1] == 0)
				offtyped += 0;
			else
				offtyped += 1;
		}

		/*-----------------------------------------------------*/
		/* DETERMINE IF FATHERS ARE HOMOZYGOUS OR HETEROZYGOUS */
		/*-----------------------------------------------------*/
		int fatherhomo[1][b];
		Homozygosity(1, b, dad, fatherhomo);

		/*-----------------------------------------------------*/
		/* DETERMINE IF MOTHERS ARE HOMOZYGOUS OR HETEROZYGOUS */
		/*-----------------------------------------------------*/
		int motherhomo[1][b];
		Homozygosity(1, b, mom, motherhomo);

		/*-----------------------------------------*/
		/* CALCULATE PARENTAL ALLELE SHARING       */
		/*-----------------------------------------*/
		int MF5[1][b];
		ParentalAlleleSharing(b, e, mom, dad, MF5);

		/*-------------------------------------------*/
		/* CALCULATE FATHER-OFFSPRING ALLELE SHARING */
		/*-------------------------------------------*/
		int FO5[1][b];
		ParentalAlleleSharing(b, e, off, dad, FO5);

		/*----------------------------------------*/
		/* MAKE ARRAY FOR CALCULATIONS            */
		/*----------------------------------------*/
		float share1[1][b];
		Sharing(b, e, mom, dad, off, homo, fatherhomo, motherhomo, MF5, FO5, share1);

		/*-----------------------------------*/
		/* CALCULATE AI                      */
		/*-----------------------------------*/
		float AIEstimate;
		AIEstimate = AICalc(b, e, mom, dad, off, HE, share1, offtyped);

		if (AIEstimate > 998)
			aa += 0;
		else
			aa += AIEstimate;

		if (AIEstimate > 998)
			cc += 0;
		else
			cc += 1;

		/*----------------------------*/
		/* PRINT RESULTS TO FILE      */
		/*----------------------------*/
		fprintf(fp4, "\n%d\t%f", off[0][0], AIEstimate);
	}
	
	bb = aa/cc;

	fprintf(fp4, "\n\nAverage\t%f", bb);

	fclose(fp4);

	printf("\n***********************************");
	printf("\nDONE!! Results written to %s.", filename4);
	printf("\n***********************************\n\n");

	return(0);
}	

int AISIM(void)
/*--------------AISIM.c----------------*/
/* This program takes mother and father*/
/* genotypes from the user, randomly   */
/* mates them (with replacement),      */
/* generates offspring, and then       */
/* calculates the allele inheritance   */
/* of those offspring.  These represent*/
/* the "null expectations" of AI values*/
/* for offspring if mating is random   */
/* (among successfull individuals) in  */
/* the population.                     */
/*-------------------------------------*/
{
       	/*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);

	/*---------------------------------*/
	/* SQUARE THE ALLELE FREQUENCIES   */
	/*---------------------------------*/
	float freqs3[c][b];
	FreqSquare(c, b, freqs2, freqs3);

	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs4[b][c];
	FreqsColumn_to_Row(b, c, freqs3, freqs4);
	
	/*-------------------------------*/
	/* CALCULATE HE FOR EACH LOCUS   */
	/*-------------------------------*/
	float HE[b];
	HECalc(b, c, freqs4, HE);

	/*------------------------------*/
	/* GET MATING PAIR DATA         */
	/*------------------------------*/
	int h;		/* Is the number of mating pairs */
	int g;
	int e;

  	h = MatingPairs();
	g = (2 * h);
	e = (2*b)+1;

	int profiles[g][e];
	MatingPairsFile(g, e, profiles);

	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(g, e, profiles);

	/******************************************/
	/* GET HOW MANY ITERATIONS TO PERFORM     */
	/******************************************/
	int mc;
	mc = Iterations();

	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/

	/*-----------------------------------------*/
	/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
	/*-----------------------------------------*/
	int seed1;
	seed1 = InitSeed();

	/*-------------------------------------------------*/
	/* CREATE ARRAY AND WRITE TO FILE "iterationseeds" */
	/*-------------------------------------------------*/
	int iterationseeds[mc];
	IterationSeed(mc, seed1, iterationseeds);

	/*----------------------------*/
	/* GET OUTFILE INFORMATION    */
	/*----------------------------*/
	FILE *fp4;
	char filename4[40];

	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename4);

       	if((fp4 = fopen(filename4, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename4);
                exit(1);
        }

	/*----------------------------*/
	/* WRITE HEADERS FOR OUTFILE  */
	/*----------------------------*/
	fprintf(fp4, "\nIteration\tAverage_AI\n");

	/*----------------------------*/
	/* BEGIN CALCULATIONS         */
	/*----------------------------*/
	int countmc;

	for (countmc = 0; countmc < mc; countmc++)
	{	
		float aa, bb, cc;
		aa = 0;
		bb = 0;
		cc = 0;
		
		/*-----------------------------------*/
		/* GET A NEW SEED FOR EACH ITERATION */
		/*-----------------------------------*/
		int seed2;
		seed2 = iterationseeds[countmc];

		fprintf(fp4, "\n%d\t", countmc+1);

		/*--------------------------------------------------*/
		/* GENERATE RANDOM NUMBERS FOR EACH NEW MATING PAIR */
		/*--------------------------------------------------*/
		int random2[h];
		IterationSeed(h, seed2, random2);

		int individuals;

		for (individuals = 0; individuals < h; individuals++)
		{

			int seed3;
			seed3 = random2[individuals];

			/*---------------------------------*/
			/* GET THE APPROPRIATE MATING PAIR */
			/*---------------------------------*/
			int pair[2][e];
			int count1, count2;

			for (count1 = 0; count1 < e; count1++)
			{
				pair[0][count1] = profiles[individuals*2][count1];
				pair[1][count1] = profiles[(individuals*2)+1][count1];
			}

			/*----------------------------------------------*/
			/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
			/*----------------------------------------------*/
			int mendel[2][e];
			Mendel(2, e, seed3, mendel);

			/*--------------------------*/
			/* CREATE A NEW OFFSPRING   */
			/*--------------------------*/
			int off[1][e];

			off[0][0] = individuals+1;

			for (count1 = 1; count1 < e; count1 += 2)
			{
				if (mendel[0][count1] == 1)
					off[0][count1] = pair[0][count1];
				else
					off[0][count1] = pair[0][count1+1];
			}

			for (count1 = 2; count1 < e; count1 += 2)
			{
				if (mendel[1][count1] == 1)
					off[0][count1] = pair[1][count1-1];
				else
					off[0][count1] = pair[1][count1];
			}

			/*-----------------------------------*/
			/* DEAL WITH PARTIAL PROFILES        */
			/*-----------------------------------*/
			Partials(1, e, off);

			/*----------------------------------*/
			/* CREATE PARENTAL FILES            */
			/*----------------------------------*/
			int mom[1][e];
			
			for (count1 = 0; count1 < e; count1++)
			{
				mom[0][count1] = pair[0][count1];
			}

			int dad[1][e];
			for (count1 = 0; count1 < e; count1++)
			{
				dad[0][count1] = pair[1][count1];
			}

			/*-----------------------------*/
			/* HETEROZYGOSITY OF OFFSPRING */
			/*-----------------------------*/
			int homo[1][b];
			Homozygosity(1, b, off, homo);

			/*-----------------------------*/
			/* NUMBER OF TYPED LOCI        */
			/*-----------------------------*/
			int offtyped;
			offtyped = 0;
	
			for (count2 = 0; count2 < b; count2++)
			{
				if (off[0][(count2*2)+1] == 0)
					offtyped += 0;
				else
					offtyped += 1;
			}

			/*-----------------------------------------------------*/
			/* DETERMINE IF FATHERS ARE HOMOZYGOUS OR HETEROZYGOUS */
			/*-----------------------------------------------------*/
			int fatherhomo[1][b];
			Homozygosity(1, b, dad, fatherhomo);

			/*-----------------------------------------------------*/
			/* DETERMINE IF MOTHERS ARE HOMOZYGOUS OR HETEROZYGOUS */
			/*-----------------------------------------------------*/
			int motherhomo[1][b];
			Homozygosity(1, b, mom, motherhomo);

			/*-----------------------------------------*/
			/* CALCULATE PARENTAL ALLELE SHARING       */
			/*-----------------------------------------*/
			int MF5[1][b];
			ParentalAlleleSharing(b, e, mom, dad, MF5);

			/*-------------------------------------------*/
			/* CALCULATE FATHER-OFFSPRING ALLELE SHARING */
			/*-------------------------------------------*/
			int FO5[1][b];
			ParentalAlleleSharing(b, e, off, dad, FO5);
	
			/*----------------------------------------*/
			/* MAKE ARRAY FOR CALCULATIONS            */
			/*----------------------------------------*/
			float share1[1][b];
			Sharing(b, e, mom, dad, off, homo, fatherhomo, motherhomo, MF5, FO5, share1);

			/*-----------------------------------*/
			/* CALCULATE AI                      */
			/*-----------------------------------*/
			float AIEstimate;
			AIEstimate = AICalc(b, e, mom, dad, off, HE, share1, offtyped);

			if (AIEstimate > 998)
				aa += 0;
			else
				aa += AIEstimate;
	
			if (AIEstimate > 998)
				cc += 0;
			else
				cc += 1;
		}	
		bb = aa/cc;

		fprintf(fp4, "%f", bb);


		printf("\nIteration %d", countmc+1);
	}

	fclose(fp4);

	printf("\n***********************************");
	printf("\nDONE!! Results written to %s.", filename4);
	printf("\n***********************************\n\n");

	return(0);
}

int AlleleFrequencies(void)
{
	clear_kb();
	/****************************************/
	/* GET GENOTYPE DATA FROM THE USER      */
	/****************************************/
	
	/*------------------*/
	/* Define Variables */
	/*------------------*/
	int loci; /* Holds the number of loci analyzed */
	int individuals; /* Holds the number of individuals analyzed */
	int columns; /* Will be (2 * loci) = # of columns in array */
	
	/*------------------*/
	/* Get Data         */
	/*------------------*/
	loci = Loci();
	individuals = Genotypes();
	columns = (2 * loci);
	
	int profiles[individuals][columns]; /* The array that will hold the genotype data */
	
	/*------------------------*/
	/* INITIALIZE STRUCTURE   */
	/*------------------------*/
	struct Text2 Names[individuals];
	
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
	FILE *fp1;
	char filename1[40];
	int count1, count2;
	
	printf("\nWhat is the name of your genotype file (including extension)? ");
	scanf("%s", filename1);
	
	if((fp1 = fopen(filename1, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename1);
		exit(1);
	}
	
	for (count1 = 0; count1 < individuals; count1++)
	{
		for (count2 = 0; count2 < (columns+1); count2++)
		{
			if (count2 == 0)
				fscanf(fp1, "%s", Names[count1].IndName);
			else
				fscanf(fp1, "%d", &profiles[count1][count2-1]);
		}
	}
	
	fclose(fp1);
    
	/*----------------------------*/
	/* Write results to outfile   */
	/*----------------------------*/
	FILE *fp2;
	char filename2[40];
	
	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename2);
	
	if((fp2 = fopen(filename2, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename2);
		exit(1);
	}
	
	/*----------------------------*/
	/* Write zeros across top     */
	/*----------------------------*/
	for (count1 = 0; count1 < loci; count1++)
	{
		fprintf(fp2, "%d", 0);
		
		if (count1 < (loci-1))
			fprintf(fp2, "\t");
		else
			fprintf(fp2, "\n");
	}
	
	
	/*------------------------------------------*/
	/* MAKE ALLELES ONE COLUMNS FOR EACH LOCUS  */
	/*------------------------------------------*/
	int alleles1[(individuals*2)][loci];
	
	for (count1 = 0; count1 < individuals; count1++)
	{
		for (count2 = 0; count2 < loci; count2++)
		{	
			alleles1[count1*2][count2] = profiles[count1][count2*2];
			alleles1[(count1*2)+1][count2] = profiles[count1][(count2*2)+1];
		}
	}
	
	/*--------------------------------------*/
	/*    MAKE COLUMNS ROWS                 */
	/*--------------------------------------*/
	int alleles2[loci][(individuals*2)];
	
	for (count1 = 0; count1 < (individuals*2); count1++)
	{	
		for (count2 = 0; count2 < loci; count2++)
		{	
			alleles2[count2][count1] = alleles1[count1][count2];
		}
	}
	
	/*---------------------------*/
	/*    SORT ALLELES           */
	/*---------------------------*/
	int holder;
	int count3;
	
	for (count1 = 0; count1 < loci; count1++)
	{
		for (count2 = 0; count2 < (individuals*2)-1; count2++)
		{	
			for (count3 = 0; count3 < (individuals*2)-count2-1; count3++)
			{	
				if (alleles2[count1][count3] > alleles2[count1][count3+1])
				{	
					holder = alleles2[count1][count3];
					alleles2[count1][count3] = alleles2[count1][count3+1];
					alleles2[count1][count3+1] = holder;
				}
			}
		}
	}
    
	
	/*--------------------------*/
	/* IDENTIFY UNIQUE VALUES   */
	/*--------------------------*/
	int unique[loci][individuals*2];
	int allelecounts[loci];
	int allelenumber;
	
	for (count1 = 0; count1 < loci; count1++)
	{	
		allelenumber = 0;
		
		if (alleles2[count1][0] == 0)	
			unique[count1][0] = 0;
		else{
			unique[count1][0] = 2;
			allelenumber += 1;
		} 
		
		
		for (count2 = 1; count2 < (individuals*2); count2++)
		{	
			if (alleles2[count1][count2] == 0)
				unique[count1][count2] = 0;
			else
				if (alleles2[count1][count2] == alleles2[count1][count2-1])
					unique[count1][count2] = 1;
				else{
					unique[count1][count2] = 2;
					allelenumber += 1;
				}	
			
		}	
		allelecounts[count1] = allelenumber;
	}
    
	/*----------------------------*/
	/* Identify most # of alleles */
	/*----------------------------*/
	int MAX;
	
	MAX = allelecounts[0];
	
	for (count1 = 1; count1 < loci; count1++)
	{	
		if (allelecounts[count1] > MAX)
			MAX = allelecounts[count1];
	}
	
	/*-------------------------------------*/
	/* Place unique alleles in a new array */
	/*-------------------------------------*/
	int alleles3[loci][MAX];
	int count5;
	
	for (count1 = 0; count1 < loci; count1++)
	{	
		count3 = 0;
		
		for (count2 = 0; count2 < (individuals*2); count2++)
		{	
			if (unique[count1][count2] == 2)
			{	
				alleles3[count1][count3] = alleles2[count1][count2];
				count3 += 1;
			}
		}
		
		for (count5 = count3; count5 < MAX; count5++)
		{
			alleles3[count1][count5] = 0;
		}
	}
	
	/*-------------------------------------*/
	/* Count the number of missing alleles */
	/*-------------------------------------*/
	float missing[loci];
	float count4;
	
	for (count1 = 0; count1 < loci; count1++)
	{	
		count4 = 0;
		
		for (count2 = 0; count2 < (individuals*2); count2++)
		{	
			if (alleles2[count1][count2] == 0)
				count4 += 1;
		}
		missing[count1] = count4;	
	}
	
	/*----------------------------------------------*/
	/* Count the number of times each allele occurs */
	/*----------------------------------------------*/
	float alleles4[loci][MAX];
	
	for (count1 = 0; count1 < loci; count1++)
	{	
		for (count2 = 0; count2 < MAX; count2++)
		{	
			count4 = 0;
			
			for (count3 = 0; count3 < (individuals*2); count3++)
			{	
				if (alleles2[count1][count3] == alleles3[count1][count2])
					count4 += 1;
			}
			alleles4[count1][count2] = count4 / ((individuals*2)-missing[count1]);	
		}
	}
	
	
	/*--------------------------*/
	/* Write allele frequencies */
	/*--------------------------*/
	for (count1 = 0; count1 < MAX; count1++)
	{			
		for (count2 = 0; count2 < loci; count2++)
		{	
			if (alleles3[count2][count1] == 0)
			{
				fprintf(fp2, "%d", 5);
			}
			else{
				fprintf(fp2, "%f", alleles4[count2][count1]);
            }
			
			if (count2 < (loci-1))
				fprintf(fp2, "\t");
			else
				fprintf(fp2, "\n");	
		}
	}
	
	fclose(fp2);
	
	printf("\n**************************************************************");
	printf("\n Done! Your results have been printed to file %s.", filename2);
	printf("\n**************************************************************\n");
	return(0);
}

/*-----------------FL.c-----------------------*/
/* This program calculates the allele	      */
/* inheritance of each genotyped individual.  */
/* This is based on testin the hypothesis of  */
/* how often an offspring inherits a paternal */
/* allele that is different from the alleles  */
/* present in mom.  This pattern is expected  */
/* in scenarios where fetal abortion occurs   */
/* when the genetic profile of the fetus is   */
/* too similar to that of its mother.  Thus,  */
/* you exect surviving offspring to inherit   */
/* paternal alleles not present in mom more   */
/* often than expected.                       */
/*--------------------------------------------*/

int FL(void)
{
	/****************************/
	/* GET DATA FROM THE USER   */
	/****************************/
	
	clear_kb();
	
	/*******************************************/
	/* Get allele frequency data from the user */
	/*******************************************/
	
	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int j;  /* Holds the number of alleles in most polymorphic locus */
	int b;  /* Holds the number of loci analyzed */
	int l;  /* Will be a + 1, which will be the # of rows in the array */
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	printf("\nHow many alleles do you have in the most polymorphic locus (not including 0)? ");
	scanf("%d", &j);
	
	printf("\nHow many loci did you use? ");
	scanf("%d", &b);
	
	l = j + 1;
	
	/*--------------------*/
	/* DEFINE ARRAY       */
	/*--------------------*/
	float freqs[l][b];
	
	/*------------------------------------------------------*/
	/* READ ALLELE FREQUENCY FILE INTO ARRAY                */
	/*------------------------------------------------------*/
	FILE *fp6;
	char filename6[40];
	int count1, count2;
	
	clear_kb();
	printf("\nWhat is the name of your allele frequency file (including extension)? ");
	scanf("%s", filename6);
	
	if((fp6 = fopen(filename6, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename6);
		exit(1);
	}
	
	for (count1 = 0; count1 < l; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			fscanf(fp6, "%f", &freqs[count1][count2]);
		}
	}
	
	fclose(fp6);
	
	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[l][b];
	
	for (count1 = 0; count1 < l; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (freqs[count1][count2] < 1)
				freqs2[count1][count2] = freqs[count1][count2];
			else
				freqs2[count1][count2] = 0;
		}
	}
	
	/*--------------------------------*/
	/* SQUARE ALLELE FREQUENCIES      */
	/*--------------------------------*/
	float freqs3[l][b];
	
	for (count1 = 0; count1 < l; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			freqs3[count1][count2] = (freqs2[count1][count2] * freqs2[count1][count2]);
		}
	}
	
	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs4[b][l];
	
	for (count1 = 0; count1 < b; count1++)
	{
		for (count2 = 0; count2 < l; count2++)
		{
			freqs4[count1][count2] = freqs3[count2][count1];
		}
	}
	
	/*---------------------------------------*/
	/* CALCULATE HE FOR EACH LOCUS           */
	/*---------------------------------------*/
	float HE[b];
	float m;
	
	for (count1 = 0; count1 < b; count1++)
	{
		m = 0;
		for (count2 = 0; count2 < l; count2++)
		{
			m += freqs4[count1][count2];
		}
		HE[count1] = (1 - m);
	}
	
	/*-------------------*/
	/* DEFINE VARIABLES  */
	/*-------------------*/
	int a;		/* Holds the number of individuals in the genotype file */
	int c;		/* Will be (2*b) + 1 for the number of columns in array */
	FILE *fp1;	/* For genotype data */
	char filename1[40];
	FILE *fp2;	/* For the mating pair data */
	char filename2[40];
	FILE *fp3;
	char filename3[40];
	
	/*-------------------*/
	/* GET GENOTYPE DATA */
	/*-------------------*/
	printf("\nHow many individuals are in your offspring genotype file? ");
	scanf("%d", &a);
	
	c = ((2*b)+1);
	
	int offspring[a][c];	/* Array for genotype file */
	
	clear_kb();
	printf("\nWhat is the name of your offspring genotype file (including extension)? ");
	scanf("%s", filename1);
	
	if((fp1 = fopen(filename1, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename1);
		exit(1);
	}
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			fscanf(fp1, "%d", &offspring[count1][count2]);
		}
	}
	
	fclose(fp1);
	
	/*-----------------------------------------------*/
	/* DEAL WITH PARTIAL PROFILES WITHIN EACH LOCUS  */
	/*-----------------------------------------------*/
	
	for (count1 = 0; count1 < a; count1++)
	{
		for(count2 = 1; count2 < c; count2 += 2)
		{
			if (offspring[count1][count2] == 0)
				offspring[count1][count2+1] = 0;
			else
				if (offspring[count1][count2+1] == 0)
					offspring[count1][count2] = 0;
		}
	}
	
	/*------------------------*/
	/* GET MATING PAIR DATA   */
	/*------------------------*/
	int pairs[2*a][c];
	
	printf("\nWhat is the name of your mating pairs file (including extension)? ");
	scanf("%s", filename2);
	
	if((fp2 = fopen(filename2, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename2);
		exit(1);
	}
	
	for (count1 = 0; count1 < (2*a); count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			fscanf(fp2, "%d", &pairs[count1][count2]);
		}
	}
	
	fclose(fp2);
	
	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename3);
	
	/*-----------------------------------------------*/
	/* DEAL WITH PARTIAL PROFILES WITHIN EACH LOCUS  */
	/*-----------------------------------------------*/
	
	for (count1 = 0; count1 < (2*a); count1++)
	{
		for(count2 = 1; count2 < c; count2 += 2)
		{
			if (pairs[count1][count2] == 0)
				pairs[count1][count2+1] = 0;
			else
				if (pairs[count1][count2+1] == 0)
					pairs[count1][count2] = 0;
		}
	}
	
	/*********************************************************/
	/* DETERMINE IF OFFSPRING ARE HETEROZYGOUS OR HOMOZYGOUS */
	/*********************************************************/	
	int off[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (offspring[count1][(count2*2)+1] == 0)
				off[count1][count2] = 0;
			else
				if (offspring[count1][(count2*2)+1] == offspring[count1][(count2*2)+2])
					off[count1][count2] = 1;
				else
					off[count1][count2] = 2;
		}
	}
	
	/*----------------------------*/
	/* COUNT NUMBER OF TYPED LOCI */	
	/*----------------------------*/
	int off1[a];
	int z;
	
	for (count1 = 0; count1 < a; count1++)
	{
		z = 0;	
		for (count2 = 0; count2 < b; count2++)
		{	
			if (off[count1][count2] > 0)
				z += 1;
			else
				z += 0;
		}
		off1[count1] = z;
	}
	
	/*******************************************************/
	/* DETERMINE IF FATHERS ARE HETEROZYGOUS OR HOMOZYGOUS */
	/*******************************************************/ 
	int father[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (pairs[(count1*2)+1][(count2*2)+1] == 0)
				father[count1][count2] = 0;
			else
				if (pairs[(count1*2)+1][(count2*2)+1] == pairs[(count1*2)+1][(count2*2)+2])
					father[count1][count2] = 1;
				else
					father[count1][count2] = 2;
		}
	}
	
	/********************************************************/
	/* DETERMINE IF MOTHERS ARE HETEROZYGOUS OR HOMOZYGOUS  */
	/********************************************************/
	int mother[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (pairs[count1*2][(count2*2)+1] == 0)
				mother[count1][count2] = 0;
			else
				if (pairs[count1*2][(count2*2)+1] == pairs[count1*2][(count2*2)+2])
					mother[count1][count2] = 1;
				else
					mother[count1][count2] = 2;
		}
	}
	
	/*************************************/
	/* DETERMINE PARENTAL ALLELE SHARING */
	/*************************************/
	
	/*--------------------------*/
	/* LONGITUDINAL COMPARISON  */
	/*--------------------------*/
	int MF1[a][c-1];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < (c-1); count2++)
		{
			if (pairs[count1*2][count2+1] == 0 || pairs[(count1*2)+1][count2+1] == 0)
				MF1[count1][count2] = 0;
			else
				if (pairs[count1*2][count2+1] == pairs[(count1*2)+1][count2+1])
					MF1[count1][count2] = 1;
				else
					MF1[count1][count2] = 0;
		}
	}
	
	/*-----------------------------------*/
	/* COLLAPSING TO ONE VALUE PER LOCUS */
	/*-----------------------------------*/
	int MF2[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			MF2[count1][count2] = MF1[count1][count2*2] + MF1[count1][(count2*2)+1];
		}
	}	
	
	/*-----------------------------*/
	/* DIAGONAL COMAPARISON #1     */
	/*-----------------------------*/
	int MF3[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (pairs[count1*2][(count2*2)+1] == 0 || pairs[(count1*2)+1][(count2*2)+1] == 0)
				MF3[count1][count2] = 0;
			else
				if (pairs[count1*2][(count2*2)+1] == pairs[(count1*2)+1][(count2*2)+2])
					MF3[count1][count2] = 1;
				else
					MF3[count1][count2] = 0;
		}
	}
	
	/*-----------------------------*/
	/* DIAGONAL COMAPARISON #2     */
	/*-----------------------------*/
	int MF4[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (pairs[count1*2][(count2*2)+1] == 0 || pairs[(count1*2)+1][(count2*2)+1] == 0)
				MF4[count1][count2] = 0;
			else
				if (pairs[count1*2][(count2*2)+2] == pairs[(count1*2)+1][(count2*2)+1])
					MF4[count1][count2] = 1;
				else
					MF4[count1][count2] = 0;
		}
	}
	
	/*---------------------------------------*/
	/* COMBINE INTO ONE ALLELE SHARING VALUE */
	/*---------------------------------------*/
	int MF5[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			MF5[count1][count2] = MF2[count1][count2] + MF3[count1][count2] + MF4[count1][count2];
		}
	}
	
	/*********************************************/
	/* DETERMINE FATHER-OFFSPRING ALLELE SHARING */
	/*********************************************/
	
	/*--------------------------*/
	/* LONGITUDINAL COMPARISON  */
	/*--------------------------*/
	int FO1[a][c-1];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < (c-1); count2++)
		{
			if (pairs[(count1*2)+1][count2+1] == 0 || offspring[count1][count2+1] == 0)
				FO1[count1][count2] = 0;
			else
				if (pairs[(count1*2)+1][count2+1] == offspring[count1][count2+1])
					FO1[count1][count2] = 1;
				else
					FO1[count1][count2] = 0;
		}
	}
	
	/*-----------------------------------*/
	/* COLLAPSING TO ONE VALUE PER LOCUS */
	/*-----------------------------------*/
	int FO2[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			FO2[count1][count2] = FO1[count1][count2*2] + FO1[count1][(count2*2)+1];
		}
	}	
	
	/*-----------------------------*/
	/* DIAGONAL COMPARISON #1      */
	/*-----------------------------*/
	int FO3[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (pairs[(count1*2)+1][(count2*2)+1] == 0 || offspring[count1][(count2*2)+1] == 0)
				FO3[count1][count2] = 0;
			else
				if (pairs[(count1*2)+1][(count2*2)+1] == offspring[count1][(count2*2)+2])
					FO3[count1][count2] = 1;
				else
					FO3[count1][count2] = 0;
		}
	}
	
	/*-----------------------------*/
	/* DIAGONAL COMPARISON #2      */
	/*-----------------------------*/
	int FO4[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (pairs[(count1*2)+1][(count2*2)+1] == 0 || offspring[count1][(count2*2)+1] == 0)
				FO4[count1][count2] = 0;
			else
				if (pairs[(count1*2)+1][(count2*2)+2] == offspring[count1][(count2*2)+1])
					FO4[count1][count2] = 1;
				else
					FO4[count1][count2] = 0;
		}
	}
	
	/*---------------------------------------*/
	/* COMBINE INTO ONE ALLELE SHARING VALUE */
	/*---------------------------------------*/
	int FO5[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			FO5[count1][count2] = FO2[count1][count2] + FO3[count1][count2] + FO4[count1][count2];
		}
	}
	
	/*********************************************/
	/* DETERMINE MOTHER-OFFSPRING ALLELE SHARING */
	/*********************************************/
	
	/*--------------------------*/
	/* LONGITUDINAL COMPARISON  */
	/*--------------------------*/
	int MO1[a][c-1];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < (c-1); count2++)
		{
			if (pairs[(count1*2)][count2+1] == 0 || offspring[count1][count2+1] == 0)
				MO1[count1][count2] = 0;
			else
				if (pairs[(count1*2)][count2+1] == offspring[count1][count2+1])
					MO1[count1][count2] = 1;
				else
					MO1[count1][count2] = 0;
		}
	}
	
	/*-----------------------------------*/
	/* COLLAPSING TO ONE VALUE PER LOCUS */
	/*-----------------------------------*/
	int MO2[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			MO2[count1][count2] = MO1[count1][count2*2] + MO1[count1][(count2*2)+1];
		}
	}	
	
	/*-----------------------------*/
	/* DIAGONAL COMPARISON #1      */
	/*-----------------------------*/
	int MO3[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (pairs[(count1*2)][(count2*2)+1] == 0 || offspring[count1][(count2*2)+1] == 0)
				MO3[count1][count2] = 0;
			else
				if (pairs[(count1*2)][(count2*2)+1] == offspring[count1][(count2*2)+2])
					MO3[count1][count2] = 1;
				else
					MO3[count1][count2] = 0;
		}
	}
	
	/*-----------------------------*/
	/* DIAGONAL COMPARISON #2      */
	/*-----------------------------*/
	int MO4[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (pairs[(count1*2)][(count2*2)+1] == 0 || offspring[count1][(count2*2)+1] == 0)
				MO4[count1][count2] = 0;
			else
				if (pairs[(count1*2)][(count2*2)+2] == offspring[count1][(count2*2)+1])
					MO4[count1][count2] = 1;
				else
					MO4[count1][count2] = 0;
		}
	}
	
	/*---------------------------------------*/
	/* COMBINE INTO ONE ALLELE SHARING VALUE */
	/*---------------------------------------*/
	int MO5[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			MO5[count1][count2] = MO2[count1][count2] + MO3[count1][count2] + MO4[count1][count2];
		}
	}
	
	/******************************************/
	/* MAKE ARRAY FOR CALCULATIONS            */
	/******************************************/
	float share1[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (pairs[(count1*2)][(count2*2)+1] == 0 || pairs[(count1*2)+1][(count2*2)+1] == 0 || offspring[count1][(count2*2)+1] == 0)
				share1[count1][count2] = 0;
			else
                if (MF5[count1][count2] == 0)
                    share1[count1][count2] = 0;
                else
                    if (father[count1][count2] == 1)
                        share1[count1][count2] = 0;
                    else
                        if (MF5[count1][count2] == 2 && mother[count1][count2] == 2 && off[count1][count2] == 1)
                            share1[count1][count2] = 2;
                        else
                            if (MF5[count1][count2] == 2 && mother[count1][count2] == 2 && off[count1][count2] == 2)
                                share1[count1][count2] = 1;
                            else
                                if (MF5[count1][count2] == 2 && mother[count1][count2] == 1 && off[count1][count2] == 2)
                                    share1[count1][count2] = 2;
                                else
                                    if (MF5[count1][count2] == 2 && mother[count1][count2] == 1 && off[count1][count2] == 1)
                                        share1[count1][count2] = 1;
                                    else
                                        if (MF5[count1][count2] == 1 && FO5[count1][count2] == 1 && MO5[count1][count2] == 2)
                                            share1[count1][count2] = 1;
                                        else
                                            if (MF5[count1][count2] == 1 && FO5[count1][count2] == 1 && MO5[count1][count2] == 1)
                                                share1[count1][count2] = 2;
                                            else 
                                                share1[count1][count2] = 0;
		}
	}
                                                           
	/*---------------------------------------*/
	/* CALCULATE WEIGHTS FOR EACH INDIVIDUAL */
	/*---------------------------------------*/
	float weights[a][b];
	
	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (pairs[(count1*2)][(count2*2)+1] == 0 || pairs[(count1*2)+1][(count2*2)+1] == 0 || offspring[count1][(count2*2)+1] == 0)
				weights[count1][count2] = 0;
			else
				weights[count1][count2] = HE[count2];
		}
	}
	
	/*------------------------------------------*/
	/* COLLAPSE TO ONE VALUE PER INDIVIDUAL     */
	/*------------------------------------------*/
	float weights2[a];
	float n;
	
	for (count1 = 0; count1 < a; count1++)
	{
		n = 0;
		for (count2 = 0; count2 < b; count2++)
		{
			n += weights[count1][count2];
		}
		weights2[count1] = n;
	}
	
	/*----------------------------*/
	/* PERFORM CALCULATIONS       */
	/*----------------------------*/
	float ai1[a], ai2[a];
	float AI[a];
	float xx, yy, zz;
	
	for (count1 = 0; count1 < a; count1++)
	{
		xx = 0;	
		
		for (count2 = 0; count2 < b; count2++)
		{
			if (share1[count1][count2] == 1 || share1[count1][count2] == 2)
				xx += 1;
			else
				xx += 0;
		}
		ai1[count1] = xx;
	}
	
	xx = 0;
	
	for (count1 = 0; count1 < a; count1++)
	{
		xx = 0;
		for (count2 = 0; count2 < b; count2++)
		{
			if (share1[count1][count2] == 2)
				xx += 1;
			else
				xx += 0;
		}
		ai2[count1] = xx;
	}
	
	xx = 0;
	
	for (count1 = 0; count1 < a; count1++)
	{
		if (ai1[count1] == 0)
			AI[count1] = 999;
		else
			AI[count1] = ((ai2[count1] / ai1[count1]) / (weights2[count1] / off1[count1]));
	}
	
	for (count1 = 0; count1 < a; count1++)
	{
		if (AI[count1] == 999)
			xx += 0;
		else
			xx += AI[count1];
	}
	
	yy = 0;
	zz = 0;
	
	for (count1 = 0; count1 < a; count1++)
	{
		if (AI[count1] == 999)
			yy += 0;
		else
			yy += 1;
	}
	
	zz = xx/yy;
	
	/****************************************************************/
	/* PRINT RESULTS TO USER'S OUTFILE                              */
	/****************************************************************/
	
	if ((fp3 = fopen(filename3, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename3);
		exit(1);
	}
	
	fprintf(fp3, "Individual\tAI\n");	
	
	for (count1 = 0; count1 < a; count1++)
	{
		fprintf(fp3, "%d\t\t%f\n", offspring[count1][0], AI[count1]);
	}
	fprintf(fp3, "\n");
	
	fprintf(fp3, "Average\t\t%f", zz);
	
	fprintf(fp3, "\n");
	
	fclose(fp3);  	
	
	printf("\n");
	printf("\n******************************************************");
	printf("\nDONE!! Your results have been written to file %s.", filename3);
	printf("\n******************************************************");
	printf("\n\n");
	return(0);
	
}

/*--------------FLSIM.c----------------*/
/* This program takes mother and father*/
/* genotypes from the user, randomly   */
/* mates them (with replacement),      */
/* generates offspring, and then       */
/* calculates the allele inheritance   */
/* of those offspring.  These represent*/
/* the "null expectations" of AI values*/
/* for offspring if mating is random   */
/* (among successfull individuals) in  */
/* the population.                     */
/*-------------------------------------*/

int FLSIM(void)
{
	
	/*******************************************/
	/* Get allele frequency data from the user */
	/*******************************************/
	
	clear_kb();
	
	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int j;  /* Holds the number of alleles in most polymorphic locus */
	int b;  /* Holds the number of loci analyzed */
	int l;  /* Will be a + 1, which will be the # of rows in the array */
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	printf("\nHow many alleles do you have in the most polymorphic locus (not including 0)? ");
	scanf("%d", &j);
	
	printf("\nHow many loci did you use? ");
	scanf("%d", &b);
	
	l = j + 1;
	
	/*--------------------*/
	/* DEFINE ARRAY       */
	/*--------------------*/
	float freqs[l][b];
	
	/*------------------------------------------------------*/
	/* READ ALLELE FREQUENCY FILE INTO ARRAY                */
	/*------------------------------------------------------*/
	FILE *fp6;
	char filename6[40];
	int count1, count2;
	
	clear_kb();
	printf("\nWhat is the name of your allele frequency file (including extension)? ");
	scanf("%s", filename6);
	
	if((fp6 = fopen(filename6, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename6);
		exit(1);
	}
	
	for (count1 = 0; count1 < l; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			fscanf(fp6, "%f", &freqs[count1][count2]);
		}
	}
	
	fclose(fp6);
	
	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[l][b];
	
	for (count1 = 0; count1 < l; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (freqs[count1][count2] < 1)
				freqs2[count1][count2] = freqs[count1][count2];
			else
				freqs2[count1][count2] = 0;
		}
	}
	
	/*--------------------------------*/
	/* SQUARE ALLELE FREQUENCIES      */
	/*--------------------------------*/
	float freqs3[l][b];
	
	for (count1 = 0; count1 < l; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			freqs3[count1][count2] = (freqs2[count1][count2] * freqs2[count1][count2]);
		}
	}
	
	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs4[b][l];
	
	for (count1 = 0; count1 < b; count1++)
	{
		for (count2 = 0; count2 < l; count2++)
		{
			freqs4[count1][count2] = freqs3[count2][count1];
		}
	}
	
	/*---------------------------------------*/
	/* CALCULATE HE FOR EACH LOCUS           */
	/*---------------------------------------*/
	float HE[b];
	float m;
	
	for (count1 = 0; count1 < b; count1++)
	{
		m = 0;
		for (count2 = 0; count2 < l; count2++)
		{
			m += freqs4[count1][count2];
		}
		HE[count1] = (1 - m);
	}
	
	/*************************************/
	/* GET PARENTAL DATA FROM THE USER   */
	/*************************************/
	
	/*--------------------*/
	/* DEFINE VARIABLES   */
	/*--------------------*/
	int a;		/* Holds the number of mating pairs */
	int c;		/* Will become (2*b) +1 */
	FILE *fp3;
	char filename3[40];
	
	/*---------------------------------*/
	/* GET PATERNAL GENOTYPES          */
	/*---------------------------------*/
	
	c = (2*b) + 1;
	
	printf("\nHow many mating pairs do you have? ");
	scanf("%d", &a);	
	
	int pairs[(2*a)][c];
	
	printf("\nWhat is the name of your mating pair file (including extension)? ");
	scanf("%s", filename3);
	
	if((fp3 = fopen(filename3, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename3);
		exit(1);
	}
	
	for (count1 = 0; count1 < (2*a); count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			fscanf(fp3, "%d", &pairs[count1][count2]);
		}
	}
	
	fclose(fp3);
	
	/*-------------------*/
	/* DEFINE VARIABLES  */
	/*-------------------*/
	int mc;		/* Holds the number of iterations to perform */
	int countmc;
	int seed1;
	int seed2;
	char filename5[40];
	FILE *fp5;
	
	/*----------------------------------------*/
	/* GET HOW MANY ITERATIONS TO PERFORM     */
	/*----------------------------------------*/
	printf("\nHow many iterations do you want to perform (e.g. 1,000)? ");
	scanf("%d", &mc);	
	
	float average[mc];
	int randomseed[mc];	/*Array to hold seeds for random numbers */
	
	/*-------------------------------------------------------*/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*-------------------------------------------------------*/
	seed1 = InitSeed();
	const gsl_rng_type * TT;
	gsl_rng * rr;
	
	gsl_rng_env_setup();
	
	TT = gsl_rng_mt19937;
	rr = gsl_rng_alloc (TT);
	gsl_rng_set(rr, seed1);
	
	for (count1 = 0; count1 < mc; count1++)
	{
		randomseed[count1] = gsl_rng_uniform_pos(rr) * seed1;
	}
	
	gsl_rng_free(rr);
	
	/*--------------------------*/
	/* Prepare Outfile          */
	/*--------------------------*/
	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename5);
	
	for (countmc = 0; countmc < mc; countmc++)
	{	
		seed2 = randomseed[countmc];
		
		/****************************************************/
		/* CREATE A "MENDEL" ARRAY TO DETERMINE INHERITANCE */
		/****************************************************/
		float mendel1[(a*2)][c];
		int mendel2[(a*2)][c];
		
		const gsl_rng_type * TTT;
		
		gsl_rng * rrr;
		
		gsl_rng_env_setup();
		
		TTT = gsl_rng_mt19937;
		rrr = gsl_rng_alloc (TTT);
		gsl_rng_set(rrr, seed2);
		
		for (count1 = 0; count1 < (a*2); count1++)
		{
			for (count2 = 0; count2 < c; count2++)
			{
				mendel1[count1][count2] = gsl_rng_uniform_pos(rrr);
			}
		}
		
		gsl_rng_free(rrr);
		
		for (count1 = 0; count1 < (a*2); count1++)
		{
			for (count2 = 0; count2 < c; count2++)
			{
				if (mendel1[count1][count2] < 0.5)
					mendel2[count1][count2] = 1;
				else
					mendel2[count1][count2] = 2;
			}
		}	
		
		
		/*****************************************************/
		/* CREATE AN ARRAY WITH NEW OFFSPRING                */
		/*****************************************************/
		int offspring[a][c-1];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 1; count2 < c; count2 += 2)
			{
				if (mendel2[(count1*2)][count2] == 1)
					offspring[count1][count2-1] = pairs[(count1*2)][count2];
				else 
					offspring[count1][count2-1] = pairs[(count1*2)][count2+1];
 				if (mendel2[(count1*2)+1][count2] == 1)
					offspring[count1][count2] = pairs[(count1*2)+1][count2];
				else
					offspring[count1][count2] = pairs[(count1*2)+1][count2+1];
			}
		}	
		
		/**************************************************************/
		/* DEAL WITH PARTIAL PROFILES WITHIN EACH LOCUS               */
		/**************************************************************/
		
		for (count1 = 0; count1 < a; count1++)
		{
			for(count2 = 0; count2 < (c-1); count2+=2)
			{
				if (offspring[count1][count2] == 0)
					offspring[count1][count2+1] = 0;
				else
					if (offspring[count1][count2+1] == 0)
						offspring[count1][count2] = 0;
			}
		}
		
		/*********************************************************/
		/* DETERMINE IF OFFSPRING ARE HETEROZYGOUS OR HOMOZYGOUS */
		/*********************************************************/	
		int off[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (offspring[count1][(count2*2)] == 0)
					off[count1][count2] = 0;
				else
					if (offspring[count1][(count2*2)] == offspring[count1][(count2*2)+1])
						off[count1][count2] = 1;
					else
						off[count1][count2] = 2;
			}
		}
		
		/*----------------------------*/
		/* COUNT NUMBER OF TYPED LOCI */
		/*----------------------------*/
		int off1[a];
		int z;
		
		for (count1 = 0; count1 < a; count1++)
		{
			z = 0;	
			for (count2 = 0; count2 < b; count2++)
			{	
				if (off[count1][count2] > 0)
					z += 1;
				else
					z += 0;
			}
			off1[count1] = z;
		}
		
		/*******************************************************/
		/* DETERMINE IF FATHERS ARE HETEROZYGOUS OR HOMOZYGOUS */
		/*******************************************************/ 
		int father[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (pairs[(count1*2)+1][(count2*2)+1] == 0)
					father[count1][count2] = 0;
				else
					if (pairs[(count1*2)+1][(count2*2)+1] == pairs[(count1*2)+1][(count2*2)+2])
						father[count1][count2] = 1;
					else
						father[count1][count2] = 2;
			}
		}
		
		/********************************************************/
		/* DETERMINE IF MOTHERS ARE HETEROZYGOUS OR HOMOZYGOUS  */
		/********************************************************/
		int mother[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (pairs[count1*2][(count2*2)+1] == 0)
					mother[count1][count2] = 0;
				else
					if (pairs[count1*2][(count2*2)+1] == pairs[count1*2][(count2*2)+2])
						mother[count1][count2] = 1;
					else
						mother[count1][count2] = 2;
			}
		}
		
		/*************************************/
		/* DETERMINE PARENTAL ALLELE SHARING */
		/*************************************/
		
		/*--------------------------*/
		/* LONGITUDINAL COMPARISON  */
		/*--------------------------*/
		int MF1[a][c-1];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < (c-1); count2++)
			{
				if (pairs[count1*2][count2+1] == 0 || pairs[(count1*2)+1][count2+1] == 0)
					MF1[count1][count2] = 0;
				else
					if (pairs[count1*2][count2+1] == pairs[(count1*2)+1][count2+1])
						MF1[count1][count2] = 1;
					else
						MF1[count1][count2] = 0;
			}
		}
		
		/*-----------------------------------*/
		/* COLLAPSING TO ONE VALUE PER LOCUS */
		/*-----------------------------------*/
		int MF2[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				MF2[count1][count2] = MF1[count1][count2*2] + MF1[count1][(count2*2)+1];
			}
		}	
		
		/*-----------------------------*/
		/* DIAGONAL COMAPARISON #1     */
		/*-----------------------------*/
		int MF3[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (pairs[count1*2][(count2*2)+1] == 0 || pairs[(count1*2)+1][(count2*2)+1] == 0)
					MF3[count1][count2] = 0;
				else
					if (pairs[count1*2][(count2*2)+1] == pairs[(count1*2)+1][(count2*2)+2])
						MF3[count1][count2] = 1;
					else
						MF3[count1][count2] = 0;
			}
		}
		
		/*-----------------------------*/
		/* DIAGONAL COMAPARISON #2     */
		/*-----------------------------*/
		int MF4[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (pairs[count1*2][(count2*2)+1] == 0 || pairs[(count1*2)+1][(count2*2)+1] == 0)
					MF4[count1][count2] = 0;
				else
					if (pairs[count1*2][(count2*2)+2] == pairs[(count1*2)+1][(count2*2)+1])
						MF4[count1][count2] = 1;
					else
						MF4[count1][count2] = 0;
			}
		}
		
		/*---------------------------------------*/
		/* COMBINE INTO ONE ALLELE SHARING VALUE */
		/*---------------------------------------*/
		int MF5[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				MF5[count1][count2] = MF2[count1][count2] + MF3[count1][count2] + MF4[count1][count2];
			}
		}
		
		/*********************************************/
		/* DETERMINE FATHER-OFFSPRING ALLELE SHARING */
		/*********************************************/
		
		/*--------------------------*/
		/* LONGITUDINAL COMPARISON  */
		/*--------------------------*/
		int FO1[a][c-1];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < (c-1); count2++)
			{
				if (pairs[(count1*2)+1][count2+1] == 0 || offspring[count1][count2] == 0)
					FO1[count1][count2] = 0;
				else
					if (pairs[(count1*2)+1][count2+1] == offspring[count1][count2])
						FO1[count1][count2] = 1;
					else
						FO1[count1][count2] = 0;
			}
		}
		
		/*-----------------------------------*/
		/* COLLAPSING TO ONE VALUE PER LOCUS */
		/*-----------------------------------*/
		int FO2[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				FO2[count1][count2] = FO1[count1][count2*2] + FO1[count1][(count2*2)+1];
			}
		}	
		
		/*-----------------------------*/
		/* DIAGONAL COMAPARISON #1     */
		/*-----------------------------*/
		int FO3[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (pairs[(count1*2)+1][(count2*2)+1] == 0 || offspring[count1][(count2*2)] == 0)
					FO3[count1][count2] = 0;
				else
					if (pairs[(count1*2)+1][(count2*2)+1] == offspring[count1][(count2*2)+1])
						FO3[count1][count2] = 1;
					else
						FO3[count1][count2] = 0;
			}
		}
		
		/*-----------------------------*/
		/* DIAGONAL COMAPARISON #2     */
		/*-----------------------------*/
		int FO4[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (pairs[(count1*2)+1][(count2*2)+1] == 0 || offspring[count1][(count2*2)] == 0)
					FO4[count1][count2] = 0;
				else
					if (pairs[(count1*2)+1][(count2*2)+2] == offspring[count1][(count2*2)])
						FO4[count1][count2] = 1;
					else
						FO4[count1][count2] = 0;
			}
		}
		
		/*---------------------------------------*/
		/* COMBINE INTO ONE ALLELE SHARING VALUE */
		/*---------------------------------------*/
		int FO5[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				FO5[count1][count2] = FO2[count1][count2] + FO3[count1][count2] + FO4[count1][count2];
			}
		}
		
		/*********************************************/
		/* DETERMINE MOTHER-OFFSPRING ALLELE SHARING */
		/*********************************************/
		
		/*--------------------------*/
		/* LONGITUDINAL COMPARISON  */
		/*--------------------------*/
		int MO1[a][c-1];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < (c-1); count2++)
			{
				if (pairs[(count1*2)][count2+1] == 0 || offspring[count1][count2+1] == 0)
					MO1[count1][count2] = 0;
				else
					if (pairs[(count1*2)][count2+1] == offspring[count1][count2+1])
						MO1[count1][count2] = 1;
					else
						MO1[count1][count2] = 0;
			}
		}
		
		/*-----------------------------------*/
		/* COLLAPSING TO ONE VALUE PER LOCUS */
		/*-----------------------------------*/
		int MO2[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				MO2[count1][count2] = MO1[count1][count2*2] + MO1[count1][(count2*2)+1];
			}
		}	
		
		/*-----------------------------*/
		/* DIAGONAL COMPARISON #1      */
		/*-----------------------------*/
		int MO3[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (pairs[(count1*2)][(count2*2)+1] == 0 || offspring[count1][(count2*2)+1] == 0)
					MO3[count1][count2] = 0;
				else
					if (pairs[(count1*2)][(count2*2)+1] == offspring[count1][(count2*2)+2])
						MO3[count1][count2] = 1;
					else
						MO3[count1][count2] = 0;
			}
		}
		
		/*-----------------------------*/
		/* DIAGONAL COMPARISON #2      */
		/*-----------------------------*/
		int MO4[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (pairs[(count1*2)][(count2*2)+1] == 0 || offspring[count1][(count2*2)+1] == 0)
					MO4[count1][count2] = 0;
				else
					if (pairs[(count1*2)][(count2*2)+2] == offspring[count1][(count2*2)+1])
						MO4[count1][count2] = 1;
					else
						MO4[count1][count2] = 0;
			}
		}
		
		/*---------------------------------------*/
		/* COMBINE INTO ONE ALLELE SHARING VALUE */
		/*---------------------------------------*/
		int MO5[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				MO5[count1][count2] = MO2[count1][count2] + MO3[count1][count2] + MO4[count1][count2];
			}
		}

		/******************************************/
		/* MAKE ARRAY FOR CALCULATIONS            */
		/******************************************/
		float share1[a][b];
	
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (pairs[(count1*2)][(count2*2)+1] == 0 || pairs[(count1*2)+1][(count2*2)+1] == 0 || offspring[count1][(count2*2)+1] == 0)
					share1[count1][count2] = 0;
				else
					if (father[count1][count2] == 1)
						share1[count1][count2] = 0;
					else
						if (MF5[count1][count2] == 0)
							share1[count1][count2] = 0;
               	         else
               	             if (MF5[count1][count2] == 2 && mother[count1][count2] == 2 && off[count1][count2] == 1)
               	                 share1[count1][count2] = 2;
               	             else
                                if (MF5[count1][count2] == 2 && mother[count1][count2] == 2 && off[count1][count2] == 2)
                                    share1[count1][count2] = 1;
                                else
                                    if (MF5[count1][count2] == 2 && mother[count1][count2] == 1 && off[count1][count2] == 2)
                                        share1[count1][count2] = 2;
                                    else
                                        if (MF5[count1][count2] == 2 && mother[count1][count2] == 1 && off[count1][count2] == 1)
                                            share1[count1][count2] = 1;
                                        else
                                            if (MF5[count1][count2] == 1 && FO5[count1][count2] == 1 && MO5[count1][count2] == 2)
                                                share1[count1][count2] = 1;
                                            else
                                                if (MF5[count1][count2] == 1 && FO5[count1][count2] == 1 && MO5[count1][count2] == 1)
                                                    share1[count1][count2] = 2;
                                                else 
                                                    share1[count1][count2] = 0;
			}
		}
		
		/*---------------------------------------*/
		/* CALCULATE WEIGHTS FOR EACH INDIVIDUAL */
		/*---------------------------------------*/
		float weights[a][b];
		
		for (count1 = 0; count1 < a; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (pairs[(count1*2)][(count2*2)+1] == 0 || pairs[(count1*2)+1][(count2*2)+1] == 0 || offspring[count1][(count2*2)] == 0)
					weights[count1][count2] = 0;
				else
					weights[count1][count2] = HE[count2];
			}
		}
		
		/*------------------------------------------*/
		/* COLLAPSE TO ONE VALUE PER INDIVIDUAL     */
		/*------------------------------------------*/
		float weights2[a];
		float n;
		
		for (count1 = 0; count1 < a; count1++)
		{
			n = 0;
			for (count2 = 0; count2 < b; count2++)
			{
				n += weights[count1][count2];
			}
			weights2[count1] = n;
		}
		
		/*----------------------------*/
		/* PERFORM CALCULATIONS       */
		/*----------------------------*/
		float ai1[a], ai2[a];
		float AI[a];
		float xx, yy, zz;
		
		for (count1 = 0; count1 < a; count1++)
		{
			xx = 0;	
			
			for (count2 = 0; count2 < b; count2++)
			{
				if (share1[count1][count2] == 1 || share1[count1][count2] == 2)
					xx += 1;
				else
					xx += 0;
			}
			ai1[count1] = xx;
		}
		
		xx = 0;
		
		for (count1 = 0; count1 < a; count1++)
		{
			xx = 0;
			for (count2 = 0; count2 < b; count2++)
			{
				if (share1[count1][count2] == 2)
					xx += 1;
				else
					xx += 0;
			}
			ai2[count1] = xx;
		}
		
		xx = 0;
		
		for (count1 = 0; count1 < a; count1++)
		{
			if (ai1[count1] == 0)
				AI[count1] = 999;
			else
				AI[count1] = ((ai2[count1] / ai1[count1]) / (weights2[count1] / off1[count1]));
		}
		
		for (count1 = 0; count1 < a; count1++)
		{
			if (AI[count1] == 999)
				xx += 0;
			else
				xx += AI[count1];
		}
		
		yy = 0;
		zz = 0;
		
		for (count1 = 0; count1 < a; count1++)
		{
			if (AI[count1] == 999)
				yy += 0;
			else
				yy += 1;
		}
		
		zz = xx/yy;
		
		average[countmc] = zz;
		
		printf("\nIteration %d", countmc+1);
	}
	
	/****************************************************************/
	/* PRINT RESULTS TO USER'S OUTFILE                              */
	/****************************************************************/
	
	if ((fp5 = fopen(filename5, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename5);
		exit(1);
	}
	
	fprintf(fp5, "Average AI\n");	
	
	for (count1 = 0; count1 < mc; count1++)
	{
		fprintf(fp5, "%f\n", average[count1]);
	}
	fprintf(fp5, "\n");
	
	fclose(fp5);  	
	
	printf("\n");
	printf("\n******************************************************");
	printf("\nDONE!! Your results have been written to file %s.", filename5);
	printf("\n******************************************************");
	printf("\n\n");
	
	return(0);
}

int Grelate(void)
/*----------------------------*/
/* This function calculates   */
/* the average relatedness    */
/* of individuals within      */
/* pr-defined "groups".       */
/*----------------------------*/
{
       	/*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);

	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs3[b][c];
	FreqsColumn_to_Row(b, c, freqs2, freqs3);

	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	float var[b];
	Locus_Var(b, c, freqs3, var);

	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	float S02[1][b];
	S0_Calc(b, c, freqs3, S02);

        /***********************************************************/
        /* GET GENOTYPE DATA FROM USER                             */
        /***********************************************************/

        /*----------------------------*/
        /* DEFINE VARIABLES           */
        /*----------------------------*/
        int d;                  /* Holds the number of individuals profiled - for the # of rows in array */
        int e;                  /* Will be (2 x b) +1 to hold the number of columns in genotype file */

        /*---------------------------*/
        /* GET DATA FROM USER        */
        /*---------------------------*/
  	d = Genotypes();
        e = (2 * b) + 1;

	int profiles[d][e];
	UserGenotypes(d, e, profiles);

	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(d, e, profiles);

	/*****************************/
	/* GET INFILE DATA FROM USER */
	/*****************************/
	int j;
	int count1, count2;

	printf("\nHow many groups do you have? ");
	scanf("%d", &j);

	int infile[j];

	/*----------------------*/
	/* READ FILE INTO ARRAY */
	/*----------------------*/

	/*-------------------*/
	/* DEFINE VARIABLES  */
	/*-------------------*/
        FILE *fp9;
        char filename9[40];

        printf("\nWhat is the name of your group file (including extension)? ");
        scanf("%s", filename9);

        if((fp9 = fopen(filename9, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename9);
                exit(1);
        }

        for (count1 = 0; count1 < j ; count1++)
        {
                fscanf(fp9, "%d", &infile[count1]);
        }

        fclose(fp9);

	/*----------------------------*/
	/* GET OUTFILE INFORMATION    */
	/*----------------------------*/
	FILE *fp4;
	char filename4[40];

	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename4);

        if((fp4 = fopen(filename4, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename4);
                exit(1);
        }

	/*----------------------------*/
	/* MAKE HEADERS FOR OUTFILE   */
	/*----------------------------*/
	fprintf(fp4, "Group\tAverage R-value\n");

	/********************/
	/* CONDUCT ANALYSES */
	/********************/
	int pair[2][(2*b)+1];
	int count3, count4;
	int n;
	float o, p, qq;
	
	n = 1;
	qq = 0;

	for (count4 = 0; count4 < j; count4++)
	{
		o = 0;
		p = 0;
		for (count3 = (n-1); count3 < infile[count4]; count3++)
		{
			for (count1 = n; count1 < infile[count4]; count1++)
			{
				for (count2 = 0; count2 < ((2*b)+1); count2++)
				{
					pair[0][count2] = profiles[count3][count2];
					pair[1][count2] = profiles[count1][count2];
				}

				/****************************************/
				/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
				/****************************************/
				float weight;
				float weights[1][b];
				weight = 0;
				weight = Locus_Weights(b, e, pair, var, weights);

				/*****************************************/
				/* CALCULATE ALLELE SHARING FOR THE PAIR */
				/*****************************************/
				float AS[1][b];
				AlleleSharing(b, e, pair, AS);

				/*****************************/
				/* CALCULATE RELATEDNESS     */
				/*****************************/
				float rel;
				rel = 0;
				rel = Relatedness(b, e, weight, pair, AS, S02, weights);

			o += rel;
			}
		n += 1;
		}
	if (count4 == 0)
		p = o/(((infile[count4])*(infile[count4]-1))/2);
	else
		p = o/(((infile[count4] - infile[count4-1])*((infile[count4] - infile[count4-1])-1))/2);

	qq += p;

	/******************************/
	/* PRINT RESULTS TO FILE      */
	/******************************/
	fprintf(fp4, "%d\t%f\n", count4+1, p);

	}

	fprintf(fp4, "\nTotal Average\t%f\n", (qq/j));

	fclose(fp4);

	printf("\n***********************************");
	printf("\nDONE!! Results written to %s.", filename4);
	printf("\n***********************************\n\n");

	return(0);
}

int GrelateSim(void)
/*---------------grelatesim.c-------------*/
/* This function calculates the expected  */
/* within-group relatedness values if     */
/* group composition is random with       */
/* respect to relatedness.  It does this  */
/* by shuffling individuals between groups*/
/* (while keeping group size constant)    */
/* and calculating the within-group       */
/* relatedness values based on these      */
/* shuffled individuals.                  */
/*----------------------------------------*/
{
       	/*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);

	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs3[b][c];
	FreqsColumn_to_Row(b, c, freqs2, freqs3);

	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	float var[b];
	Locus_Var(b, c, freqs3, var);

	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	float S02[1][b];
	S0_Calc(b, c, freqs3, S02);

        /***********************************************************/
        /* GET GENOTYPE DATA FROM USER                             */
        /***********************************************************/

        /*----------------------------*/
        /* DEFINE VARIABLES           */
        /*----------------------------*/
        int d;                  /* Holds the number of individuals profiled - for the # of rows in array */
        int e;                  /* Will be (2 x b) +1 to hold the number of columns in genotype file */

        /*---------------------------*/
        /* GET DATA FROM USER        */
        /*---------------------------*/
  	d = Genotypes();
        e = (2 * b) + 1;

	int profiles[d][e];
	UserGenotypes(d, e, profiles);

	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(d, e, profiles);

	/*****************************/
	/* GET INFILE DATA FROM USER */
	/*****************************/
	int j;
	int count1;

	printf("\nHow many groups do you have? ");
	scanf("%d", &j);

	int infile[j];

	/*----------------------*/
	/* READ FILE INTO ARRAY */
	/*----------------------*/

	/*-------------------*/
	/* DEFINE VARIABLES  */
	/*-------------------*/
        FILE *fp9;
        char filename9[40];

        printf("\nWhat is the name of your group file (including extension)? ");
        scanf("%s", filename9);

        if((fp9 = fopen(filename9, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename9);
                exit(1);
        }

        for (count1 = 0; count1 < j ; count1++)
        {
                fscanf(fp9, "%d", &infile[count1]);
        }

        fclose(fp9);

	/******************************************/
	/* GET HOW MANY ITERATIONS TO PERFORM     */
	/******************************************/
	int mc;
	mc = Iterations();

	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/

	/*-----------------------------------------*/
	/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
	/*-----------------------------------------*/
	int seed1;
	seed1 = InitSeed();

	/*-------------------------------------------------*/
	/* CREATE ARRAY AND WRITE TO FILE "iterationseeds" */
	/*-------------------------------------------------*/
	int iterationseeds[mc];
	IterationSeed(mc, seed1, iterationseeds);

	/*----------------------------*/
	/* GET OUTFILE INFORMATION    */
	/*----------------------------*/
	FILE *fp4;
	char filename4[40];

	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename4);

       	if((fp4 = fopen(filename4, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename4);
                exit(1);
        }

	/*----------------------------*/
	/* WRITE HEADERS FOR OUTFILE  */
	/*----------------------------*/
	fprintf(fp4, "Iteration\t");

	for (count1 = 0; count1 < j; count1++)
	{
		fprintf(fp4, "Group %d\t", count1+1);
	}
	
	fprintf(fp4, "Average\n");

	/*--------------------------*/
	/* BEGIN CALCULATIONS       */
	/*--------------------------*/
	int countmc;

	for (countmc = 0; countmc < mc; countmc++)
	{	
		/*-----------------------------------*/
		/* GET A NEW SEED FOR EACH ITERATION */
		/*-----------------------------------*/
		int seed2;
		seed2 = iterationseeds[countmc];

		fprintf(fp4, "%d\t", countmc+1);

		/*------------------------------------*/
		/* SHUFFLE INDIVIDUALS BETWEEN GROUPS */
		/*------------------------------------*/
		int d1[d];
		Shuffle(d, seed2, d1);

		/*--------------------------------------------*/
		/* PLACE RANDOMIZED INDIVIDUALS IN NEW ARRAY  */
		/*--------------------------------------------*/
		int simpairs[d][(2*b)+1];
		int count2;

		for (count1 = 0; count1 < d; count1++)
		{
			for (count2 = 0; count2 < ((2*b)+1); count2++)
			{
				simpairs[count1][count2] = profiles[d1[count1]][count2];
			}
		} 

		/*------------------------------*/
		/* MAKE NEW PAIRWISE ARRAY      */
		/*------------------------------*/
		int pair[2][(2*b)+1];
		int count3, count4;
		int n;
		float o, p, qq;
	
		n = 1;
		qq = 0;

		for (count4 = 0; count4 < j; count4++)
		{ 
			o = 0;
			p = 0;
			for (count3 = (n-1); count3 < infile[count4]; count3++)
			{
				for (count1 = n; count1 < infile[count4]; count1++)
				{
					for (count2 = 0; count2 < ((2*b)+1); count2++)
					{
						pair[0][count2] = simpairs[count3][count2];
						pair[1][count2] = simpairs[count1][count2];
					}

					/****************************************/
					/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
					/****************************************/
					float weight;
					float weights[1][b];
					weight = 0;
					weight = Locus_Weights(b, e, pair, var, weights);
	
					/*****************************************/
					/* CALCULATE ALLELE SHARING FOR THE PAIR */
					/*****************************************/
					float AS[1][b];
					AlleleSharing(b, e, pair, AS);
	
					/*****************************/
					/* CALCULATE RELATEDNESS     */
					/*****************************/
					float rel;
					rel = 0;
					rel = Relatedness(b, e, weight, pair, AS, S02, weights);
	
				o += rel;
				}
			n += 1;	
			}
		if (count4 == 0)
			p = o/(((infile[count4])*(infile[count4]-1))/2);
		else
			p = o/(((infile[count4] - infile[count4-1])*((infile[count4] - infile[count4-1])-1))/2);

			fprintf(fp4, "%f\t", p);

		qq += p;
		}

	fprintf(fp4, "%f\n", (qq/j));

	printf("\nIteration %d", countmc+1);

	}		

	fclose(fp4);  	

	printf("\n***********************************");
	printf("\nDONE!! Results written to %s.", filename4);
	printf("\n***********************************\n\n");

	return(0);
}

int Grelate2(void)
/*-------------------------------*/
/* This function calculates      */
/* the average relatedness       */
/* of individuals within         */
/* pre-defined "groups". It      */
/* does this for all individuals */
/* compared to one reference     */
/* individual.                   */
/*-------------------------------*/
{
	/*******************************************/
	/* Get allele frequency data from the user */
	/*******************************************/
	
	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int a;  /* Holds the number of alleles in most polymorphic locus */
	int b;  /* Holds the number of loci analyzed */
	int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	a = Alleles();
	b = Loci();
	c = a + 1;
	f = 2 * b;
	
	/*------------------------*/
	/* GET ALLELE FREQUENCIES */
	/*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);
	
	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);
	
	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs3[b][c];
	FreqsColumn_to_Row(b, c, freqs2, freqs3);
	
	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	float var[b];
	Locus_Var(b, c, freqs3, var);
	
	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	float S02[1][b];
	S0_Calc(b, c, freqs3, S02);
	
	/***********************************************************/
	/* GET GENOTYPE DATA FROM USER                             */
	/***********************************************************/
	
	/*----------------------------*/
	/* DEFINE VARIABLES           */
	/*----------------------------*/
	int d;                  /* Holds the number of individuals profiled - for the # of rows in array */
	int e;                  /* Will be (2 x b) +1 to hold the number of columns in genotype file */
	
	/*---------------------------*/
	/* GET DATA FROM USER        */
	/*---------------------------*/
  	d = Genotypes();
	e = (2 * b) + 1;
	
	int profiles[d][e];
	UserGenotypes(d, e, profiles);
	
	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(d, e, profiles);
	
	/*****************************/
	/* GET INFILE DATA FROM USER */
	/*****************************/
	int j;
	int count1, count2;
	
	printf("\nHow many groups do you have? ");
	scanf("%d", &j);
	
	int infile[j];
	
	/*----------------------*/
	/* READ FILE INTO ARRAY */
	/*----------------------*/
	
	/*-------------------*/
	/* DEFINE VARIABLES  */
	/*-------------------*/
	FILE *fp9;
	char filename9[40];
	
	printf("\nWhat is the name of your group file (including extension)? ");
	scanf("%s", filename9);
	
	if((fp9 = fopen(filename9, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename9);
		exit(1);
	}
	
	for (count1 = 0; count1 < j ; count1++)
	{
		fscanf(fp9, "%d", &infile[count1]);
	}
	
	fclose(fp9);
	
	/*----------------------------------*/
	/* GET FOCAL INDIVIDUAL INFORMATION */
	/*----------------------------------*/
	FILE *fp20;
	char filename20[40];
	int focal[j][e];
	
	printf("\nWhat is the name of your focal individual file (including extension)? ");
	scanf("%s", filename20);
	
	if((fp20 = fopen(filename20, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename20);
		exit(1);
	}
	
	for (count1 = 0; count1 < j ; count1++)
	{
		for (count2 = 0; count2 < e; count2++)
		{
			fscanf(fp20, "%d", &focal[count1][count2]);
		}
	}
	
	fclose(fp20);
	
	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(j, e, focal);
	
	/*----------------------------*/
	/* GET OUTFILE INFORMATION    */
	/*----------------------------*/
	FILE *fp4;
	char filename4[40];
	
	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename4);
	
	if((fp4 = fopen(filename4, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename4);
		exit(1);
	}
	
	/*----------------------------*/
	/* MAKE HEADERS FOR OUTFILE   */
	/*----------------------------*/
	fprintf(fp4, "Group\tAverage R-value\n");
	
	/********************/
	/* CONDUCT ANALYSES */
	/********************/
	int pair[2][(2*b)+1];
	int count4;
	int n;
	float o, p, qq;
	
	n = 0;
	qq = 0;
	
	for (count4 = 0; count4 < j; count4++)
	{
		o = 0;
		p = 0;
		for (count1 = n; count1 < infile[count4]; count1++)
		{
			for (count2 = 0; count2 < ((2*b)+1); count2++)
			{
				pair[0][count2] = focal[count4][count2];
				pair[1][count2] = profiles[count1][count2];
			}
			
			/****************************************/
			/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
			/****************************************/
			float weight;
			float weights[1][b];
			weight = 0;
			weight = Locus_Weights(b, e, pair, var, weights);
			
			/*****************************************/
			/* CALCULATE ALLELE SHARING FOR THE PAIR */
			/*****************************************/
			float AS[1][b];
			AlleleSharing(b, e, pair, AS);
			
			/*****************************/
			/* CALCULATE RELATEDNESS     */
			/*****************************/
			float rel;
			rel = 0;
			rel = Relatedness(b, e, weight, pair, AS, S02, weights);
			
			o += rel;
		}
		n = infile[count4];
		if (count4 == 0)
			p = o/(infile[count4]);
		else
			p = o/(infile[count4] - infile[count4-1]);
		
		qq += p;
		
		/******************************/
		/* PRINT RESULTS TO FILE      */
		/******************************/
		fprintf(fp4, "%d\t%f\n", count4+1, p);
		
	}
	
	fprintf(fp4, "\nTotal Average\t%f\n", (qq/j));
	
	fclose(fp4);
	
	printf("\n***********************************");
	printf("\nDONE!! Results written to %s.", filename4);
	printf("\n***********************************\n\n");
	
	return(0);
}

int Grelate2Sim(void)
/*---------------grelatesim.c----------------*/
/* This function calculates the expected     */
/* within-group relatedness values (relative */
/* to a defined reference individual) if     */
/* group composition is random with          */
/* respect to relatedness.  It does this     */
/* by shuffling individuals (except for the  */
/* reference individual) between groups      */
/* (while keeping group size constant)       */
/* and calculating the within-group          */
/* relatedness values based on these         */
/* shuffled individuals.                     */
/*-------------------------------------------*/
{
	/*******************************************/
	/* Get allele frequency data from the user */
	/*******************************************/
	
 	/*------------------*/
	/* DEFINE VARIABLES */
	/*------------------*/
	int a;  /* Holds the number of alleles in most polymorphic locus */
	int b;  /* Holds the number of loci analyzed */
	int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
	/*----------------------*/
	/* GET DATA FROM USER   */
	/*----------------------*/
	a = Alleles();
	b = Loci();
	c = a + 1;
	f = 2 * b;
	
	/*------------------------*/
	/* GET ALLELE FREQUENCIES */
	/*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);
	
	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);
	
	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs3[b][c];
	FreqsColumn_to_Row(b, c, freqs2, freqs3);
	
	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	float var[b];
	Locus_Var(b, c, freqs3, var);
	
	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	float S02[1][b];
	S0_Calc(b, c, freqs3, S02);
	
	/***********************************************************/
	/* GET GENOTYPE DATA FROM USER                             */
	/***********************************************************/
	
	/*----------------------------*/
	/* DEFINE VARIABLES           */
	/*----------------------------*/
	int d;                  /* Holds the number of individuals profiled - for the # of rows in array */
	int e;                  /* Will be (2 x b) +1 to hold the number of columns in genotype file */
	
	/*---------------------------*/
	/* GET DATA FROM USER        */
	/*---------------------------*/
  	d = Genotypes();
	e = (2 * b) + 1;
	
	int profiles[d][e];
	UserGenotypes(d, e, profiles);
	
	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(d, e, profiles);
	
	/*****************************/
	/* GET INFILE DATA FROM USER */
	/*****************************/
	int j;
	int count1, count2;
	
	printf("\nHow many groups do you have? ");
	scanf("%d", &j);
	
	int infile[j];
	
	/*----------------------*/
	/* READ FILE INTO ARRAY */
	/*----------------------*/
	
	/*-------------------*/
	/* DEFINE VARIABLES  */
	/*-------------------*/
	FILE *fp9;
	char filename9[40];
	
	printf("\nWhat is the name of your group file (including extension)? ");
	scanf("%s", filename9);
	
	if((fp9 = fopen(filename9, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename9);
		exit(1);
	}
	
	for (count1 = 0; count1 < j ; count1++)
	{
		fscanf(fp9, "%d", &infile[count1]);
	}
	
	fclose(fp9);
	
	/******************************************/
	/* GET HOW MANY ITERATIONS TO PERFORM     */
	/******************************************/
	int mc;
	mc = Iterations();
	
	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/
	
	/*-----------------------------------------*/
	/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
	/*-----------------------------------------*/
	int seed1;
	seed1 = InitSeed();
	
	/*-------------------------------------------------*/
	/* CREATE ARRAY AND WRITE TO FILE "iterationseeds" */
	/*-------------------------------------------------*/
	int iterationseeds[mc];
	IterationSeed(mc, seed1, iterationseeds);
	
	/*----------------------------------*/
	/* GET FOCAL INDIVIDUAL INFORMATION */
	/*----------------------------------*/
	FILE *fp20;
	char filename20[40];
	int focal[j][e];
	
	printf("\nWhat is the name of your focal individual file (including extension)? ");
	scanf("%s", filename20);
	
	if((fp20 = fopen(filename20, "r")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename20);
		exit(1);
	}
	
	for (count1 = 0; count1 < j ; count1++)
	{
		for (count2 = 0; count2 < e; count2++)
		{
			fscanf(fp20, "%d", &focal[count1][count2]);
		}
	}
	
	fclose(fp20);
	
	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(j, e, focal);
	
	
	/*----------------------------*/
	/* GET OUTFILE INFORMATION    */
	/*----------------------------*/
	FILE *fp4;
	char filename4[40];
	
	printf("\nWhat do you want to call your outfile? ");
	scanf("%s", filename4);
	
	if((fp4 = fopen(filename4, "w")) == NULL)
	{
		fprintf(stderr, "Error opening file %s.\n", filename4);
		exit(1);
	}
	
	/*----------------------------*/
	/* WRITE HEADERS FOR OUTFILE  */
	/*----------------------------*/
	fprintf(fp4, "Iteration\t");
	
	for (count1 = 0; count1 < j; count1++)
	{
		fprintf(fp4, "Group %d\t", count1+1);
	}
	
	fprintf(fp4, "Average\n");
	
	/*--------------------------*/
	/* BEGIN CALCULATIONS       */
	/*--------------------------*/
	int countmc;
	
	for (countmc = 0; countmc < mc; countmc++)
	{	
		/*-----------------------------------*/
		/* GET A NEW SEED FOR EACH ITERATION */
		/*-----------------------------------*/
		int seed2;
		seed2 = iterationseeds[countmc];
		
		fprintf(fp4, "%d\t", countmc+1);
		
		/*------------------------------------*/
		/* SHUFFLE INDIVIDUALS BETWEEN GROUPS */
		/*------------------------------------*/
		int d1[d];
		Shuffle(d, seed2, d1);
		
		/*--------------------------------------------*/
		/* PLACE RANDOMIZED INDIVIDUALS IN NEW ARRAY  */
		/*--------------------------------------------*/
		int simpairs[d][(2*b)+1];
		
		for (count1 = 0; count1 < d; count1++)
		{
			for (count2 = 0; count2 < ((2*b)+1); count2++)
			{
				simpairs[count1][count2] = profiles[d1[count1]][count2];
			}
		} 
		
		/*------------------------------*/
		/* MAKE NEW PAIRWISE ARRAY      */
		/*------------------------------*/
		int pair[2][(2*b)+1];
		int count4;
		int n;
		float o, p, qq;
		
		n = 0;
		qq = 0;
		
		for (count4 = 0; count4 < j; count4++)
		{ 
			o = 0;
			p = 0;
			for (count1 = n; count1 < infile[count4]; count1++)
			{
				for (count2 = 0; count2 < ((2*b)+1); count2++)
				{
					pair[0][count2] = focal[count4][count2];
					pair[1][count2] = simpairs[count1][count2];
				}
				
				/****************************************/
				/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
				/****************************************/
				float weight;
				float weights[1][b];
				weight = 0;
				weight = Locus_Weights(b, e, pair, var, weights);
				
				/*****************************************/
				/* CALCULATE ALLELE SHARING FOR THE PAIR */
				/*****************************************/
				float AS[1][b];
				AlleleSharing(b, e, pair, AS);
				
				/*****************************/
				/* CALCULATE RELATEDNESS     */
				/*****************************/
				float rel;
				
				rel = 0;
				rel = Relatedness(b, e, weight, pair, AS, S02, weights);
				
				o += rel;
			}
			n = infile[count4];	
			
			if (count4 == 0)
				p = o/((infile[count4]));
			else
				p = o/((infile[count4] - infile[count4-1]));
			
			fprintf(fp4, "%f\t", p);
			
			qq += p;
			
		}
		
		fprintf(fp4, "%f\n", (qq/j));
		
		printf("\nIteration %d", countmc+1);
		
	}		
	
	fclose(fp4);  	
	
	printf("\n***********************************");
	printf("\nDONE!! Results written to %s.", filename4);
	printf("\n***********************************\n\n");
	
	return(0);
}

int HL(void)
/*-----------------HL.c-----------------------*/
/* This program calculates homozygosity by    */
/* loci (HL) for each genotyped individual    */
/* using the method described in Aparicio et  */
/* al. (2006).                                */
/*--------------------------------------------*/
{
       	/*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);

	/*---------------------------------*/
	/* SQUARE THE ALLELE FREQUENCIES   */
	/*---------------------------------*/
	float freqs3[c][b];
	FreqSquare(c, b, freqs2, freqs3);

	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs4[b][c];
	FreqsColumn_to_Row(b, c, freqs3, freqs4);
	
	/*-------------------------------*/
	/* CALCULATE HE FOR EACH LOCUS   */
	/*-------------------------------*/
	float HE[b];
	HECalc(b, c, freqs4, HE);

        /***********************************************************/
        /* GET GENOTYPE DATA FROM USER                             */
        /***********************************************************/

        /*----------------------------*/
        /* DEFINE VARIABLES           */
        /*----------------------------*/
        int d;                  /* Holds the number of individuals profiled - for the # of rows in array */
        int e;                  /* Will be (2 x b) +1 to hold the number of columns in genotype file */

        /*---------------------------*/
        /* GET DATA FROM USER        */
        /*---------------------------*/	
  	d = Genotypes();
        e = (2 * b) + 1;

	int profiles[d][e];
	UserGenotypes(d, e, profiles);

	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(d, e, profiles);

	/**************************************/
	/* GET OUTFILE INFORMATION            */
	/**************************************/
        FILE *fp1;
        char filename1[40];

        printf("\nWhat do you want to call your outfile? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
       	}

	/****************************************/
	/* BEGIN RESULTS FILE                   */
	/****************************************/
	fprintf(fp1, "Individual\tHL-Value\n");

	/***************************************/
	/* CONDUCT CALCULATIONS                */
	/***************************************/
	int individuals;
	float Average, HLSUM;
	Average = 0;
	HLSUM = 0;

	for (individuals = 0; individuals < d; individuals++)
	{
		/*---------------------------------------*/
		/* GET INDIVIDUALS' PROFILE              */
		/*---------------------------------------*/
		int genotype[1][e];
		int count1;

		for (count1 = 0; count1 < e; count1++)
		{
			genotype[0][count1] = profiles[individuals][count1];
		}
		
		/*-----------------------------------------*/
		/* INDICATE HOMOZYGOUS & HETEROZYGOUS LOCI */
		/*-----------------------------------------*/
		int homo[1][b];
		Homozygosity(1, b, genotype, homo);

		/*-------------------------------*/
		/* SUM HE FOR HOMOZYGOUS LOCI    */
		/*-------------------------------*/
		float HL1[1][b];
		float HL_1;
		int count2;

		HL_1 = 0;

		for (count1 = 0; count1 < 1; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (homo[count1][count2] == 1)
					HL1[count1][count2] = HE[count2];
				else
					HL1[count1][count2]= 0;
			HL_1 += HL1[count1][count2];
			}
		}

		/*------------------------------*/
		/* SUM HE for all profiled loci */
		/*------------------------------*/
		float HL3[1][b];
		float HL_2;

		HL_2 = 0;

		for (count1 = 0; count1 < 1; count1++)
		{
			for (count2 = 0; count2 < b; count2++)
			{
				if (homo[count1][count2] == 0)
					HL3[count1][count2]= 0;
				else
					HL3[count1][count2] = HE[count2];
			HL_2 += HL3[count1][count2];
			}
		}

		/*----------------------------------*/
		/* CALCULATE HL FOR EACH INDIVIDUAL */
		/*----------------------------------*/
		float HL_3;
		HL_3 = 0;

		HL_3 = (HL_1 / HL_2);

		/*******************************************/
		/* WRITE RESULTS TO FILE                   */
		/*******************************************/
		fprintf(fp1, "%d\t%f\n", profiles[individuals][0], HL_3);

	HLSUM += HL_3;
	}

	Average = HLSUM/d;

	fprintf(fp1, "\nAverage\t%f\n", Average);	
	
	printf("\n********************************************************\n");
	printf("Done!! Your results have been written to file %s", filename1);
	printf("\n********************************************************\n\n");

	fclose(fp1);

        return(0);
}

int HLSIM(void)
/*--------------HLSIM.c----------------*/
/* This program takes mother and father*/
/* genotypes from the user, randomly   */
/* mates them (with replacement),      */
/* generates offspring, and then       */
/* calculates the HL for those         */
/* offspring.  These represent the     */
/* "null expectations" of HL values    */
/* for offspring if mating is random   */
/* (among successfull individuals) in  */
/* the population.                     */
/*-------------------------------------*/
{
       	/*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);

	/*---------------------------------*/
	/* SQUARE THE ALLELE FREQUENCIES   */
	/*---------------------------------*/
	float freqs3[c][b];
	FreqSquare(c, b, freqs2, freqs3);

	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs4[b][c];
	FreqsColumn_to_Row(b, c, freqs3, freqs4);
	
	/*-------------------------------*/
	/* CALCULATE HE FOR EACH LOCUS   */
	/*-------------------------------*/
	float HE[b];
	HECalc(b, c, freqs4, HE);

	/***********************************/
	/* GET PARENTAL DATA FROM THE USER */
	/***********************************/
	
	/*--------------------*/
	/* DEFINE VARIABLES   */
	/*--------------------*/
	int d;		/* Holds the number of males profiled */
	int e;		/* Holds the number of females profiled */
	int g;		/* Holds 2 * b + 1, which is the number of columns in the profile array */

	g = (2*b)+1;	

	/*-------------------------*/
	/* GET # OF MALES PROFILED */
	/*-------------------------*/
	d = ProfiledMales();

	/*----------------------------------------------------*/
	/* GET MALE GENOYPES & WRITE TO ARRAY "malegenotypes" */
	/*----------------------------------------------------*/
	int malegenotypes[d][g];
	MaleGenotypes(d, g, malegenotypes);

	/*----------------------------------------*/
	/* DEAL WITH PARTIAL GENOTYPES            */
	/*----------------------------------------*/
	Partials(d, g, malegenotypes);

	/*----------------------------*/
	/* GET # OF FEMALES PROFILED  */
	/*----------------------------*/
	e = ProfiledFemales();

	/*--------------------------------------------------------*/
	/* GET FEMALE GENOYPES & WRITE TO ARRAY "femalegenotypes" */
	/*--------------------------------------------------------*/
	int femalegenotypes[e][g];
	FemaleGenotypes(e, g, femalegenotypes);

	/*----------------------------------------*/
	/* DEAL WITH PARTIAL GENOTYPES            */
	/*----------------------------------------*/
	Partials(e, g, femalegenotypes);

	/******************************************/
	/* GET HOW MANY ITERATIONS TO PERFORM     */
	/******************************************/
	int mc;
	mc = Iterations();

	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/

	/*-----------------------------------------*/
	/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
	/*-----------------------------------------*/
	int seed1;
	seed1 = InitSeed();

	/*-------------------------------------------------*/
	/* CREATE ARRAY AND WRITE TO FILE "iterationseeds" */
	/*-------------------------------------------------*/
	int iterationseeds[mc];
	IterationSeed(mc, seed1, iterationseeds);

	/*----------------------------------------*/
	/* GET HOW MANY MATING PAIRS TO GENERATE  */
	/*----------------------------------------*/
	int h;
	printf("\nHow many simulated offspring do you want to generate in each iteration? ");
	scanf("%d", &h);

	/**************************************/
	/* GET OUTFILE INFORMATION            */
	/**************************************/
        FILE *fp1;
        char filename1[40];

        printf("\nWhat do you want to call your outfile? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
       	}

	/****************************************/
	/* BEGIN RESULTS FILE                   */
	/****************************************/
	fprintf(fp1, "Iteration\tAverage_HL\n");

	/**************************************/
	/* CONDUCT SIMULATIONS                */
	/**************************************/
	int countmc;

	for (countmc = 0; countmc < mc; countmc++)
	{	
		/*-----------------------------------*/
		/* GET A NEW SEED FOR EACH ITERATION */
		/*-----------------------------------*/
		int seed2;
		seed2 = iterationseeds[countmc];

		/*--------------------------------------------------*/
		/* GENERATE RANDOM NUMBERS FOR EACH NEW MATING PAIR */
		/*--------------------------------------------------*/
		int random2[h];
		IterationSeed(h, seed2, random2);

		/*************************************/
		/* PERFORM CALCULATIONS              */
		/*************************************/
		int individuals;

		float Average, HLSUM;
		Average = 0;
		HLSUM = 0;

		for (individuals = 0; individuals < h; individuals++)
		{
			/*---------------------------*/
			/* SELECT A RANDOM FEMALE    */
			/*---------------------------*/
			int seed3;
			seed3 = random2[individuals];
			int randomfemale;
			randomfemale = Randomize(e, seed3);

			/*------------------------------*/
			/* SELECT A RANDOM MALE         */
			/*------------------------------*/
			int randommale;
			randommale = Randomize(d, (seed3+5));

			/*----------------------------------------*/
			/* MAKE A NEW MATING PAIR                 */
			/*----------------------------------------*/
			int pairs[2][g];
			int count1;

			for (count1 = 0; count1 < g; count1++)
			{
				pairs[0][count1] = femalegenotypes[randomfemale][count1];
				pairs[1][count1] = malegenotypes[randommale][count1];
			}

			/*----------------------------------------------*/
			/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
			/*----------------------------------------------*/
			int mendel[2][g];
			Mendel(2, g, (seed3+11), mendel);

			/*--------------------------*/
			/* CREATE A NEW OFFSPRING   */
			/*--------------------------*/
			int offspring[1][g];

			offspring[0][0] = individuals+1;

			for (count1 = 1; count1 < g; count1 += 2)
			{
				if (mendel[0][count1] == 1)
					offspring[0][count1] = pairs[0][count1];
				else
					offspring[0][count1] = pairs[0][count1+1];
			}

			for (count1 = 2; count1 < g; count1 += 2)
			{
				if (mendel[1][count1] == 1)
					offspring[0][count1] = pairs[1][count1-1];
				else
					offspring[0][count1] = pairs[1][count1];
			}

			/*-----------------------------------*/
			/* DEAL WITH PARTIAL PROFILES        */
			/*-----------------------------------*/
			Partials(1, g, offspring);

			/*-----------------------------------------*/
			/* INDICATE HOMOZYGOUS & HETEROZYGOUS LOCI */
			/*-----------------------------------------*/
			int homo[1][b];
			Homozygosity(1, b, offspring, homo);

			/*-------------------------------*/
			/* SUM HE FOR HOMOZYGOUS LOCI    */
			/*-------------------------------*/
			float HL1[1][b];
			float HL_1;
			int count2;

			HL_1 = 0;

			for (count1 = 0; count1 < 1; count1++)
			{
				for (count2 = 0; count2 < b; count2++)
				{
					if (homo[count1][count2] == 1)
						HL1[count1][count2] = HE[count2];
					else
						HL1[count1][count2]= 0;
				HL_1 += HL1[count1][count2];
				}
			}

			/*------------------------------*/
			/* SUM HE for all profiled loci */
			/*------------------------------*/
			float HL3[1][b];
			float HL_2;

			HL_2 = 0;

			for (count1 = 0; count1 < 1; count1++)
			{
				for (count2 = 0; count2 < b; count2++)
				{
					if (homo[count1][count2] == 0)
						HL3[count1][count2]= 0;
					else
						HL3[count1][count2] = HE[count2];
				HL_2 += HL3[count1][count2];
				}
			}

			/*----------------------------------*/
			/* CALCULATE HL FOR EACH INDIVIDUAL */
			/*----------------------------------*/
			float HL_3;
			HL_3 = 0;
	
			HL_3 = (HL_1 / HL_2);


		HLSUM += HL_3;
		}

		Average = HLSUM/h;

		/*******************************************/
		/* WRITE RESULTS TO FILE                   */
		/*******************************************/
		fprintf(fp1, "\nAverage\t%f", Average);
		printf("\nIteration %d", countmc+1);
	}	
	
	fclose(fp1);

	printf("\n********************************************************\n");
	printf("Done!! Your results have been written to file %s", filename1);
	printf("\n********************************************************\n\n");

	return(0);
}


int IRcalc(void)
/*-----------------IR.C------------------*/
/* This program calculates the internal  */
/* relatedness (IR) values for a set     */
/* of individuals using the method       */
/* described in Amos et al. (2001)       */
/*---------------------------------------*/
{
        /*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*-------------------------------*/
	/* DOUBLE THE ALLELE FREQUENCIES */
	/*-------------------------------*/
	float freqs2[c][f];
	DoubleFreqs(b, c, f, freqs2, frequencies);

        /***********************************************************/
        /* GET GENOTYPE DATA FROM USER                             */
        /***********************************************************/

        /*----------------------------*/
        /* DEFINE VARIABLES           */
        /*----------------------------*/
        int d;                  /* Holds the number of individuals profiled - for the # of rows in array */
        int e;                  /* Will be (2 x b) +1 to hold the number of columns in genotype file */

        /*---------------------------*/
        /* GET DATA FROM USER        */
        /*---------------------------*/
  	d = Genotypes();
        e = (2 * b) + 1;

	int profiles[d][e];
	UserGenotypes(d, e, profiles);

	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(d, e, profiles);

	/**************************************/
	/* GET OUTFILE INFORMATION            */
	/**************************************/
        FILE *fp1;
        char filename1[40];

        printf("\nWhat do you want to call your outfile? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
       	}

	/****************************************/
	/* BEGIN RESULTS FILE                   */
	/****************************************/
	fprintf(fp1, "Individual\tIR-Value\n");

	/***************************************/
	/* CONDUCT CALCULATIONS                */
	/***************************************/
	int individuals;
	float Average, IRSUM;
	Average = 0;
	IRSUM = 0;

	for (individuals = 0; individuals < d; individuals++)
	{
		/**************************************************/
		/* REPLACE ALLELES WITH THEIR FREQUENCIES AND SUM */
		/**************************************************/
		float allelefreq[1][e-1];
		float A;
		A = 0;
		int count1;
	
		for (count1 = 1; count1 < e; count1++)
		{
			allelefreq[0][count1-1] = freqs2[(profiles[individuals][count1])][count1-1];
			A += allelefreq[0][count1-1];
		}		

		/**************************************************/
		/* SUM HOMOZYGOUS LOCI                            */
		/**************************************************/
		int homozygous[1][b];
		float H;
	
		H = 0;
		for (count1 = 0; count1 < b; count1++)
		{
			if (profiles[individuals][(count1*2)+1] == 0)
				homozygous[0][count1] = 0;
			else
				if (profiles[individuals][(count1*2)+1] == profiles[individuals][(count1*2)+2])
					homozygous[0][count1] = 1;
				else
					homozygous[0][count1] = 0;

		H += homozygous[0][count1];
		}

		/*******************************************/
		/* SUM LOCI PROFILED                       */
		/*******************************************/
		int profiled[1][b];
		float L;

		L = 0;
		for (count1 = 0; count1 < b; count1++)
		{
			if (profiles[individuals][(count1*2)+1] == 0)
				profiled[0][count1] = 0;
			else
				profiled[0][count1] = 1;

		L += profiled[0][count1];
		}

		/********************************************/
		/* CALCULATE IR                             */
		/********************************************/
		float IR;

		IR = ((2*H) - A)/((2*L) - A);
		
		/*******************************************/
		/* WRITE RESULTS TO FILE                   */
		/*******************************************/
		fprintf(fp1, "%d\t%f\n", profiles[individuals][0], IR);

	IRSUM += IR;
	}

	Average = IRSUM/d;

	fprintf(fp1, "\nAverage\t%f\n", Average);	
	
	fclose(fp1);

	printf("\n********************************************************\n");
	printf("Done!! Your results have been written to file %s", filename1);
	printf("\n********************************************************\n\n");

        return(0);
}

int IRsim(void)
/*----------------------------------*/
/* This function calculates the     */
/* expected IR values for offspring */
/* from a known gene pool.  It does */
/* this by sampling mothers and     */
/* fathers (with replacement) from  */
/* their respective files,          */
/* generating offspring from these  */
/* randomized mating pairs, and     */
/* calculating the IR values for    */
/* these simulated offspring.       */
/*----------------------------------*/       
{
       	/*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*-------------------------------*/
	/* DOUBLE THE ALLELE FREQUENCIES */
	/*-------------------------------*/
	float freqs2[c][f];
	DoubleFreqs(b, c, f, freqs2, frequencies);

	/***********************************/
	/* GET PARENTAL DATA FROM THE USER */
	/***********************************/
	
	/*--------------------*/
	/* DEFINE VARIABLES   */
	/*--------------------*/
	int d;		/* Holds the number of males profiled */
	int e;		/* Holds the number of females profiled */
	int g;		/* Holds 2 * b + 1, which is the number of columns in the profile array */

	g = (2*b)+1;	

	/*-------------------------*/
	/* GET # OF MALES PROFILED */
	/*-------------------------*/
	d = ProfiledMales();

	/*----------------------------------------------------*/
	/* GET MALE GENOYPES & WRITE TO ARRAY "malegenotypes" */
	/*----------------------------------------------------*/
	int malegenotypes[d][g];
	MaleGenotypes(d, g, malegenotypes);

	/*----------------------------------------*/
	/* DEAL WITH PARTIAL GENOTYPES            */
	/*----------------------------------------*/
	Partials(d, g, malegenotypes);

	/*----------------------------*/
	/* GET # OF FEMALES PROFILED  */
	/*----------------------------*/
	e = ProfiledFemales();

	/*--------------------------------------------------------*/
	/* GET FEMALE GENOYPES & WRITE TO ARRAY "femalegenotypes" */
	/*--------------------------------------------------------*/
	int femalegenotypes[e][g];
	FemaleGenotypes(e, g, femalegenotypes);

	/*----------------------------------------*/
	/* DEAL WITH PARTIAL GENOTYPES            */
	/*----------------------------------------*/
	Partials(e, g, femalegenotypes);

	/******************************************/
	/* GET HOW MANY ITERATIONS TO PERFORM     */
	/******************************************/
	int mc;
	mc = Iterations();

	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/

	/*-----------------------------------------*/
	/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
	/*-----------------------------------------*/
	int seed1;
	seed1 = InitSeed();

	/*-------------------------------------------------*/
	/* CREATE ARRAY AND WRITE TO FILE "iterationseeds" */
	/*-------------------------------------------------*/
	int iterationseeds[mc];
	IterationSeed(mc, seed1, iterationseeds);

	/*----------------------------------------*/
	/* GET HOW MANY MATING PAIRS TO GENERATE  */
	/*----------------------------------------*/
	int h;
	printf("\nHow many simulated offspring do you want to generate in each iteration? ");
	scanf("%d", &h);

	/**************************************/
	/* GET OUTFILE INFORMATION            */
	/**************************************/
        FILE *fp1;
        char filename1[40];

        printf("\nWhat do you want to call your outfile? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
       	}

	/****************************************/
	/* BEGIN RESULTS FILE                   */
	/****************************************/
	fprintf(fp1, "Iteration\tAverage_IR\n");

	/**************************************/
	/* CONDUCT SIMULATIONS                */
	/**************************************/
	int countmc;

	for (countmc = 0; countmc < mc; countmc++)
	{	
		/*-----------------------------------*/
		/* GET A NEW SEED FOR EACH ITERATION */
		/*-----------------------------------*/
		int seed2;
		seed2 = iterationseeds[countmc];

		/*--------------------------------------------------*/
		/* GENERATE RANDOM NUMBERS FOR EACH NEW MATING PAIR */
		/*--------------------------------------------------*/
		int random2[h];
		IterationSeed(h, seed2, random2);

		/*************************************/
		/* PERFORM CALCULATIONS              */
		/*************************************/
		int individuals;

		float Average, IRSUM;
		Average = 0;
		IRSUM = 0;

		for (individuals = 0; individuals < h; individuals++)
		{
			/*---------------------------*/
			/* SELECT A RANDOM FEMALE    */
			/*---------------------------*/
			int seed3;
			seed3 = random2[individuals];
			int randomfemale;
			randomfemale = Randomize(e, seed3);

			/*------------------------------*/
			/* SELECT A RANDOM MALE         */
			/*------------------------------*/
			int randommale;
			randommale = Randomize(d, (seed3+5));

			/*----------------------------------------*/
			/* MAKE A NEW MATING PAIR                 */
			/*----------------------------------------*/
			int pairs[2][g];
			int count1;

			for (count1 = 0; count1 < g; count1++)
			{
				pairs[0][count1] = femalegenotypes[randomfemale][count1];
				pairs[1][count1] = malegenotypes[randommale][count1];
			}

			/*----------------------------------------------*/
			/* MAKE A MENDEL ARRAY TO DETERMINE INHERITANCE */
			/*----------------------------------------------*/
			int mendel[2][g];
			Mendel(2, g, (seed3+11), mendel);

			/*--------------------------*/
			/* CREATE A NEW OFFSPRING   */
			/*--------------------------*/
			int offspring[1][g];

			offspring[0][0] = individuals+1;

			for (count1 = 1; count1 < g; count1 += 2)
			{
				if (mendel[0][count1] == 1)
					offspring[0][count1] = pairs[0][count1];
				else
					offspring[0][count1] = pairs[0][count1+1];
			}

			for (count1 = 2; count1 < g; count1 += 2)
			{
				if (mendel[1][count1] == 1)
					offspring[0][count1] = pairs[1][count1-1];
				else
					offspring[0][count1] = pairs[1][count1];
			}

			/*-----------------------------------*/
			/* DEAL WITH PARTIAL PROFILES        */
			/*-----------------------------------*/
			Partials(1, g, offspring);

			/**************************************************/
			/* REPLACE ALLELES WITH THEIR FREQUENCIES AND SUM */
			/**************************************************/
			float allelefreq[1][g-1];
			float A;
			A = 0;
		
			for (count1 = 1; count1 < g; count1++)
			{
				allelefreq[0][count1-1] = freqs2[offspring[0][count1]][count1-1];
				A += allelefreq[0][count1-1];
			}		

			/**************************************************/
			/* SUM HOMOZYGOUS LOCI                            */
			/**************************************************/
			int homozygous[1][b];
			float H;
	
			H = 0;
			for (count1 = 0; count1 < b; count1++)
			{
				if (offspring[0][(count1*2)+1] == 0)
					homozygous[0][count1] = 0;
				else
					if (offspring[0][(count1*2)+1] == offspring[0][(count1*2)+2])
						homozygous[0][count1] = 1;
					else
						homozygous[0][count1] = 0;

			H += homozygous[0][count1];
			}

			/*******************************************/
			/* SUM LOCI PROFILED                       */
			/*******************************************/
			int profiled[1][b];
			float L;
	
			L = 0;
			for (count1 = 0; count1 < b; count1++)
			{
				if (offspring[0][(count1*2)+1] == 0)
					profiled[0][count1] = 0;
				else
					profiled[0][count1] = 1;

			L += profiled[0][count1];
			}

			/********************************************/
			/* CALCULATE IR                             */
			/********************************************/
			float IR;

			IR = ((2*H) - A)/((2*L) - A);
		
		IRSUM += IR;
		}

	Average = IRSUM/h;

	fprintf(fp1, "\nIteration %d\t%f", countmc+1, Average);	
	
	printf("\nIteration %d", countmc+1);
	
	}

	fclose(fp1);

	printf("\n********************************************************\n");
	printf("Done!! Your results have been written to file %s", filename1);
	printf("\n********************************************************\n\n");

	return(0);
}

int Pairrelate(void)
/*---------------pairrelate.c--------------*/
/* This program calculates the relatedness */
/* of a list of identified mating pairs    */
/* using the method described in Li et al. */
/* (1993), with each locus weighted using  */
/* the approach described in Lynch &       */
/* Ritland (1999).                         */
/*-----------------------------------------*/
{
       	/*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);

	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs3[b][c];
	FreqsColumn_to_Row(b, c, freqs2, freqs3);

	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	float var[b];
	Locus_Var(b, c, freqs3, var);

	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	float S02[1][b];
	S0_Calc(b, c, freqs3, S02);

	/****************************************************/
	/* GET MATING PAIR DATA FROM THE USER               */
	/****************************************************/

	/*-------------------*/
	/* DEFINE VARIABLES  */
	/*-------------------*/
	int d;		/* Holds the number of mating pairs in file */
	int g;		/* Will be 2*d for the number of rows in array */
	int e;		/* Will be (2 x b) +1 to hold the number of columns in genotype file */

        /*---------------------------*/
        /* GET DATA FROM USER        */
        /*---------------------------*/
  	d = MatingPairs();
	g = (2 * d);
        e = (2 * b) + 1;

	int profiles[g][e];
	MatingPairsFile(g, e, profiles);

	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(g, e, profiles);

	/**************************************/
	/* GET OUTFILE INFORMATION            */
	/**************************************/
        FILE *fp1;
        char filename1[40];

        printf("\nWhat do you want to call your outfile? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
       	}

	/**********************/
	/* CONDUCT ANALYSES   */
	/**********************/
	fprintf(fp1, "Pair\tR-value\n");

	/*----------------------------------*/
	/* READ APPROPRIATE PAIR INTO ARRAY */
	/*----------------------------------*/
	int pair[2][e];
	int count2, count4;

	for (count2 = 0; count2 < d; count2++)
	{		
		for (count4 = 0; count4 < e; count4++)
		{
			pair[0][count4] = profiles[count2*2][count4];
			pair[1][count4] = profiles[(count2*2)+1][count4];
		}

		/****************************************/
		/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
		/****************************************/
		float weight;
		float weights[1][b];
		weight = 0;
		weight = Locus_Weights(b, e, pair, var, weights);

		/*****************************************/
		/* CALCULATE ALLELE SHARING FOR THE PAIR */
		/*****************************************/
		float AS[1][b];
		AlleleSharing(b, e, pair, AS);

		/*****************************/
		/* CALCULATE RELATEDNESS     */
		/*****************************/
		float rel;
		rel = 0;
		rel = Relatedness(b, e, weight, pair, AS, S02, weights);

		/*************************/
		/* PRINT RESULTS TO FILE */
		/*************************/
		fprintf(fp1, "\nPair %d\t%f", count2+1, rel);
	}

	fclose(fp1);

	printf("\n********************************************************\n");
	printf("Done!! Your results have been written to file %s", filename1);
	printf("\n********************************************************\n\n");

	return(0);
}

int Pairsim(void)
/*--------------PAIRSIM.c-------------------*/
/* This program generates the               */
/* distribution of the expected relatedness */
/* values for mating pairs within a         */
/* population if mating is random, by       */
/* sampling males and females from their    */
/* respective files (with replacement)      */
/* and calculating their relatedness        */
/*------------------------------------------*/
{
       	/*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);

	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs3[b][c];
	FreqsColumn_to_Row(b, c, freqs2, freqs3);

	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	float var[b];
	Locus_Var(b, c, freqs3, var);

	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	float S02[1][b];
	S0_Calc(b, c, freqs3, S02);

	/***********************************/
	/* GET PARENTAL DATA FROM THE USER */
	/***********************************/
	
	/*--------------------*/
	/* DEFINE VARIABLES   */
	/*--------------------*/
	int d;		/* Holds the number of males profiled */
	int e;		/* Holds the number of females profiled */
	int g;		/* Holds 2 * b + 1, which is the number of columns in the profile array */

	g = (2*b)+1;	

	/*-------------------------*/
	/* GET # OF MALES PROFILED */
	/*-------------------------*/
	d = ProfiledMales();

	/*----------------------------------------------------*/
	/* GET MALE GENOYPES & WRITE TO ARRAY "malegenotypes" */
	/*----------------------------------------------------*/
	int malegenotypes[d][g];
	MaleGenotypes(d, g, malegenotypes);

	/*----------------------------------------*/
	/* DEAL WITH PARTIAL GENOTYPES            */
	/*----------------------------------------*/
	Partials(d, g, malegenotypes);

	/*----------------------------*/
	/* GET # OF FEMALES PROFILED  */
	/*----------------------------*/
	e = ProfiledFemales();

	/*--------------------------------------------------------*/
	/* GET FEMALE GENOYPES & WRITE TO ARRAY "femalegenotypes" */
	/*--------------------------------------------------------*/
	int femalegenotypes[e][g];
	FemaleGenotypes(e, g, femalegenotypes);

	/*----------------------------------------*/
	/* DEAL WITH PARTIAL GENOTYPES            */
	/*----------------------------------------*/
	Partials(e, g, femalegenotypes);

	/******************************************/
	/* GET HOW MANY ITERATIONS TO PERFORM     */
	/******************************************/
	int mc;
	mc = Iterations();

	/*********************************************************/
	/* MAKE ARRAY TO HOLD SEEDS FOR RANDOM NUMBER GENERATORS */
	/*********************************************************/

	/*-----------------------------------------*/
	/* SEED RANDOM NUMBER GENERATOR WITH CLOCK */
	/*-----------------------------------------*/
	int seed1;
	seed1 = InitSeed();

	/*-------------------------------------------------*/
	/* CREATE ARRAY AND WRITE TO FILE "iterationseeds" */
	/*-------------------------------------------------*/
	int iterationseeds[mc];
	IterationSeed(mc, seed1, iterationseeds);

	/*----------------------------------------*/
	/* GET HOW MANY MATING PAIRS TO GENERATE  */
	/*----------------------------------------*/
	int h;
	printf("\nHow many mating pairs do you want to generate in each iteration? ");
	scanf("%d", &h);

	/**************************************/
	/* GET OUTFILE INFORMATION            */
	/**************************************/
        FILE *fp1;
        char filename1[40];

        printf("\nWhat do you want to call your outfile? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
       	}

	/****************************************/
	/* BEGIN RESULTS FILE                   */
	/****************************************/
	fprintf(fp1, "Iteration\tAverage R-Value\n");

	/**************************************/
	/* CONDUCT SIMULATIONS                */
	/**************************************/
	int countmc;

	for (countmc = 0; countmc < mc; countmc++)
	{	
		/*-----------------------------------*/
		/* GET A NEW SEED FOR EACH ITERATION */
		/*-----------------------------------*/
		int seed2;
		seed2 = iterationseeds[countmc];

		/*--------------------------------------------------*/
		/* GENERATE RANDOM NUMBERS FOR EACH NEW MATING PAIR */
		/*--------------------------------------------------*/
		int random2[h];
		IterationSeed(h, seed2, random2);

		/*************************************/
		/* PERFORM CALCULATIONS              */
		/*************************************/
		int individuals;

		float Average, RSUM;
		Average = 0;
		RSUM = 0;

		for (individuals = 0; individuals < h; individuals++)
		{
			/*---------------------------*/
			/* SELECT A RANDOM FEMALE    */
			/*---------------------------*/
			int seed3;
			seed3 = random2[individuals];
			int randomfemale;
			randomfemale = Randomize(e, seed3);

			/*------------------------------*/
			/* SELECT A RANDOM MALE         */
			/*------------------------------*/
			int randommale;
			randommale = Randomize(d, (seed3+5));

			/*----------------------------------------*/
			/* MAKE A NEW MATING PAIR                 */
			/*----------------------------------------*/
			int pair[2][g];
			int count1;

			for (count1 = 0; count1 < g; count1++)
			{
				pair[0][count1] = femalegenotypes[randomfemale][count1];
				pair[1][count1] = malegenotypes[randommale][count1];
			}

			/*-----------------------------------*/
			/* DEAL WITH PARTIAL PROFILES        */
			/*-----------------------------------*/
			Partials(1, g, pair);

			/****************************************/
			/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
			/****************************************/
			float weight;
			float weights[1][b];
			weight = 0;
			weight = Locus_Weights(b, g, pair, var, weights);

			/*****************************************/
			/* CALCULATE ALLELE SHARING FOR THE PAIR */
			/*****************************************/
			float AS[1][b];
			AlleleSharing(b, g, pair, AS);

			/*****************************/
			/* CALCULATE RELATEDNESS     */
			/*****************************/
			float rel;
			rel = 0;
			rel = Relatedness(b, g, weight, pair, AS, S02, weights);
	
			RSUM += rel;
		}
		Average = RSUM/h;

	fprintf(fp1, "\nIteration %d\t%f", countmc+1, Average);	
	
	printf("\nIteration %d", countmc+1);
	
	}

	fclose(fp1);

	printf("\n********************************************************\n");
	printf("Done!! Your results have been written to file %s", filename1);
	printf("\n********************************************************\n\n");

	return(0);
}

int Pairwise(void)
/*---------------Pairwise.c-----------------*/
/* This program takes a list of individuals */
/* and calculates all pairwise relatedness  */
/* values using the method described in Li  */
/* et al. (1993), with each locus weighted  */
/* using the approach described in Lynch &  */
/* Ritland (1999).                          */
/*------------------------------------------*/
{
       	/*******************************************/
        /* Get allele frequency data from the user */
        /*******************************************/

 	/*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */
        int b;  /* Holds the number of loci analyzed */
        int c;  /* Will be a + 1, which will be the # of rows in the array */
	int f; 	/* Will be 2 * b */
	
        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        a = Alleles();
	b = Loci();
        c = a + 1;
	f = 2 * b;

        /*------------------------*/
        /* GET ALLELE FREQUENCIES */
        /*------------------------*/
	float frequencies[c][b];
	Frequencies(c, b, frequencies);

	/*---------------------------------*/
	/* MAKE INTEGERS ZEROS IN FILE     */
	/*---------------------------------*/
	float freqs2[c][b];
	FreqConvert(c, b, frequencies, freqs2);

	/*-------------------------------*/
	/* CONVERT COLUMNS TO ROWS       */
	/*-------------------------------*/
	float freqs3[b][c];
	FreqsColumn_to_Row(b, c, freqs2, freqs3);

	/*-----------------------------------*/
	/* CALCULATE VARIANCE FOR EACH LOCUS */
	/*-----------------------------------*/
	float var[b];
	Locus_Var(b, c, freqs3, var);

	/*-----------------------------------*/
	/* CALCULATE S0 FOR EACH LOCUS       */
	/*-----------------------------------*/
	float S02[1][b];
	S0_Calc(b, c, freqs3, S02);

        /***********************************************************/
        /* GET GENOTYPE DATA FROM USER                             */
        /***********************************************************/

        /*----------------------------*/
        /* DEFINE VARIABLES           */
        /*----------------------------*/
        int d;                  /* Holds the number of individuals profiled - for the # of rows in array */
        int e;                  /* Will be (2 x b) +1 to hold the number of columns in genotype file */

        /*---------------------------*/
        /* GET DATA FROM USER        */
        /*---------------------------*/
  	d = Genotypes();
        e = (2 * b) + 1;

	int profiles[d][e];
	UserGenotypes(d, e, profiles);

	/**************************************/
	/* DEAL WITH PARTIAL PROFILES         */
	/**************************************/
	Partials(d, e, profiles);

	/**************************************/
	/* GET OUTFILE INFORMATION            */
	/**************************************/
        FILE *fp1;
        char filename1[40];

        printf("\nWhat do you want to call your outfile? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "w")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
       	}

	/**********************/
	/* CONDUCT ANALYSES   */
	/**********************/

	fprintf(fp1, "Individual_1\tIndividual_2\tR-value\n");

	/*----------------------------------*/
	/* READ APPROPRIATE PAIR INTO ARRAY */
	/*----------------------------------*/
	int pair[2][e];
	int count2, count3, count4;

	for (count2 = 0; count2 < d; count2++)
	{		

		for (count3 = (count2+1); count3 < d; count3++)
		{
			for (count4 = 0; count4 < e; count4++)
			{
				pair[0][count4] = profiles[count2][count4];
				pair[1][count4] = profiles[count3][count4];
			}

			/****************************************/
			/* CALCULATE LOCUS WEIGHTS FOR THE PAIR */
			/****************************************/
			float weight;
			float weights[1][b];
			weight = 0;
			weight = Locus_Weights(b, e, pair, var, weights);

			/*****************************************/
			/* CALCULATE ALLELE SHARING FOR THE PAIR */
			/*****************************************/
			float AS[1][b];
			AlleleSharing(b, e, pair, AS);

			/*****************************/
			/* CALCULATE RELATEDNESS     */
			/*****************************/
			float rel;
			rel = 0;
			rel = Relatedness(b, e, weight, pair, AS, S02, weights);

			/*************************/
			/* PRINT RESULTS TO FILE */
			/*************************/
			fprintf(fp1, "\n%d\t%d\t%f", pair[0][0], pair[1][0], rel);
			
		}
	}

	fclose(fp1);

	printf("\n********************************************************\n");
	printf("Done!! Your results have been written to file %s", filename1);
	printf("\n********************************************************\n\n");

	return(0);
}

/***********************************************************************************/
/*                                HELPER FUNCTIONS                                 */
/***********************************************************************************/

float AICalc(int b, int e, int mom[1][e], int dad[1][e], int off[1][e], float HE[b], float share1[1][b], int offtyped)
/*-------------------------------*/
/* This function calculates the  */
/* weighted allele inheritance   */
/* for an offspring, based on    */
/* data that has previously      */
/* been calculated.              */
/*-------------------------------*/
{

	int count1;

	/*---------------------------------------*/
	/* CALCULATE WEIGHTS FOR EACH INDIVIDUAL */
	/*---------------------------------------*/
	float weights[1][b];

	for (count1 = 0; count1 < b; count1++)
	{
		if (mom[0][(count1*2)+1] == 0 || dad[0][(count1*2)+1] == 0 || off[0][(count1*2)+1] == 0)
			weights[0][count1] = 0;
		else
			weights[0][count1] = HE[count1];
	}

	/*------------------------------------------*/
	/* COLLAPSE TO ONE VALUE PER INDIVIDUAL     */
	/*------------------------------------------*/
	float weights2;

	weights2 = 0;

	for (count1 = 0; count1 < b; count1++)
	{
		weights2 += weights[0][count1];
	}
		
	/*----------------------------*/
	/* PERFORM CALCULATIONS       */
	/*----------------------------*/
	float ai1, ai2;
	float AI;
	float xx, yy;

	ai1 = 0;
	ai2 = 0;
	xx = 0;

	for (count1 = 0; count1 < b; count1++)
	{
		if (share1[0][count1] > 0)
			xx += 1;
		else
			xx += 0;
	}
	ai1 = xx;

	yy = 0;

	for (count1 = 0; count1 < b; count1++)
	{
		if (share1[0][count1] == 2)
			yy += 1;
		else
			yy += 0;
	}
	ai2 = yy;

	if (ai1 == 0)
		AI = 999;
	else
		AI = ((ai2 / ai1) / (weights2 / offtyped));

	return AI;
}

int Alleles(void)
/*-----------------------------*/
/* This function asks the user */
/* how many alleles they have  */
/* in the most polymorphic     */
/* locus, and then saves that  */
/* value.                      */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of alleles in most polymorphic locus */

        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many alleles do you have in the most polymorphic locus (not including 0)? ");
        scanf("%d", &a);

	return a;
}

void *AlleleSharing(int b, int e, int pair[2][e], float AS[1][b])
/*------------------------------*/
/* This function calculates the */
/* allele sharing between a pair*/
/* of individuals for the       */
/* calculation of relatedness   */
/*------------------------------*/
{
	/*--------------------*/
	/* FIRST COMPARISON   */
	/*--------------------*/
	int sharing[1][e-1];
	int count5, count6;

	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < (e-1); count6++)
		{
			if((pair[count5*2][count6+1] == 0) || (pair[(count5*2)+1][count6+1] == 0))
				sharing[count5][count6] = 0;
			else
				if (pair[count5*2][count6+1] == pair[(count5*2)+1][count6+1])
					sharing[count5][count6] = 1;
				else
					sharing[count5][count6] = 0;
		}
	}

	/*----------------------------------*/
	/* COLLAPSE TO ONE COLUMN PER LOCUS */
	/*----------------------------------*/
	int share1[1][b];

	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			share1[count5][count6] = (sharing[count5][count6*2] + sharing[count5][(count6*2)+1]);
		}
	}

	/*-----------------------*/
	/* SECOND COMPARISON     */
	/*-----------------------*/
	int share2[1][b];

	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
				share2[count5][count6] = 0;
			else
				if(pair[count5*2][(count6*2)+1] == pair[(count5*2)+1][(count6*2)+2])
					share2[count5][count6] = 1;
				else
					share2[count5][count6] = 0;
		}
	}

	/*---------------------------*/
	/* FOR COMPARISON #3         */
	/*---------------------------*/
	int share3[1][b];

	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
				share3[count5][count6] = 0;
			else
				if(pair[count5*2][(count6*2)+2] == pair[(count5*2)+1][(count6*2)+1])
					share3[count5][count6] = 1;
				else
					share3[count5][count6] = 0;
		}
	}

	/*--------------------------------*/
	/* COMBINE TO ONE VALUE PER LOCUS */
	/*--------------------------------*/
	float share4[1][b];

	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
				share4[count5][count6] = 0;
			else
				share4[count5][count6] = (share1[count5][count6] + share2[count5][count6] + share3[count5][count6]);
		}
	}
				
	/********************************************************/
	/* ASSESS IF INDIVIDUALS ARE HOMOZYGOUS OR HETEROZYGOUS */
	/********************************************************/

	/*-----------------------------------*/
	/* HOMOZYGOTE OR HETEROZYGOTE        */
	/*-----------------------------------*/
	float homo[2][b];

	for (count5 = 0; count5 < 2; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if(pair[count5][(count6*2)+1] == 0)
				homo[count5][count6] = 0;
			else
				if(pair[count5][(count6*2)+1] == pair[count5][(count6*2)+2])
					homo[count5][count6] = 1;
				else
					homo[count5][count6] = 0;
		}
	}

	float hetero[1][b];

	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
				hetero[count5][count6] = 0;	
			else
				hetero[count5][count6] = (homo[count5*2][count6] + homo[(count5*2)+1][count6]);
		}
	}	

	/********************/
	/* CALCULATE AS     */
	/********************/
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
				AS[count5][count6] = 0;
			else
				if(share4[count5][count6] == 4)
					AS[count5][count6] = 1;
				else	
					if((share4[count5][count6] == 2) && (hetero[count5][count6] == 0))
						AS[count5][count6] = 1;
					else
						if((share4[count5][count6] == 2) && (hetero[count5][count6] == 1))
							AS[count5][count6] = 0.75;
						else
							if(share4[count5][count6] == 1)
								AS[count5][count6] = 0.5;
							else
								AS[count5][count6] = 0;
		}
	}
	return(0);
}

void clear_kb(void)
/* Clears stdin of any waiting characters */
{
        char junk[80];
        fgets(junk,80,stdin);
}

void *DoubleFreqs(int b, int c, int f, float freqs2[c][f], float frequencies[c][b])
/*-----------------------------------*/
/* This function makes an array      */
/* where there are two columns of    */
/* allele frequencies for each locus */
/* and writes to file "freqs2".      */
/*-----------------------------------*/
{
        int count1, count2;

        for (count1 = 0; count1 < c; count1++)
        {
                for (count2 = 0; count2 < f; count2++)
                {
                        freqs2[count1][(2*count2)] = frequencies[count1][count2];
                        freqs2[count1][(2*count2)+1] = frequencies[count1][count2];
                }
        }
	return(0);

}

void *FemaleGenotypes(int w, int x, int femalegenotypes[w][x])
/*------------------------------*/
/* This function gets the       */
/* genotype data of profiled    */
/* females from the user and    */
/* writes it to a file called   */
/* "femalegenotypes".           */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[40];
        int count1, count2;

        printf("\nWhat is the name of your 'reproductive females' file (including extension)? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < w; count1++)
        {
                for (count2 = 0; count2 < x; count2++)
                {
                        fscanf(fp1, "%d", &femalegenotypes[count1][count2]);
                }
        }

        fclose(fp1);
	return(0);
}

void *FreqConvert(int c, int b, float frequencies[c][b], float freqs2[c][b])
/*----------------------------*/
/* This function converts the */
/* integers in an allele      */
/* frequency file to zeros.   */
/*----------------------------*/
{
	int count1, count2;

	for (count1 = 0; count1 < c; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (frequencies[count1][count2] < 1)
				freqs2[count1][count2] = frequencies[count1][count2];
			else
				freqs2[count1][count2] = 0;
		}
	}
	return(0);
}

void *FreqsColumn_to_Row(int b, int c, float freqs3[c][b], float freqs4[b][c])
/*------------------------------------*/
/* This function reads the "freqs3"   */
/* array and converts the columns     */
/* to rows.                           */
/*------------------------------------*/
{
	/*--------------------------*/
	/* CONVERT COLUMNS TO ROWS  */
	/*--------------------------*/
	int count1, count2;

	for (count1 = 0; count1 < b; count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			freqs4[count1][count2] = freqs3[count2][count1];
		}
	}
	return(0);
}

void *FreqSquare(int c, int b, float freqs2[c][b], float freqs3[c][b])
/*---------------------------*/
/* This function squares     */
/* the allele frequencies in */
/* the allele frequency file */
/*---------------------------*/
{
	int count1, count2;

	for (count1 = 0; count1 < c; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			freqs3[count1][count2] = (freqs2[count1][count2] * freqs2[count1][count2]);
		}
	}
	return(0);
}

void *Frequencies(int c, int b, float frequencies[c][b])
/*------------------------------*/
/* This function asks the user  */
/* the name of their allele     */
/* frequency file, and then     */
/* reads that into an array     */
/* named frequencies and then   */
/* writes it to a file named    */
/* freqs.                       */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[40];
        int count1, count2;

        printf("\nWhat is the name of your allele frequency file (including extension)? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < c; count1++)
        {
                for (count2 = 0; count2 < b; count2++)
                {
                        fscanf(fp1, "%f", &frequencies[count1][count2]);
                }
        }

        fclose(fp1);

	return(0);
}

int Genotypes(void)
/*-----------------------------*/
/* This function asks the user */
/* how many individuals they   */
/* have in their genotype file */
/* and then returns that value */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of individuals in their genotype file */

        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many individuals do you have in your genotype file? ");
        scanf("%d", &a);

	return a;
}

void *HECalc(int b, int c, float freqs4[b][c], float HE[b])
/*-----------------------------*/
/* This function calculates    */
/* the expected heterozygosity */
/* for a set of loci.          */
/*-----------------------------*/
{
	int count1, count2;
	float a;

	for (count1 = 0; count1 < b; count1++)
	{
		a = 0;
		for (count2 = 0; count2 < c; count2++)
		{
			a += freqs4[count1][count2];
		}
	HE[count1] = (1 - a);
	}
	return(0);
}

void *Homozygosity(int a, int b, int genotype[a][(2*b)+1], int homo[a][b])
/*------------------------------*/
/* This function records if an  */
/* individual is homozygous or  */
/* heterozygous at each locus.  */
/*------------------------------*/
{
	int count1, count2;

	for (count1 = 0; count1 < a; count1++)
	{
		for (count2 = 0; count2 < b; count2++)
		{
			if (genotype[count1][(count2*2)+1] == 0)
				homo[count1][count2] = 0;
			else
				if (genotype[count1][(count2*2)+1] == genotype[count1][(count2*2)+2])
					homo[count1][count2] = 1;
				else
					homo[count1][count2] = 2;
		}
	}
	return(0);
}

int InitSeed(void)
/*------------------------------------*/
/* This function generates a seed for */
/* the random number generator based  */
/* on the computer clock.             */
/*------------------------------------*/
{
        int seed;
        time_t  nowtime;
        struct tm*preztime;

        time(&nowtime);
        preztime = localtime(&nowtime);
        seed = (int)((preztime->tm_sec+1)*(preztime->tm_min+1)*(preztime->tm_hour+1)*(preztime->tm_year)*(preztime->tm_year));
        if(seed%2==0) seed++;

        return seed;
}

int Iterations(void)
/*-----------------------------*/
/* This function asks the user */
/* how many iterations they    */
/* would like to perform, and  */
/* then saves that value.      */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  

        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many iterations do you want to perform (e.g. 1000)? ");
        scanf("%d", &a);

	return a;
}

void *IterationSeed(int y, int z, int iterationseeds[y])
/*------------------------------*/
/* This function creates a list */
/* of random numbers, one for   */
/* each iteration that the user */
/* wants to perform, that will  */
/* serve as the seed for the    */
/* other random number          */
/* generators within that       */
/* iteration.  These numbers are*/
/* written to an array called    */
/* "iterationseeds".            */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        int count1;
	
	/*--------------------------------*/
	/* CREAT ARRAY OF RANDOM NUMBERS  */
	/*--------------------------------*/
	const gsl_rng_type * TT;
	gsl_rng * rr;

	gsl_rng_env_setup();

	TT = gsl_rng_mt19937;
	rr = gsl_rng_alloc (TT);
	gsl_rng_set(rr, z);

	for (count1 = 0; count1 < y; count1++)
	{
		iterationseeds[count1] = gsl_rng_uniform_pos(rr) * z;
	}
	
	gsl_rng_free(rr);

	return(0);
}


int Loci(void)
/*-----------------------------*/
/* This function asks the user */
/* how many loci they used and */
/* saves that  value.          */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of loci used */

        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many loci did you use? ");
        scanf("%d", &a);

	return a;
}

void *Locus_Var(int b, int c, float freqs3[b][c], float var[b])
/*-------------------------------*/
/* This function sums the number */
/* of alleles present in each    */
/* locus.                        */
/*-------------------------------*/
{
	int x, w, count1, count2;

	for (count1 = 0; count1 < b; count1++)
	{
		x = 0;	
		w = 0;	
		for (count2 = 0; count2 < c; count2++)
		{
			if (freqs3[count1][count2] == 0)
				w = 0;
			else
				w = 1;
		x += w;
		}
	var[count1] = x;	
	}
	return(0);
}

float Locus_Weights(int b, int e, int pair[2][e], float var[b], float weights[1][b])
/*------------------------------*/
/* This function calculates the */
/* weight to be given to each   */
/* locus for relatedness        */
/* calculation.                 */
/*------------------------------*/
{
	/*--------------------------------------------------------*/
	/* CALCULATE WEIGHTS FOR EACH LOCUS PROFILED IN EACH PAIR */
	/*--------------------------------------------------------*/

	float w1[1][b];
	int count5, count6;

	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
				w1[count5][count6] = 0;
			else
				w1[count5][count6] = var[count6];
		}
	}

	/*----------------------------------------------*/
	/* CALCULATE THE WEIGHT FOR EACH COMPARED LOCUS */
	/*----------------------------------------------*/
	float w2[1][1];
	float yy, xx;
	yy = 0;
	xx = 0;

	for (count5 = 0; count5 < 1; count5++)
	{
		xx = 0;
		yy = 0;		
		for (count6 = 0; count6 < b; count6++)
		{
			yy = w1[count5][count6];
			xx += yy;
		}
	w2[count5][0] = xx;
	}

	/*-------------------*/
	/* CALCULATE WEIGHTS */
	/*-------------------*/
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if(w1[count5][count6] == 0)
				weights[count5][count6] = 0;
			else
				weights[count5][count6] = (((w1[count5][count6])-1)/(((w2[count5][0])-1)));
		}
	}

	/*------------------------*/
	/* COMBINE WEIGHTS        */
	/*------------------------*/
	float aaa;
	float w3;
	aaa = 0;
	w3 = 0;

	for (count5 = 0; count5 < 1; count5++)
	{
		aaa = 0;
		for (count6 = 0; count6 < b; count6++)
		{
			aaa += weights[count5][count6];
		}
	w3 += aaa;
	}
	return w3;
}

void *MaleGenotypes(int u, int v, int malegenotypes[u][v])
/*------------------------------*/
/* This function gets the       */
/* genotype data of profiled    */
/* males from the user and      */
/* writes it to a file called   */
/* "malegenotypes".             */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[40];
        int count1, count2;

        printf("\nWhat is the name of your 'reproductive males' file (including extension)? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < u; count1++)
        {
                for (count2 = 0; count2 < v; count2++)
                {
                        fscanf(fp1, "%d", &malegenotypes[count1][count2]);
                }
        }

        fclose(fp1);

	return(0);
}

int MatingPairs(void)
/*-----------------------------*/
/* This function asks the user */
/* how many mating pairs they  */
/* have in their genotype file */
/* and then returns that value */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of individuals in their genotype file */

        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many pairs do you have in your mating pairs file? ");
        scanf("%d", &a);

	return a;
}

void *MatingPairsFile(int d, int e, int profiles[d][e])
/*------------------------------*/
/* This function gets the       */
/* genotype data from the user  */
/* and writes it to an array    */
/* called "profiles".           */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[40];
        int count1, count2;

        printf("\nWhat is the name of your mating pairs file (including extension)? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < d; count1++)
        {
                for (count2 = 0; count2 < e; count2++)
                {
                        fscanf(fp1, "%d", &profiles[count1][count2]);
                }
        }

        fclose(fp1);
	return(0);
}

void *Mendel(int mm, int nn, int oo, int mendel[mm][nn])
/*------------------------------------*/
/* This function makes an array that  */
/* is filled with 1's and 2's that    */
/* serves to determine which alleles  */
/* offspring will inherit.            */
/*------------------------------------*/
{
	/*--------------------------*/
	/* DEFINE VARIABLES         */
	/*--------------------------*/
	float mendel1[mm][nn];
	int count1, count2;
	const gsl_rng_type * TTT;
	
	gsl_rng * rrr;

	/*------------------------------------*/
	/* CREAT ARRAY OF RANDOM NUMBERS      */
	/*------------------------------------*/
	gsl_rng_env_setup();

	TTT = gsl_rng_mt19937;
	rrr = gsl_rng_alloc (TTT);
	gsl_rng_set(rrr, oo);

	for (count1 = 0; count1 < mm; count1++)
	{
		for (count2 = 0; count2 < nn; count2++)
		{
			mendel1[count1][count2] = gsl_rng_uniform_pos(rrr);
		}
	}

	gsl_rng_free(rrr);

	/*--------------------------------------*/
	/* CONVERT THESE NUMBERS TO 1'S AND 0'S */
	/*--------------------------------------*/
	for (count1 = 0; count1 < mm; count1++)
	{
		for (count2 = 0; count2 < nn; count2++)
		{
			if (mendel1[count1][count2] < 0.5)
				mendel[count1][count2] = 1;
			else
				mendel[count1][count2] = 2;
		}
	}	
	return(0);
}

int Offspring(void)
/*-----------------------------*/
/* This function asks the user */
/* how many mating pairs they  */
/* have in their genotype file */
/* and then returns that value */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  /* Holds the number of individuals in their genotype file */

        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many offspring do you have in your offspring file? ");
        scanf("%d", &a);

	return a;
}

void *OffspringProfiles(int d, int e, int offspring[d][e])
/*-----------------------------*/
/* This function asks the user */
/* for their offspring file,   */
/* then scans it into an array */
/*-----------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[40];
	int count1, count2;

        printf("\nWhat is the name of your offspring file (including extension)? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < d; count1++)
        {
                for (count2 = 0; count2 < e; count2++)
                {
                        fscanf(fp1, "%d", &offspring[count1][count2]);
                }
        }

        fclose(fp1);
	
	return(0);
}

void *ParentalAlleleSharing(int b, int e, int mom[1][e], int dad[1][e], int MF5[1][b])
/*---------------------------------------*/
/* This functiona calculates the allele  */
/* sharing between the parents for use   */
/* in the calculation of allele          */
/* inheritence.                          */
/*---------------------------------------*/
{
	int count1;
	/*--------------------------*/
	/* LONGITUDINAL COMPARISON  */
	/*--------------------------*/
	int MF1[1][e-1];

	for (count1 = 0; count1 < (e-1); count1++)
	{
		if (mom[0][count1+1] == 0 || dad[0][count1+1] == 0)
			MF1[0][count1] = 0;
		else
			if (mom[0][count1+1] == dad[0][count1+1])
				MF1[0][count1] = 1;
			else
				MF1[0][count1] = 0;
	}

	/*-----------------------------------*/
	/* COLLAPSING TO ONE VALUE PER LOCUS */
	/*-----------------------------------*/
	int MF2[1][b];
	
	for (count1 = 0; count1 < b; count1++)
	{
		MF2[0][count1] = MF1[0][(count1*2)] + MF1[0][(count1*2)+1];
	}

	/*-----------------------------*/
	/* DIAGONAL COMAPARISON #1     */
	/*-----------------------------*/
	int MF3[1][b];
	
	for (count1 = 0; count1 < b; count1++)
	{
		if (mom[0][(count1*2)+1] == 0 || dad[0][(count1*2)+1] == 0)
			MF3[0][count1] = 0;
		else
			if (mom[0][(count1*2)+1] == dad[0][(count1*2)+2])
				MF3[0][count1] = 1;
			else
				MF3[0][count1] = 0;
	}	

	/*-----------------------------*/
	/* DIAGONAL COMAPARISON #2     */
	/*-----------------------------*/
	int MF4[1][b];
	
	for (count1 = 0; count1 < b; count1++)
	{
		if (mom[0][(count1*2)+1] == 0 || dad[0][(count1*2)+1] == 0)
			MF4[0][count1] = 0;
		else
			if (mom[0][(count1*2)+2] == dad[0][(count1*2)+1])
				MF4[0][count1] = 1;
			else
				MF4[0][count1] = 0;
	}	

	/*---------------------------------------*/
	/* COMBINE INTO ONE ALLELE SHARING VALUE */
	/*---------------------------------------*/
	for (count1 = 0; count1 < b; count1++)
	{
		MF5[0][count1] = MF2[0][count1] + MF3[0][count1] + MF4[0][count1];
	}

	return(0);
}

void Partials(int d, int e, int profiles[d][e])
/*---------------------------------*/
/* This function goes through the  */
/* genotype file and ensures that  */
/* if one allele is missing at a   */
/* locus, then both alleles are    */
/* coded as "0". Genotypes must be */
/* all or none at each locus for   */
/* these analyses.                 */
/*---------------------------------*/
{
        int count1, count2;

        for (count1 = 0; count1 < d; count1++)
        {
                for(count2 = 1; count2 < e; count2+=2)
                {
                        if (profiles[count1][count2] == 0)
                                profiles[count1][count2+1] = 0;
                        else
                                if (profiles[count1][count2+1] == 0)
                                        profiles[count1][count2] = 0;
                }
        }
}

int ProfiledFemales(void)
/*-----------------------------*/
/* This function asks the user */
/* how many females they have  */
/* profiled, and then saves    */
/* that value.                 */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  

        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many profiled females do you have in your 'reproductive females' file? ");
        scanf("%d", &a);

	return a;
}

int ProfiledMales(void)
/*-----------------------------*/
/* This function asks the user */
/* how many males they have    */
/* profiled, and then saves    */
/* that value.                 */
/*-----------------------------*/
{
        /*------------------*/
        /* DEFINE VARIABLES */
        /*------------------*/
        int a;  

        /*----------------------*/
        /* GET DATA FROM USER   */
        /*----------------------*/
        printf("\nHow many profiled males do you have in your 'reproductive males' file? ");
        scanf("%d", &a);

	return a;
}

int Randomize(int ff, int gg)
/*----------------------------------*/
/* This function takes the number   */
/* of moms, and randomizes that     */
/* number (with replacement).       */
/* This list is then used later     */
/* to select which females reproduce*/
/* in the simulations.              */
/*----------------------------------*/
{
	/*--------------------*/
	/* DEFINE VARIABLES   */
	/*--------------------*/
	int count1;
	int m1[ff];
	int m2[1];
	const gsl_rng_type * V;
	gsl_rng * w;

	/*-----------------------*/
	/* RANDOMIZE LIST        */
	/*-----------------------*/
	gsl_rng_env_setup();

	V = gsl_rng_mt19937;
	w = gsl_rng_alloc (V);
	gsl_rng_set(w, gg);

	for (count1 = 0; count1 < ff; count1++)
	{
		m1[count1] = count1;
	}

	gsl_ran_sample (w, m2, 1, m1, ff, sizeof(int));

	gsl_rng_free(w);

	int a;
	a = m2[0];

	return a;
}

float Relatedness(int b, int e, float weight, int pair[2][e], float AS[1][b], float S02[1][b], float weights[1][b])
/*-----------------------------*/
/* This function takes other   */
/* data and calculates the     */
/* relatedness for a pair of   */
/* individuals.                */
/*-----------------------------*/
{
	/*----------------------------------*/
	/* CALCULATE RELATEDNESS_1         */
	/*----------------------------------*/
	float rel1[1][b];
	int count5, count6;
	
	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
				rel1[count5][count6] = 0;
			else
				rel1[count5][count6] = ((AS[count5][count6] - S02[0][count6])/(1-S02[0][count6]));
		}
	}

	/*------------------------------------------*/
	/* CALCULATE THE WEIGHTED RELATEDNESS VALUE */
	/*------------------------------------------*/
	float rel2[1][b];

	for (count5 = 0; count5 < 1; count5++)
	{
		for (count6 = 0; count6 < b; count6++)
		{
			if((pair[count5*2][(count6*2)+1] == 0) || (pair[(count5*2)+1][(count6*2)+1] == 0))
				rel2[count5][count6] = 0;
			else
				rel2[count5][count6] = ((rel1[count5][count6])*(weights[count5][count6]));
		}
	}
	
	/*--------------------------------*/
	/* CALCULATE RELATEDNESS VALUE    */
	/*--------------------------------*/
	float rel3;
	float q, s;

	for (count5 = 0; count5 < 1; count5++)
	{
		q = 0;
		s = 0;
		for (count6 = 0; count6 < b; count6++)
		{
			q = rel2[count5][count6];
			s += q;
		}
	rel3 = s/weight;
	}
	return rel3;
}

void *S0_Calc(int b, int c, float freqs3[b][c], float S02[1][b])
/*-------------------------------*/
/* This function calculates the  */
/* S0 for each locus, as needed  */
/* for calculating relatedness.  */
/*-------------------------------*/
{
	int count1, count2;
	float S01[b][c];
	
	for (count1 = 0; count1 < b; count1++)
	{
		for (count2 = 0; count2 < c; count2++)
		{
			S01[count1][count2] = ((freqs3[count1][count2] * freqs3[count1][count2])*(2-freqs3[count1][count2]));
		}
	}

	/*------------------------------*/
	/* SUM ACROSS ALLELES           */
	/*------------------------------*/
	float y,z;

	for (count1 = 0; count1 < b; count1++)
	{
		y = 0;	
		z = 0;	
		for (count2 = 0; count2 < c; count2++)
		{
			z = S01[count1][count2];
		y += z;			
		}
	S02[0][count1] = y;	
	}	

	return(0);
}

void *Sharing(int b, int e, int mom[1][e], int dad[1][e], int off[1][e], int homo[1][b], int fatherhomo[1][b], int motherhomo[1][b], int MF5[1][b], int FO5[1][b], float share1[1][b])
/*----------------------------*/
/* This function takes all of */
/* the parental and offspring */
/* data and creates an array  */
/* of the allele sharing      */
/* between the individuals    */
/* involved.                  */
/*----------------------------*/
{
	int count1;

	for (count1 = 0; count1 < b; count1++)
	{
		if (mom[0][(count1*2)+1] == 0 || dad[0][(count1*2)+1] == 0 || off[0][(count1*2)+1] == 0)
			share1[0][count1] = 0;
		else
			if (fatherhomo[0][count1] == 1)
				share1[0][count1] = 0;
			else
				if (MF5[0][count1] == 0)
					share1[0][count1] = 0;
				else
					if (MF5[0][count1] == 1 && FO5[0][count1] == 2 && homo[0][count1] == 1)
						share1[0][count1] = 1;
					else
						if (MF5[0][count1] == 1 && FO5[0][count1] == 2 && homo[0][count1] == 2)
							share1[0][count1] = 2;
						else
							if (MF5[0][count1] == 2 && motherhomo[0][count1] == 2 && homo[0][count1] == 1)
								share1[0][count1] = 1;
							else
								if (MF5[0][count1] == 2 && motherhomo[0][count1] == 2 && homo[0][count1] == 2)
									share1[0][count1] = 2;
								else
									if (MF5[0][count1] == 2 && motherhomo[0][count1] == 1 && homo[0][count1] == 1)
										share1[0][count1] = 1;
									else
										if (MF5[0][count1] == 2 && motherhomo[0][count1] == 1 && homo[0][count1] == 2)
											share1[0][count1] = 2;
										else
											share1[0][count1] = 0;
	}
	return(0);
}


void *Shuffle(int d, int seed2, int d1[d])
/*-------------------------*/
/* This function shuffles  */
/* numbers to be used for  */
/* randomization (without  */
/* replacement) purposes.  */
/*-------------------------*/
{
	const gsl_rng_type * T;
	gsl_rng * r;

	gsl_rng_env_setup();

	T = gsl_rng_mt19937;
	r = gsl_rng_alloc (T);
	gsl_rng_set(r, seed2);

	int count1;

	for (count1 = 0; count1 < d; count1++)
	{
		d1[count1] = count1;
	}

	gsl_ran_shuffle (r, d1, d, sizeof(int));

	gsl_rng_free(r);

	return(0);
}
void *UserGenotypes(int d, int e, int profiles[d][e])
/*------------------------------*/
/* This function gets the       */
/* genotype data from the user  */
/* and writes it to an array    */
/* called "profiles".           */
/*------------------------------*/
{
	/*---------------------*/
	/* DEFINE VARIABLES)   */
	/*---------------------*/
        FILE *fp1;
        char filename1[40];
        int count1, count2;

        printf("\nWhat is the name of your genotype file (including extension)? ");
        scanf("%s", filename1);

        if((fp1 = fopen(filename1, "r")) == NULL)
        {
                fprintf(stderr, "Error opening file %s.\n", filename1);
                exit(1);
        }

        for (count1 = 0; count1 < d; count1++)
        {
                for (count2 = 0; count2 < e; count2++)
                {
                        fscanf(fp1, "%d", &profiles[count1][count2]);
                }
        }

        fclose(fp1);
	return(0);
}


